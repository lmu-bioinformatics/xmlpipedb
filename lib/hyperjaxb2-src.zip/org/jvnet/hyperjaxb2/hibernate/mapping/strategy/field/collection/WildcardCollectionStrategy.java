package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection;

import java.util.Collection;
import java.util.Collections;

import org.jvnet.hyperjaxb2.customizations.AbstractCollectionPropertyType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.customizations.WildcardCollectionPropertyType;
import org.jvnet.hyperjaxb2.hibernate.mapping.ManyToAny;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.FieldUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class WildcardCollectionStrategy extends AbstractCollectionFieldStrategy {

  public Collection getContent(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {

    final WildcardCollectionPropertyType cproperty = Utils.getWildcardCollectionProperty(fieldItem);

    final ManyToAny manyToAny = Utils.createManyToAny(
        cproperty.getManyToAny(),
        principalStrategy.getIdentifierStrategy().getPropertyType(),
        principalStrategy.getIdentifierStrategy().getMetaType(),
        principalStrategy.getNamingStrategy().getCollectionTableSubColumnName(classContext, fieldItem, "Hjclass"),
        principalStrategy.getNamingStrategy().getCollectionTableSubColumnName(classContext, fieldItem, "Hjchildid"));

    return Collections.singletonList(manyToAny);
  }

  public AbstractCollectionPropertyType getCollectionProperty(FieldItem fieldItem) {
    return Utils.getWildcardCollectionProperty(fieldItem);
  }
}
