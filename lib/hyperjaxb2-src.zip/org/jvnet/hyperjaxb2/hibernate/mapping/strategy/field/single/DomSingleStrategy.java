package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single;

import org.jvnet.hyperjaxb2.customizations.TypeType;
import org.jvnet.hyperjaxb2.customizations.impl.TypeTypeImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.hyperjaxb2.runtime.hibernate.type.ElementType;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class DomSingleStrategy extends AbstractSimpleSingleFieldStrategy {

  protected TypeType getDefaultType(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {
    final TypeType type = new TypeTypeImpl();
    type.setName(ElementType.class.getName());
    return type;
  }
}
