package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.fields;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jvnet.hyperjaxb2.customizations.Constants;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IFieldStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.INamingStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.PrincipalStrategyWrapper;
import org.jvnet.hyperjaxb2.hibernate.visitor.HibernateMappingGeneratingVisitor;
import org.jvnet.jaxbcommons.util.CustomizationUtils;
import org.jvnet.jaxbcommons.util.FieldUtils;
import org.jvnet.jaxbcommons.util.TypeUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;

public class ComponentFieldsStrategy implements IFieldStrategy {

  public Object generateMapping(
      final IPrincipalStrategy principalStrategy,
      final ClassContext classContext,
      final FieldItem fieldItem) {

    final ClassItem fieldClassItem = TypeUtils.getClassItem(classContext, fieldItem);
    final ClassContext fieldClassContext = classContext.parent.getClassContext(fieldClassItem);

    final FieldUse[] fieldUses = fieldClassItem.getDeclaredFieldUses();

    final List fieldMappings = new ArrayList();

    final List fieldItems = new ArrayList(fieldUses.length);

    for (int index = 0; index < fieldUses.length; index++) {
      final FieldUse fieldUse = fieldUses[index];
      final FieldItem item = FieldUtils.getFieldItem(fieldUse);

      if (!CustomizationUtils.containsCustomization(item, Constants.ID)
          && !CustomizationUtils.containsCustomization(item, Constants.VERSION)) {
        fieldItems.add(item);
      }
    }

    for (Iterator iterator = fieldItems.iterator(); iterator.hasNext();) {
      final FieldItem item = (FieldItem) iterator.next();

      final Object fieldMapping = item.visit(new HibernateMappingGeneratingVisitor(

      new PrincipalStrategyWrapper(principalStrategy) {
        private INamingStrategy namingStrategy = getComponentNamingStrategyFactory()
            .createNamingStrategy(principalStrategy, classContext, fieldItem);

        public INamingStrategy getNamingStrategy() {
          return namingStrategy;
        }
      }, fieldClassContext));
      if (fieldMapping != null) {
        fieldMappings.add(fieldMapping);
      }
    }

    return fieldMappings;
  }
}
