package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public interface INamingStrategyFactory {
  
  public INamingStrategy createNamingStrategy(IPrincipalStrategy principalStrategy, ClassContext classContext, FieldItem fieldItem);

}
