package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming;

import com.sun.codemodel.JDefinedClass;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;

public class NamingStrategy implements INamingStrategy {

  public String getTableName(ClassContext classContext) {

    final JDefinedClass theClass = classContext.ref;
    if (theClass.parentContainer() instanceof JDefinedClass) {
      final JDefinedClass container = (JDefinedClass) theClass.parentContainer();
      final ClassItem containingClassItem = classContext.parent
          .getGrammar()
          .getClassItem(container);

      if (containingClassItem != null) {
        final ClassContext containingClassContext = classContext.parent
            .getClassContext(containingClassItem);
        return getTableName(containingClassContext) + "_" + classContext.target.name;
      }
      else {
        return classContext.target.name;
      }
    }
    else {
      return classContext.target.name;
    }
  }
  

  public String getCollectionTableName(ClassContext classContext, FieldItem fieldItem) {
    return getTableName(classContext) + "_" + getColumnName(classContext, fieldItem);
  }

  public String getCollectionTableSubColumnName(
      ClassContext classContext,
      FieldItem fieldItem,
      String name) {
    return getCollectionTableName(classContext, fieldItem) + "_" + name;
  }


  public String getColumnName(ClassContext classContext, FieldItem fieldItem) {
    return fieldItem.name;
  }

  public String getSubColumnName(ClassContext classContext, FieldItem fieldItem, String name) {
    return getColumnName(classContext, fieldItem) + "_" + name;
  }

}
