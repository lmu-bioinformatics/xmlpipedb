package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IFieldStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.INamingStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.INamingStrategyFactory;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IDiscriminatorStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IIdentifierStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IVersionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.type.ITypeStrategy;

public interface IPrincipalStrategy {

  public ITypeStrategy getTypeStrategy();

  public INamingStrategy getNamingStrategy();
  
  public INamingStrategyFactory getComponentNamingStrategyFactory();
  
  public IClassStrategy getClassStrategy();

  public IClassStrategy getSubclassStrategy();

  public IIdentifierStrategy getIdentifierStrategy();

  public IDiscriminatorStrategy getDiscriminatorStrategy();

  public IVersionStrategy getVersionStrategy();

  public IClassStrategy getFieldsStrategy();

  public IFieldStrategy getComponentFieldsStrategy();

  public IFieldStrategy getPrimitiveSingleStrategy();

  public IFieldStrategy getDomSingleStrategy();

  public IFieldStrategy getEnumSingleStrategy();

  public IFieldStrategy getWildcardSingleStrategy();

  public IFieldStrategy getComplexSingleStrategy();

  public IFieldStrategy getComplexCollectionStrategy();

  public IFieldStrategy getDomCollectionStrategy();

  public IFieldStrategy getEnumCollectionStrategy();

  public IFieldStrategy getPrimitiveCollectionStrategy();

  public IFieldStrategy getWildcardCollectionStrategy();

}
