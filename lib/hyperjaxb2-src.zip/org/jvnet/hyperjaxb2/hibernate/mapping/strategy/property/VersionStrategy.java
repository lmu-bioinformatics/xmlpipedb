package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;

import javax.xml.namespace.QName;

import org.jvnet.hyperjaxb2.customizations.Constants;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.customizations.VersionType;
import org.jvnet.hyperjaxb2.hibernate.mapping.Version;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.FieldUtils;
import org.jvnet.jaxbcommons.util.TypeUtils;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JType;
import com.sun.msv.datatype.xsd.LongType;
import com.sun.msv.datatype.xsd.XSDatatype;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.PrimitiveItem;

public class VersionStrategy extends
        AbstractCustomizableFieldStrategy implements IVersionStrategy {

    protected Object generateMappingInternal(
            IPrincipalStrategy principalStrategy, ClassContext classContext,
            FieldItem fieldItem) {
      
        final String fieldPropertyName = FieldUtils
                .getFieldPropertyName(fieldItem);
        final PrimitiveItem fieldTypeItem = TypeUtils
                .getPrimitiveTypeItem(fieldItem);
        final String fieldType = principalStrategy.getTypeStrategy().getType(
                fieldTypeItem.guard);

        final VersionType cversion = Utils.getOrCreateVersion(fieldItem);

        final Version version = Utils.createVersion(cversion, fieldPropertyName,
                fieldType);
        return version;
    }

    public String getDefaultPropertyName() {
        return "Hjversion";
    }

    public XSDatatype getPropertyDatatype() {
        return LongType.theInstance;
    }

    public JType getPropertyClass(JCodeModel codeModel) {
      return codeModel.LONG.getWrapperClass();
    }

    public String getPropertyType() {
        return org.hibernate.type.LongType.class.getName();
    }

    protected QName getCustomizationName() {
        return Constants.VERSION;
    }
}
