package org.jvnet.hyperjaxb2.hibernate.mapping.tests;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.jvnet.hyperjaxb2.hibernate.mapping.HibernateMapping;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.HibernateMappingImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.utils.HibernateMappingUtils;

public class HibernateMappingTest extends TestCase {
  
  public void testNewMapping() throws Exception {
    final HibernateMapping hm = new HibernateMappingImpl();
    final String result = HibernateMappingUtils.marshall(hm);
    Assert.assertTrue("Marshalled content must contain [hibernate-mapping] substring.", result.indexOf("hibernate-mapping") != -1);
  }
}
