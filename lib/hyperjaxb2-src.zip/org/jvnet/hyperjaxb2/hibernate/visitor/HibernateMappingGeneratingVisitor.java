package org.jvnet.hyperjaxb2.hibernate.visitor;

import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.FieldUtils;
import org.jvnet.jaxbcommons.visitor.ClassifyingVisitor;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;

public class HibernateMappingGeneratingVisitor extends ClassifyingVisitor {

  private final IPrincipalStrategy principalStrategy;

  public IPrincipalStrategy getPrincipalStrategy() {
    return principalStrategy;
  }

  public HibernateMappingGeneratingVisitor(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext) {
    super(classContext);
    this.principalStrategy = principalStrategy;
  }

  public Object onClass(ClassItem classItem) {
    if (!Utils.isIgnored(classItem)) {
      return super.onClass(classItem);
    }
    else {
      return null;
    }
  }

  public Object onClassInternal(ClassItem classItem) {

    if (classItem.getSuperClass() == null) {
      return getPrincipalStrategy().getClassStrategy().generateMapping(
          getPrincipalStrategy(),
          classContext);
    }
    else {
      return getPrincipalStrategy().getSubclassStrategy().generateMapping(
          getPrincipalStrategy(),
          classContext);
    }
  }

  public Object onField(FieldItem fieldItem) {
    if (Utils.isIgnored(fieldItem)) {
    	return null;
    }
    else if (FieldUtils.isConstantField(classContext, fieldItem))
    {
    	return null;
    }
    else
    {
      return super.onField(fieldItem);
    }
  }

  public Object onPrimitiveSingleField(FieldItem fieldItem) {
    return getPrincipalStrategy().getPrimitiveSingleStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onDomSingleField(FieldItem fieldItem) {
    return getPrincipalStrategy().getDomSingleStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onEnumSingleField(FieldItem fieldItem) {
    return getPrincipalStrategy().getEnumSingleStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onWildcardSingleField(FieldItem fieldItem) {
    return getPrincipalStrategy().getWildcardSingleStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onHeteroSingleField(FieldItem fieldItem) {
    return getPrincipalStrategy().getWildcardSingleStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onComplexSingleField(FieldItem fieldItem) {
    return getPrincipalStrategy().getComplexSingleStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onPrimitiveCollectionField(FieldItem fieldItem) {
    return getPrincipalStrategy().getPrimitiveCollectionStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onDomCollectionField(FieldItem fieldItem) {
    return getPrincipalStrategy().getDomCollectionStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onEnumCollectionField(FieldItem fieldItem) {
    return getPrincipalStrategy().getEnumCollectionStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onWildcardCollectionField(FieldItem fieldItem) {
    return getPrincipalStrategy().getWildcardCollectionStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onComplexCollectionField(FieldItem fieldItem) {
    return getPrincipalStrategy().getComplexCollectionStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }

  public Object onHeteroCollectionField(FieldItem fieldItem) {
    return getPrincipalStrategy().getWildcardCollectionStrategy().generateMapping(
        getPrincipalStrategy(),
        classContext,
        fieldItem);
  }
}
