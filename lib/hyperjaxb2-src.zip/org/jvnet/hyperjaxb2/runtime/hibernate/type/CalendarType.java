package org.jvnet.hyperjaxb2.runtime.hibernate.type;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;

import org.hibernate.HibernateException;

public class CalendarType extends org.hibernate.type.CalendarType {

  public void set(PreparedStatement preparedStatement, Object calendar, int index)
      throws HibernateException,
      SQLException {
    Calendar cal = (Calendar) calendar;
    preparedStatement.setTimestamp(index, new Timestamp(cal.getTime().getTime()));
  }
}

