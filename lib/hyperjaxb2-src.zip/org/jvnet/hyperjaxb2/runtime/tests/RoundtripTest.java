package org.jvnet.hyperjaxb2.runtime.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.Serializable;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.ReplicationMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.jvnet.hyperjaxb2.runtime.hibernate.event.def.IdTransferringMergeEventListener;
import org.jvnet.jaxbcommons.tests.AbstractPackagedSamplesTest;
import org.jvnet.jaxbcommons.util.ContextUtils;

/**
 * Roundtrip test case.
 * 
 * @author Aleksei Valikov
 */
public abstract class RoundtripTest extends AbstractPackagedSamplesTest {

  /**
   * Test case logger.
   */
  protected static Log logger = LogFactory.getLog(RoundtripTest.class);

  /**
   * Serializing transformer.
   */
  protected Transformer serializer;

  protected SessionFactory sessionFactory;

  public RoundtripTest(final String packageNames) {
    super(packageNames);
  }

  public RoundtripTest(String testName, String packageNames) {
    super(testName, packageNames);
  }

  /**
   * Test setup.
   * 
   * @throws Exception
   *             In case of setup problems.
   */
  public void setUp() throws Exception {
    super.setUp();
    serializer = TransformerFactory.newInstance().newTransformer();
    serializer.setOutputProperty(OutputKeys.INDENT, "yes");

    final Properties properties = new Properties();
    properties.load(new FileInputStream(getPropertiesFile()));

    final Configuration configuration = new Configuration();

    configuration.addDirectory(getConfigurationDirectory());
    configuration.setProperties(properties);
    configuration.getSessionEventListenerConfig().setMergeEventListener(
        new IdTransferringMergeEventListener());

    final SchemaExport schemaExport = new SchemaExport(configuration, properties);
    schemaExport.setDelimiter(";");
    schemaExport.create(true, true);

    sessionFactory = configuration.buildSessionFactory();
  }

  private File getConfigurationDirectory() {
    return new File(getBaseDir(), "hbm");
  }

  protected File getPropertiesFile() {
    return new File(getBaseDir(), "hibernate.properties");
  }

  protected void checkSample(JAXBContext context, File sample) throws Exception {

    final Unmarshaller unmarshaller = context.createUnmarshaller();
    logger.debug("Unmarshalling.");
    // Unmarshall the document
    final Object object = unmarshaller.unmarshal(sample);
    logger.debug("Opening session.");
    // Open the session, save object into the database
    final Session saveSession = sessionFactory.openSession();
    logger.debug("Saving the object.");
    final Object merged = saveSession.merge(object);
    final Serializable id = saveSession.getIdentifier(merged);
    logger.debug("Flushing and closing the session.");
    saveSession.flush();
    // Close the session
    saveSession.close();

    logger.debug("Opening session.");
    // Open the session, load the object
    final Session loadSession = sessionFactory.openSession();
    logger.debug("Loading the object.");
    final Object loadedObject = loadSession.load(object.getClass(), id);
    logger.debug("Closing the session.");
    loadSession.close();

    final Marshaller marshaller = context.createMarshaller();
    logger.debug("Checking the document identity.");

    logger.debug("Source object:\n" + ContextUtils.format(context, object));
    logger.debug("Result object:\n" + ContextUtils.format(context, loadedObject));

    Assert.assertEquals("Loaded and reloaded objects differ.", object, loadedObject);
  }
}