package org.jvnet.jaxbcommons.addon.generator;

import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JMethod;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public interface IMethodStrategy {

  public JMethod generate(ClassContext classContext, FieldItem fieldItem, JDefinedClass theClass);

}
