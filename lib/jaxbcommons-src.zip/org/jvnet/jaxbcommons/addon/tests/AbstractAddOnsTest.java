package org.jvnet.jaxbcommons.addon.tests;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.IteratorUtils;

public abstract class AbstractAddOnsTest extends AbstractXJCTest{
  
  public AbstractAddOnsTest() {
    super();
  }

  public AbstractAddOnsTest(String testName) {
    super(testName);
  }
  
  private AbstractXJCTest[] addOnTests;
  
  public void setUp() throws Exception {
    super.setUp();
    addOnTests = getAddOnTests();
    for (Iterator iterator = IteratorUtils.getIterator(addOnTests); iterator.hasNext();)
    {
      final AbstractXJCTest test = (AbstractXJCTest) iterator.next();
      test.setUp();
    }
  }
  
  public abstract AbstractXJCTest[] getAddOnTests();

  public List getAddonOptions() {
    final List addonOptions = new ArrayList();
    for (Iterator iterator = IteratorUtils.getIterator(addOnTests); iterator.hasNext();)
    {
      final AbstractXJCTest test = (AbstractXJCTest) iterator.next();
      addonOptions.addAll(test.getAddonOptions());
    }
    return addonOptions;
  }

}
