package org.jvnet.jaxbcommons.addon;

import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.support.AbstractXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public abstract class AbstractApplicationContextAwareCodeAugmenter
    extends
    AbstractParameterizableCodeAugmenter {

  private AbstractXmlApplicationContext applicationContext;

  private boolean dependencyCheck = true;

  public void setDependencyCheck(boolean dependencyCheck) {
    this.dependencyCheck = dependencyCheck;
  }

  public boolean isDependencyCheck() {
    return dependencyCheck;
  }

  public AbstractXmlApplicationContext getApplicationContext() {
    return applicationContext;
  }

  private String config;

  public String getConfig() {
    return config;
  }

  public void setConfig(String config) {
    this.config = config;
    applicationContext = new FileSystemXmlApplicationContext(new String[]{ config }, false);
    applicationContext.setClassLoader(getClass().getClassLoader());
    applicationContext.refresh();
    this.applicationContext.getBeanFactory().autowireBeanProperties(
        this,
        AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE,
        isDependencyCheck());
  }
}
