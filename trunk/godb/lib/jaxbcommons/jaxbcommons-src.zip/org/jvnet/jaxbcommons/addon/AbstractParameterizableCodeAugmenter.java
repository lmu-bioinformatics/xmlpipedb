package org.jvnet.jaxbcommons.addon;

import java.io.IOException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sun.tools.xjc.BadCommandLineException;
import com.sun.tools.xjc.CodeAugmenter;
import com.sun.tools.xjc.Options;

public abstract class AbstractParameterizableCodeAugmenter implements CodeAugmenter {

  protected Log logger = LogFactory.getLog(getClass());

  public int parseArgument(Options opt, String[] args, int start)
      throws BadCommandLineException,
      IOException {

    int consumed = 0;
    final String optionPrefix = "-" + getOptionName() + "-";
    final int optionPrefixLength = optionPrefix.length();

    final String arg = args[start];
    final int equalsPosition = arg.indexOf('=');

    if (arg.startsWith(optionPrefix) && equalsPosition > optionPrefixLength) {
      final String propertyName = arg.substring(optionPrefixLength, equalsPosition);

      final String value = arg.substring(equalsPosition + 1);
      consumed++;
      try {
        BeanUtils.setProperty(this, propertyName, value);
      }
      catch (Exception ex) {
        ex.printStackTrace();
        throw new BadCommandLineException("Error setting property ["
            + propertyName
            + "], value ["
            + value
            + "].");
      }
    }
    return consumed;
  }
}
