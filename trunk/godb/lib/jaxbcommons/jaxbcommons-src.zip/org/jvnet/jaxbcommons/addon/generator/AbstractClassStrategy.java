package org.jvnet.jaxbcommons.addon.generator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sun.codemodel.JClassAlreadyExistsException;
import com.sun.codemodel.JClassContainer;
import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JDefinedClass;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public abstract class AbstractClassStrategy implements IClassStrategy {

  protected static final Log logger = LogFactory.getLog(IClassStrategy.class);

  public JCodeModel getCodeModel(ClassContext classContext) {
    return classContext.ref.owner();
  }

  public JDefinedClass generate(
      ClassContext classContext,
      FieldItem fieldItem,
      JClassContainer container) {
    try {
      return generateInternal(classContext, fieldItem, container);
    }
    catch (JClassAlreadyExistsException jcaeex) {
      return jcaeex.getExistingClass();
    }
  }

  public abstract JDefinedClass generateInternal(
      ClassContext classContext,
      FieldItem fieldItem,
      JClassContainer container) throws JClassAlreadyExistsException;
}
