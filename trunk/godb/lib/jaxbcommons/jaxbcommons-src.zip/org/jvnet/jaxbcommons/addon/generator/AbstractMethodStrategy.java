package org.jvnet.jaxbcommons.addon.generator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sun.codemodel.JClass;
import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JPrimitiveType;
import com.sun.codemodel.JType;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;

/**
 * Abstract base class for method strategies.
 * @author valikov
 */
public abstract class AbstractMethodStrategy implements IMethodStrategy {
  
  protected Log logger = LogFactory.getLog(getClass());

  public FieldUse getFieldUse(ClassContext classContext, FieldItem fieldItem) {
    return classContext.target.getField(fieldItem.name);
  }

  public JType getType(ClassContext classContext, FieldItem fieldItem) {
    return getFieldUse(classContext, fieldItem).type;
  }

  public JClass getObjectType(ClassContext classContext, FieldItem fieldItem) {
    final FieldUse fieldUse = getFieldUse(classContext, fieldItem);
    return fieldUse.type.isPrimitive()
        ? ((JPrimitiveType) fieldUse.type).getWrapperClass()
        : (JClass) fieldUse.type;
  }

  public JClass getClass(ClassContext classContext, FieldItem fieldItem) {
    final JType type = getType(classContext, fieldItem);
    return type.isPrimitive() ? ((JPrimitiveType) type).getWrapperClass() : (JClass) type;
  }

  public JDefinedClass getDefinedClass(ClassContext classContext, FieldItem fieldItem) {
    return (JDefinedClass) getClass(classContext, fieldItem);
  }

  public JCodeModel getCodeModel(ClassContext classContext) {
    return classContext.ref.owner();
  }

}
