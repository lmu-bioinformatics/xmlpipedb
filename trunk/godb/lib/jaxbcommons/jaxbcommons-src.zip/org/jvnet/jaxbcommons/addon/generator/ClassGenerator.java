package org.jvnet.jaxbcommons.addon.generator;

import com.sun.codemodel.JClassAlreadyExistsException;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JFieldVar;
import com.sun.codemodel.JMethod;

/**
 * Base class for generators.
 * 
 * @author Aleksei Valikov
 */
public abstract class ClassGenerator {

    /**
     * Generated class.
     */
    protected JDefinedClass theClass;
    
    /**
     * Internal method for class generation.
     * 
     * @return Generated class.
     * @throws JClassAlreadyExistsException
     *             Thrown if class already exists.
     */
    protected abstract JDefinedClass generateClass()
            throws JClassAlreadyExistsException;

    /**
     * Generates fields.
     */
    protected abstract void generateFields();

    /**
     * Generates methods.
     */
    protected abstract void generateMethods();

    /**
     * Returns the generated (if required) and returns the generated class.
     * 
     * @return Generated class.
     */
    public JDefinedClass getGeneratedClass() {
        try {
            theClass = generateClass();
            generateFields();
            generateMethods();
            return theClass;
        } catch (JClassAlreadyExistsException jcaeex) {
            return jcaeex.getExistingClass();
        }
    }
}
