package org.jvnet.jaxbcommons.addon.generator;

import com.sun.codemodel.JClassAlreadyExistsException;
import com.sun.codemodel.JClassContainer;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JFieldVar;
import com.sun.codemodel.JMethod;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class ComposedClassStrategy extends AbstractClassStrategy {

  public static final IFieldStrategy[] NO_FIELDS = new IFieldStrategy[]{};
  public static final IMethodStrategy[] NO_METHODS = new IMethodStrategy[]{};

  private final IClassStrategy classStrategy;
  private final IFieldStrategy[] fieldStrategies;
  private final IMethodStrategy[] methodStrategies;

  public ComposedClassStrategy(
      IClassStrategy classStrategy,
      IFieldStrategy[] fieldStrategies,
      IMethodStrategy[] methodStrategies) {
    this.classStrategy = classStrategy;
    this.fieldStrategies = fieldStrategies;
    this.methodStrategies = methodStrategies;
  }

  public JDefinedClass generateInternal(
      ClassContext classContext,
      FieldItem fieldItem,
      JClassContainer container) throws JClassAlreadyExistsException {

    final JDefinedClass theClass = classStrategy.generateInternal(
        classContext,
        fieldItem,
        container);

    final JFieldVar[] fields = new JFieldVar[fieldStrategies.length];
    for (int index = 0; index < fieldStrategies.length; index++) {
      fields[index] = fieldStrategies[index].generate(classContext, fieldItem, theClass);
    }

    final JMethod[] methods = new JMethod[methodStrategies.length];
    for (int index = 0; index < methodStrategies.length; index++) {
      methods[index] = methodStrategies[index].generate(classContext, fieldItem, theClass);
    }
    return theClass;
  }
}
