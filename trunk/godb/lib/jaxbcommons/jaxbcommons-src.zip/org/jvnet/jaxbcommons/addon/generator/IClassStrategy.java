package org.jvnet.jaxbcommons.addon.generator;

import com.sun.codemodel.JClassAlreadyExistsException;
import com.sun.codemodel.JClassContainer;
import com.sun.codemodel.JDefinedClass;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public interface IClassStrategy {

  public JDefinedClass generate(ClassContext classContext, FieldItem fieldItem, JClassContainer container);
  public JDefinedClass generateInternal(ClassContext classContext, FieldItem fieldItem, JClassContainer container) throws JClassAlreadyExistsException;
  
}
