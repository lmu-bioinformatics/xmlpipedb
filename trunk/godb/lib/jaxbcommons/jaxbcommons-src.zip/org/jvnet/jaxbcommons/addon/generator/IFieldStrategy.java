package org.jvnet.jaxbcommons.addon.generator;

import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JFieldVar;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public interface IFieldStrategy {
  
  public JFieldVar generate(ClassContext classContext, FieldItem fieldItem, JDefinedClass theClass);
}
