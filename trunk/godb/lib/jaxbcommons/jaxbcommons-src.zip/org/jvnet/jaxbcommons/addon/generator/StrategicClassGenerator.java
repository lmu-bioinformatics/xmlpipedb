/*
 * Created on 28.06.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.jvnet.jaxbcommons.addon.generator;

import com.sun.codemodel.JClassAlreadyExistsException;
import com.sun.codemodel.JClassContainer;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JFieldVar;
import com.sun.codemodel.JMethod;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

/**
 * 
 * @author valikov
 */
public class StrategicClassGenerator extends ClassGenerator{
  
  public static final IFieldStrategy[] NO_FIELDS = new IFieldStrategy[]{};
  public static final IMethodStrategy[] NO_METHODS= new IMethodStrategy[]{};
  
  private final ClassContext classContext;
  private final FieldItem fieldItem;
  private final JClassContainer container;
  private final IClassStrategy classStrategy;
  private final IFieldStrategy[] fieldStrategies;
  private final IMethodStrategy[] methodStrategies;

  public StrategicClassGenerator(
      ClassContext classContext,
      FieldItem fieldItem,
      JClassContainer container,
      IClassStrategy classStrategy,
      IFieldStrategy[] fieldStrategies,
      IMethodStrategy[] methodStrategies) {
        this.classContext = classContext;
        this.fieldItem = fieldItem;
        this.container = container;
        this.classStrategy = classStrategy;
        this.fieldStrategies = fieldStrategies;
        this.methodStrategies = methodStrategies;
  }
  
  protected JDefinedClass generateClass() throws JClassAlreadyExistsException {
    return classStrategy.generate(classContext, fieldItem, container);
  }
  
  protected void generateFields() {
    final JFieldVar[] fields = new JFieldVar[fieldStrategies.length];
    for (int index = 0; index < fieldStrategies.length; index++)
    {
      fields[index] = fieldStrategies[index].generate(classContext, fieldItem, theClass);
    }
//    return fields;
  }
  
  protected void generateMethods() {
    final JMethod[] methods = new JMethod[methodStrategies.length];
    for (int index = 0; index < methodStrategies.length; index++)
    {
      methods[index] = methodStrategies[index].generate(classContext, fieldItem, theClass);
    }
//    return methods;
  }
  

}
