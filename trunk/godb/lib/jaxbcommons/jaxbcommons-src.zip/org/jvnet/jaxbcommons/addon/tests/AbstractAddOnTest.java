package org.jvnet.jaxbcommons.addon.tests;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;


import com.sun.tools.xjc.CodeAugmenter;

/**
 * Abstract test for add-ons.
 * 
 * @author Aleksei Valikov
 */
public abstract class AbstractAddOnTest extends AbstractXJCTest {
  protected CodeAugmenter addOn;
  
  protected AbstractAddOnTest() {
    super();
  }

  protected AbstractAddOnTest(String testName) {
    super(testName);
  }
  
  /**
   * Test setup.
   * 
   * @throws Exception
   *             In case of setup problems.
   */
  public void setUp() throws Exception {
    super.setUp();
    addOn = newAddOn();
  }

  /**
   * Returns a string array of add-on command-line options.
   * 
   * @return Command-line options for the add-on.
   */
  public List getAddonOptions()
  {
    final List addonOptions = new ArrayList();
    addonOptions.add("-" + addOn.getOptionName());
    return addonOptions;
  }
  
  /**
   * Returns the add-on to be tested.
   * @return Add-on to be tested.
   */
  protected abstract CodeAugmenter newAddOn();
}
