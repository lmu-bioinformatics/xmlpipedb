package org.jvnet.jaxbcommons.addon.tests;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.SuffixFileFilter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sun.tools.xjc.Driver;

public abstract class AbstractXJCTest extends TestCase{
  
  private final String testName;
  private final File baseDir;
  
  public String getTestName()
  {
    return testName;
  }
  
  protected AbstractXJCTest()
  {
    testName = null;
    baseDir = new File(".");
  }
  
  protected AbstractXJCTest(String testName)
  {
    this.testName = testName;
    baseDir = new File("tests", testName);
  }

  public abstract List getAddonOptions();

  /**
   * Logger.
   */
  protected Log log = LogFactory.getLog(AbstractAddOnTest.class);
  
  public void setUp() throws Exception {
    super.setUp();
  }

  /**
   * Returns command-line arguments for XJC invocation. This array will be
   * constructed of what {@link #getOptions()},{@link #getBindingOptions()},
   * {@link #getAddonOptions()}and {@link #getSchemaOptions()}return.
   * 
   * @return Command-line arguments for XJC invocation.
   */
  public String[] getArguments() {
    final List args = new ArrayList();
    
    args.addAll(getOptions());
    args.addAll(getBindingOptions());
    if (isDebug())
      args.add("-debug");
    if (isNv())
      args.add("-nv");
    if (isExtension())
      args.add("-extension");
    args.addAll(getAddonOptions());
    args.addAll(getSchemaOptions());
    
    return (String[]) args.toArray(new String[]{});
  }

  /**
   * Returns command-line options for the add-on.
   * 
   * @return Command line options for the add-on.
   */
  public List getOptions() {
    return Arrays.asList(new String[]{ "-d", getGeneratedSourcesDir().getAbsolutePath() });
  }

  protected boolean isDebug() {
    return true;
  }

  protected boolean isNv() {
    return true;
  }

  protected boolean isExtension() {
    return true;
  }

  /**
   * Returns schema options.
   * 
   * @return Schema options.
   */
  public List getSchemaOptions() {
    final File[] schemaFiles = getSchemaFiles();
    final List schemaOptions = new ArrayList(schemaFiles.length);
    for (int index = 0; index < schemaFiles.length; index++) {
      final File schemaFile = schemaFiles[index];
      schemaOptions.add(schemaFile.getAbsolutePath());
    }
    return schemaOptions;
  }

  /**
   * Returns schema directory.
   * @return Schema directory.
   */
  public File getSchemaDirectory() {
    return new File(getBaseDir(), "schema");
  }

  /**
   * Returns an array of schema files.
   * 
   * @return Array of schema files.
   */
  public File[] getSchemaFiles() {
    final Collection schemaFiles = FileUtils.listFiles(getSchemaDirectory(), new String[]{"xsd"}, true);
    return (File[]) schemaFiles.toArray(new File[schemaFiles.size()]);
  }

  /**
   * Returns binding directory.
   * @return Binding directory.
   */
  public File getBindingDirectory() {
  return new File(getBaseDir(), "binding");
  }

  /**
   * Returns an array of binding files.
   * 
   * @return An array of binding files.
   */
  public File[] getBindingFiles() {
    final FileFilter fileFilter = new SuffixFileFilter(".xml");
    return getBindingDirectory().listFiles(fileFilter);
  }

  /**
   * Binding options.
   * 
   * @return Binding options.
   */
  public List getBindingOptions() {
    final File[] bindingFiles = getBindingFiles();
    final List bindingOptions = new ArrayList();
    if (null != bindingFiles && bindingFiles.length > 0) {
      bindingOptions.add("-b");
      for (int index = 0; index < bindingFiles.length; index++) {
        final File bindingFile = bindingFiles[index];
        bindingOptions.add(bindingFile.getAbsolutePath());
      }
    }
    return bindingOptions;
  }

  /**
   * Directory where the sources will be generated.
   * 
   * @return "Generated sources" directory.
   */
  public File getGeneratedSourcesDir() {
    final File generatedSourcesDir = new File(getBaseDir(), "generated.src");
    if (!generatedSourcesDir.exists()) {
      generatedSourcesDir.mkdirs();
    }
    return generatedSourcesDir;
  }

  /**
   * Runs the test.
   * 
   * @throws Exception
   *             In case a problem occurs during running the test.
   */
  public void testRun() throws Exception {
    try {
      Driver.run(getArguments(), System.out, System.err);
    }
    catch (Exception ex) {
      ex.printStackTrace();
      throw ex;
    }
  }
  
  public File getBaseDir()
  {
    return baseDir;
  }
}
