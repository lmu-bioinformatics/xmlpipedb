package org.jvnet.jaxbcommons.addon.tests;

public class AddOnsTest extends AbstractAddOnsTest {

  private final AbstractXJCTest[] addOnTests = new AbstractXJCTest[]{
      new org.jvnet.jaxbcommons.enums.addon.tests.AddOnTest(),
      new org.jvnet.jaxbcommons.equals.addon.tests.AddOnTest(),
      new org.jvnet.jaxbcommons.hashcode.addon.tests.AddOnTest(),
      new org.jvnet.jaxbcommons.i18n.addon.tests.AddOnTest() };

  public AddOnsTest() {
    super();
  }

  public AddOnsTest(String testName) {
    super(testName);
  }

  public AbstractXJCTest[] getAddOnTests() {
    return addOnTests;
  }
}
