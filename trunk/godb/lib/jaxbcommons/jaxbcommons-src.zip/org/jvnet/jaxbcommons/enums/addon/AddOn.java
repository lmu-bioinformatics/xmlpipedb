package org.jvnet.jaxbcommons.enums.addon;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jvnet.jaxbcommons.addon.generator.IMethodStrategy;
import org.jvnet.jaxbcommons.enums.addon.generator.GetEnumMapStrategy;
import org.jvnet.jaxbcommons.enums.addon.generator.ValuesStrategy;
import org.jvnet.jaxbcommons.util.TypeUtils;
import org.jvnet.jaxbcommons.visitor.ClassifyingVisitor;
import org.xml.sax.ErrorHandler;

import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JType;
import com.sun.tools.xjc.BadCommandLineException;
import com.sun.tools.xjc.CodeAugmenter;
import com.sun.tools.xjc.Options;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.grammar.AnnotatedGrammar;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.TypeItem;

/**
 * Add-on to generate <code>public static &lt;Type&gt;[] values();</code> and 
 * <code>public static Map&lt;String,&lt;Type&gt;&gt; getEnumMap();</code> methods.
 * 
 * @author Aleksei Valikov
 */
public class AddOn implements CodeAugmenter {

  /**
   * Logger.
   */
  protected Log logger = LogFactory.getLog(AddOn.class);

  /**
   * Does nothing.
   *
   * @param opt  ignored.
   * @param args ignored.
   * @param i    ignored.
   * @return Alway returns <code>0</code>.
   * @throws com.sun.tools.xjc.BadCommandLineException
   *                             Never thrown.
   * @throws java.io.IOException Never thrown.
   */
  public int parseArgument(final Options opt, final String[] args, final int i)
      throws BadCommandLineException,
      IOException {
    return 0; // no option recognized
  }

  public String getOptionName() {
    return "Xenums";
  }

  public String getUsage() {
    return "  -Xenums                      :  adds values() and getEnumMap() methods to the generated enum classes";
  }

  /**
   * Augments the code.
   *
   * @param grammar          annotated grammar.
   * @param generatorContext generator context.
   * @param options          options.
   * @param errorHandler     error handler.
   * @return If the add-on executes successfully, return true. If it detects some errors but those are reported and
   *         recovered gracefully, return false.
   */
  public boolean run(
      final AnnotatedGrammar grammar,
      final GeneratorContext generatorContext,
      final Options options,
      final ErrorHandler errorHandler) {

    // Process class items
    final ClassItem[] classItems = grammar.getClasses();
    for (int index = 0; index < classItems.length; index++) {
      final ClassItem classItem = classItems[index];
      final ClassContext classContext = generatorContext.getClassContext(classItem);

      classItem.visit(new ClassifyingVisitor(classContext) {
        public Object onEnumCollectionField(com.sun.tools.xjc.grammar.FieldItem fieldItem) {
          onEnumField(classContext, fieldItem);
          return null;
        }

        public Object onEnumSingleField(com.sun.tools.xjc.grammar.FieldItem fieldItem) {
          onEnumField(classContext, fieldItem);
          return null;
        }

      });
    }
    return true;
  }

  protected IMethodStrategy valuesStrategy = new ValuesStrategy();

  public IMethodStrategy getValuesStrategy() {
    return valuesStrategy;
  }

  public void setValuesStrategy(IMethodStrategy valuesStrategy) {
    this.valuesStrategy = valuesStrategy;
  }

  protected IMethodStrategy getEnumMapStrategy = new GetEnumMapStrategy();

  public IMethodStrategy getGetEnumMapStrategy() {
    return getEnumMapStrategy;
  }

  public void setGetEnumMapStrategy(IMethodStrategy getEnumMapStrategy) {
    this.getEnumMapStrategy = getEnumMapStrategy;
  }

  protected void onEnumField(ClassContext classContext, FieldItem fieldItem) {
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);
    final JType type = typeItem.getType();
    final JDefinedClass theClass = (JDefinedClass) type;
    logger.trace("Augmenting enum class [" + theClass.fullName() + "].");
    getValuesStrategy().generate(classContext, fieldItem, theClass);
    getGetEnumMapStrategy().generate(classContext, fieldItem, theClass);
  }
}