package org.jvnet.jaxbcommons.enums.addon.generator;

import java.util.HashMap;
import java.util.Map;

import org.jvnet.jaxbcommons.addon.generator.AbstractMethodStrategy;

import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JExpr;
import com.sun.codemodel.JMethod;
import com.sun.codemodel.JMod;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class GetEnumMapStrategy extends AbstractMethodStrategy{

  private final Map processedClassesMap = new HashMap();

  public JMethod generate(ClassContext classContext, FieldItem fieldItem, JDefinedClass theClass) {

    if (processedClassesMap.keySet().contains(theClass)) {
      return (JMethod) processedClassesMap.get(theClass);
    }
    else {
      
      final JMethod getEnumMap = theClass.method(JMod.PUBLIC|JMod.STATIC, Map.class, "getEnumMap" );
      getEnumMap.body()._return(JExpr.ref("valueMap"));
      processedClassesMap.put(theClass, getEnumMap);
      return getEnumMap;
    }
  }
}
