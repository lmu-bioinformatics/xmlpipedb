package org.jvnet.jaxbcommons.enums.addon.generator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jvnet.jaxbcommons.addon.generator.AbstractMethodStrategy;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JExpr;
import com.sun.codemodel.JMethod;
import com.sun.codemodel.JMod;
import com.sun.codemodel.JOp;
import com.sun.codemodel.JVar;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class ValuesStrategy extends AbstractMethodStrategy {

  private final Map processedClassesMap = new HashMap();

  public JMethod generate(ClassContext classContext, FieldItem fieldItem, JDefinedClass theClass) {

    if (processedClassesMap.keySet().contains(theClass)) {
      return (JMethod) processedClassesMap.get(theClass);

    }
    else {
      final JCodeModel codeModel = getCodeModel(classContext);

      final JVar $values = theClass.field(JMod.PRIVATE | JMod.STATIC, List.class, "values");

      final JMethod constructor = (JMethod) theClass.constructors().next();
      constructor.body()._if(JOp.eq($values, JExpr._null()))._then().assign(
          $values,
          JExpr._new(codeModel.ref(ArrayList.class)));

      constructor.body().invoke($values, "add").arg(JExpr._this());

      final JMethod values = theClass.method(JMod.PUBLIC | JMod.STATIC, theClass.array(), "values");
      values.body()._return(
          JExpr.cast(theClass.array(), $values.invoke("toArray").arg(JExpr.newArray(theClass, 0))));
      processedClassesMap.put(theClass, values);
      return values;
    }
  }
}
