/*
 * Created on 28.06.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.jvnet.jaxbcommons.equals.addon.generator;

import java.util.Arrays;
import java.util.Calendar;

import org.jvnet.jaxbcommons.addon.generator.AbstractMethodStrategy;
import org.jvnet.jaxbcommons.util.AccessorUtils;
import org.jvnet.jaxbcommons.util.FieldUtils;

import com.sun.codemodel.JBlock;
import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JConditional;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JExpr;
import com.sun.codemodel.JMethod;
import com.sun.codemodel.JMod;
import com.sun.codemodel.JOp;
import com.sun.codemodel.JVar;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;

/**
 * 
 * @author valikov
 */
public class EqualsStrategy extends AbstractMethodStrategy {

  public JMethod generate(ClassContext classContext, FieldItem fieldItem, JDefinedClass theClass) {

    final JMethod equals = classContext.implClass.method(
        JMod.PUBLIC,
        getCodeModel(classContext).BOOLEAN,
        "equals");
    final JVar obj = equals.param(Object.class, "obj");

    final JConditional ifThisEqObj = equals.body()._if(JOp.eq(JExpr._this(), obj));
    ifThisEqObj._then()._return(JExpr.TRUE);

    final JConditional ifWrongObj = equals.body()._if(
        JOp.cor(JOp.eq(JExpr._null(), obj), JOp.not(JOp._instanceof(obj,classContext.ref))));

    ifWrongObj._then()._return(JExpr.FALSE);
    final JVar target = equals.body().decl(
        classContext.implClass,
        "target",
        JExpr.cast(classContext.implClass, obj));

    for (ClassItem item = classContext.target; item != null; item = item.getSuperClass()) {
      final ClassContext context = classContext.parent.getClassContext(item);
      generateFieldsEquality(context, equals.body(), target);
    }

    equals.body()._return(JExpr.TRUE);
    return equals;
  }

  /**
   * Generates field equality check instructions.
   *
   * @param classContext class context.
   * @param methodBody   method body.
   * @param target       target variable.
   */
  protected void generateFieldsEquality(
      final ClassContext classContext,
      final JBlock methodBody,
      final JVar target) {
    final FieldUse[] fieldUses = classContext.target.getDeclaredFieldUses();
    // Iterate over field uses
    for (int index = 0; index < fieldUses.length; index++) {
      final FieldUse fieldUse = fieldUses[index];
      final FieldItem fieldItem = FieldUtils.getFieldItem(fieldUse);
      final JMethod getter = AccessorUtils.get(classContext, fieldItem);
      if (getter != null) {
        final JBlock block = methodBody.block();
        final JVar value = block.decl(getter.type(), "value", JExpr._this().invoke(getter));
        final JVar targetValue = block.decl(getter.type(), "targetValue", target.invoke(getter));
        valuesEqual(getCodeModel(classContext), block, value, targetValue);
      }
    }
  }

  /**
   * Generates expression checking equality of two values.
   *
   * @param codeModel code model.
   * @param value value.
   * @param targetValue target value.
   */
  protected void valuesEqual(
      JCodeModel codeModel,
      final JBlock block,
      final JVar value,
      final JVar targetValue) {

    if (value.type().isArray()) {
      final JConditional ifValuesNotEqual = block._if(JOp.not(codeModel
          .ref(Arrays.class)
          .staticInvoke("equals")
          .arg(value)
          .arg(targetValue)));
      ifValuesNotEqual._then()._return(JExpr.FALSE);
    }
    else if (value.type().isPrimitive()) {
      final JConditional ifValuesNotEqual = block._if(JOp.ne(value, targetValue));
      ifValuesNotEqual._then()._return(JExpr.FALSE);
    }
    else if (value.type() == codeModel.ref(Calendar.class)) {
      final JConditional ifValuesNotEqual = block._if(JOp.not(JOp.cor(
          JOp.eq(value, targetValue),
          JOp.cand(JOp.ne(value, JExpr._null()),

          JOp.eq(value.invoke("getTime").invoke("getTime"), targetValue.invoke("getTime").invoke(
              "getTime"))))));
      ifValuesNotEqual._then()._return(JExpr.FALSE);
    }
    else {
      final JConditional ifValuesNotEqual = block._if(JOp.not(JOp.cor(
          JOp.eq(value, targetValue),
          JOp.cand(JOp.ne(value, JExpr._null()), value.invoke("equals").arg(targetValue)))));
      ifValuesNotEqual._then()._return(JExpr.FALSE);
    }
  }

}
