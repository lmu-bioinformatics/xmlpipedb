package org.jvnet.jaxbcommons.equals.addon.tests;

import org.jvnet.jaxbcommons.addon.tests.AbstractAddOnTest;
import org.jvnet.jaxbcommons.equals.addon.AddOn;

import com.sun.tools.xjc.CodeAugmenter;

public class AddOnTest extends AbstractAddOnTest {
  
  public AddOnTest() {
    super();
  }

  public AddOnTest(String testName) {
    super(testName);
  }
  
  protected CodeAugmenter newAddOn() {
    return new AddOn();
  }
}
