package org.jvnet.jaxbcommons.i18n.addon;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jvnet.jaxbcommons.util.EnumUtils;
import org.jvnet.jaxbcommons.util.FieldUtils;
import org.xml.sax.ErrorHandler;

import com.sun.codemodel.JDefinedClass;
import com.sun.msv.datatype.xsd.XSDatatype;
import com.sun.msv.grammar.ValueExp;
import com.sun.tools.xjc.BadCommandLineException;
import com.sun.tools.xjc.CodeAugmenter;
import com.sun.tools.xjc.Options;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.grammar.AnnotatedGrammar;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;

/**
 * This add-on generates property files base on class, field and enum
 * names.
 * 
 * @author valikov
 */
public class AddOn implements CodeAugmenter {

  /** Logger. */
  public final Log logger = LogFactory.getLog(getClass());

  /** Option name. */
  public static final String OPTION_NAME = "Xi18n";
  /** Locale option name. */
  public static final String LOCALE_OPTION_NAME = "-Xi18n-locale";
  /** Import properties option name. */
  public static final String IMPORT_PROPERTIES_OPTION_NAME = "-Xi18n-import-properties";
  /** Export properties option name. */
  public static final String EXPORT_PROPERTIES_OPTION_NAME = "-Xi18n-export-properties";

  private Set locales = new HashSet();

  private Map importedProperties = new HashMap();
  private Map lowercaseImportedProperties = new HashMap();
  private Map exportedProperties = new HashMap();
  private Map lowercaseExportedProperties = new HashMap();

  private File importDirectory;
  private String importName;
  private File exportDirectory;
  private String exportName;

  public String getOptionName() {
    return OPTION_NAME;
  }

  public String getUsage() {
    return "";
  }

  private String afterEquals(String str) {
    return str.substring(str.indexOf('=') + 1);
  }

  public int parseArgument(Options options, String[] args, int start)
      throws BadCommandLineException,
      IOException {

    if (start >= args.length)
      return 0;

    final String arg = args[start];
    final String value = afterEquals(arg);
    if (arg.startsWith(LOCALE_OPTION_NAME)) {
      final Locale locale = parseLocale(value);
      logger.info(MessageFormat.format("Adding locale [{0}].", new Object[]{ locale }));
      locales.add(locale);
      return 1 + parseArgument(options, args, start + 1);
    }
    else if (arg.startsWith(IMPORT_PROPERTIES_OPTION_NAME)) {
      final File file = new File(value);
      importDirectory = file.getParentFile();
      importName = file.getName();

      logger.info(MessageFormat.format(
          "Importing properties with name [{0}] from the directory [{1}].",
          new Object[]{ importName, importDirectory.getAbsolutePath() }));

      return 1 + parseArgument(options, args, start + 1);
    }
    else if (arg.startsWith(EXPORT_PROPERTIES_OPTION_NAME)) {
      final File file = new File(value);
      exportDirectory = file.getParentFile();
      exportName = file.getName();
      logger.info(MessageFormat.format(
          "Exporting properties with name [{0}] to the directory [{1}].",
          new Object[]{ exportName, exportDirectory.getAbsolutePath() }));
      return 1 + parseArgument(options, args, start + 1);
    }
    else {
      return 0;
    }
  }

  /**
   * Parses locale code given as string.
   * @param string locale code.
   * @return Parsed locale.
   */
  private Locale parseLocale(String string) {
    final StringTokenizer tokens = new StringTokenizer(string, "_");
    final String language = tokens.hasMoreTokens() ? tokens.nextToken() : "";
    final String country = tokens.hasMoreTokens() ? tokens.nextToken() : "";
    String variant = "";
    String sep = "";
    while (tokens.hasMoreTokens()) {
      variant += sep + tokens.nextToken();
      sep = "_";
    }
    return new Locale(language, country, variant);
  }

  public boolean run(
      AnnotatedGrammar grammar,
      GeneratorContext context,
      Options options,
      ErrorHandler errorHandler) {

    for (final Iterator iterator = locales.iterator(); iterator.hasNext();) {
      final Locale locale = (Locale) iterator.next();
      final String l = locale.toString();

      if (importDirectory != null && importName != null) {
        final String name = importName + "_" + l + ".properties";
        final File file = new File(importDirectory, name);
        if (file.isFile()) {

          logger.info(MessageFormat.format("Loading properties from [{0}].", new Object[]{ file
              .getAbsolutePath() }));
          try {
            final Properties properties = new Properties();
            properties.load(new FileInputStream(file));

            final Properties lowercaseProperties = new Properties();
            for (Iterator i = properties.entrySet().iterator(); i.hasNext();) {
              final Map.Entry entry = (Map.Entry) i.next();
              lowercaseProperties.setProperty(
                  ((String) entry.getKey()).toLowerCase(locale),
                  (String) entry.getValue());
            }
            importedProperties.put(l, properties);
            lowercaseImportedProperties.put(l, lowercaseProperties);
          }
          catch (IOException ioex) {
            logger.error("Error loading properties.", ioex);
            importedProperties.put(l, new Properties());
            lowercaseImportedProperties.put(l, new Properties());
          }
        }
        else {
          logger.warn(MessageFormat.format("[{0}] is not a file. Ignoring.", new Object[]{ file
              .getAbsolutePath() }));
          importedProperties.put(l, new Properties());
          lowercaseImportedProperties.put(l, new Properties());
        }
      }
      exportedProperties.put(l, new Properties());
      lowercaseExportedProperties.put(l, new Properties());
      
    }

    final ClassItem[] classes = grammar.getClasses();
    for (int index = 0; index < classes.length; index++) {
      final ClassItem classItem = classes[index];
      final ClassContext classContext = context.getClassContext(classItem);
      setProperty(classItem.getTypeAsDefined().fullName(), "@@TODO."
          + classItem.getTypeAsDefined().name()
          + "@@");

      final FieldUse[] fields = classItem.getDeclaredFieldUses();
      for (int jndex = 0; jndex < fields.length; jndex++) {
        final FieldUse fieldUse = fields[jndex];
        setProperty(fieldUse.owner.getType().fullName() + "." + fieldUse.name, "@@TODO."
            + fieldUse.name
            + "@@");

        if (fieldUse.type instanceof JDefinedClass
            && null == grammar.getClassItem((JDefinedClass) fieldUse.type)) {

          final JDefinedClass enumClass = (JDefinedClass) fieldUse.type;
          final FieldItem fieldItem = FieldUtils.getFieldItem(fieldUse);

          final Collection enumValues = EnumUtils.getValues(classContext, fieldItem);

          // TODO: biconversion
          if (enumValues != null) {
            for (Iterator iterator = enumValues.iterator(); iterator.hasNext();) {
              final ValueExp enumValue = (ValueExp) iterator.next();

              final String lexical;
              if (enumValue.dt instanceof XSDatatype)
                lexical = ((XSDatatype) enumValue.dt).convertToLexicalValue(enumValue.value, null);
              else
                lexical = enumValue.value.toString();
              setProperty(enumClass.fullName() + "." + lexical, "@@TODO." + lexical + "@@");

            }
          }
        }
      }
    }

    for (final Iterator iterator = locales.iterator(); iterator.hasNext();) {
      final Locale locale = (Locale) iterator.next();
      final String l = locale.toString();
      final Properties imp = (Properties) importedProperties.get(l);
      final Properties exp = (Properties) exportedProperties.get(l);
      final Properties lexp = (Properties) lowercaseExportedProperties.get(l);

      for (final Enumeration names = imp.propertyNames(); names.hasMoreElements();) {
        final String key = (String) names.nextElement();
        if (!lexp.containsKey(key.toLowerCase(locale))) {
          final String value = imp.getProperty(key);
          logger.trace(MessageFormat.format("{0}={1}[{2}]", new Object[]{ key, value, l }));
          exp.setProperty(key, value);
          lexp.setProperty(key.toLowerCase(locale), value);
        }
      }
    }

    for (final Iterator iterator = locales.iterator(); iterator.hasNext();) {
      final Locale locale = (Locale) iterator.next();
      final String l = locale.toString();
      final Properties exp = (Properties) exportedProperties.get(l);

      if (exportDirectory != null && exportName != null) {

        if (!exportDirectory.exists()) {
          logger.info(MessageFormat.format(
              "Export directory [{0}] does not exist. Creating.",
              new Object[]{ exportDirectory.getAbsolutePath() }));
          exportDirectory.mkdirs();
        }

        if (exportDirectory.isDirectory()) {
          final String name = exportName + "_" + l + ".properties";
          final File file = new File(exportDirectory, name);
          try {
            exp.store(new FileOutputStream(file), null);
          }
          catch (IOException ioex) {
            logger.error("Error storing properties.", ioex);
          }
        }
        else {
          logger.error(MessageFormat.format(
              "Export directory [{0}] is not a directory. Unable to export",
              new Object[]{ exportDirectory.getAbsolutePath() }));
        }
      }
    }
    return true;
  }

  protected void setProperty(String name, String value) {
    for (final Iterator iterator = locales.iterator(); iterator.hasNext();) {
      final Locale locale = (Locale) iterator.next();
      setProperty(name, value, locale);
    }
  }

  protected void setProperty(String name, String draft, Locale locale) {
    final String l = locale.toString();
    final Properties imp = (Properties) lowercaseImportedProperties.get(l);
    final Properties exp = (Properties) exportedProperties.get(l);
    final Properties lexp = (Properties) lowercaseExportedProperties.get(l);
    final String value = imp.getProperty(name.toLowerCase(locale), draft);
    logger.trace(MessageFormat.format("{0}={1}[{2}]", new Object[]{ name, value, l }));
    exp.setProperty(name, value);
    lexp.setProperty(name.toLowerCase(), value);
  }
}
