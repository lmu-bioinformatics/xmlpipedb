package org.jvnet.jaxbcommons.i18n.addon.tests;

import java.io.File;
import java.util.List;

import org.jvnet.jaxbcommons.addon.tests.AbstractAddOnTest;
import org.jvnet.jaxbcommons.i18n.addon.AddOn;



import com.sun.tools.xjc.CodeAugmenter;


/**
 * Add-on test.
 * 
 * @author valikov
 */
public class AddOnTest extends AbstractAddOnTest {
  
  public AddOnTest() {
    super();
  }

  public AddOnTest(String testName) {
    super(testName);
  }
  
  protected CodeAugmenter newAddOn() {
    return new AddOn();
  }

  public List getAddonOptions() {
    final List options = super.getAddonOptions();
    options.add("-Xi18n-locale=en");
    options.add("-Xi18n-locale=de");
    options.add("-Xi18n-import-properties=" + getImportPropertiesFile().getAbsolutePath());
    options.add("-Xi18n-export-properties=" + getExportPropertiesFile().getAbsolutePath());
    return options;
  }

  protected File getImportPropertiesFile() {
    return new File(new File(getBaseDir(), "i18n"), "import.messages");
  }

  protected File getExportPropertiesFile() {
    return new File(new File(getBaseDir(), "i18n"), "messages");
  }
}
