package org.jvnet.jaxbcommons.locator;

import com.sun.xml.bind.ValidationEventLocatorEx;

public interface IFieldObjectLocator extends IObjectLocator, ValidationEventLocatorEx{

}
