package org.jvnet.jaxbcommons.locator;

public interface IListEntryObjectLocator extends IObjectLocator{
  
  public int getIndex();

}
