package org.jvnet.jaxbcommons.locator;

import javax.xml.bind.ValidationEventLocator;

import org.jvnet.jaxbcommons.i18n.IReportable;

public interface IObjectLocator extends ValidationEventLocator, IReportable{

  public IObjectLocator getParentLocator();
  
  public IObjectLocator[] getPath();
}
