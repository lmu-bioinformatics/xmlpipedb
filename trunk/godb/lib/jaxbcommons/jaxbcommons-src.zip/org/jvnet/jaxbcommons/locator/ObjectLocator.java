package org.jvnet.jaxbcommons.locator;

import java.net.URL;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.w3c.dom.Node;

/**
 * Abstract base class for event locators.
 * @author Aleksei Valikov
 */
public class ObjectLocator implements IObjectLocator {
  /**
   * Parent locator.
   */
  protected final IObjectLocator parentLocator;
  /**
   * Object.
   */
  protected final Object object;

  /**
   * Constructs a new validation event locator.
   *
   * @param parentLocator parent location (may be <code>null</code>).
   * @param object        object.
   * @param fieldName     field name.
   */
  protected ObjectLocator(final IObjectLocator parentLocator, final Object object) {
    this.object = object;
    this.parentLocator = parentLocator;
  }

  /**
   * Returns parent locator.
   *
   * @return Parent locator.
   */
  public IObjectLocator getParentLocator() {
    return parentLocator;
  }

  public IObjectLocator[] getPath() {
    final IObjectLocator[] path = new IObjectLocator[getAncestorCount(this) + 1];
    fillPath(this, path, path.length - 1);
    return path;
  }

  private void fillPath(IObjectLocator locator, IObjectLocator[] path, int index) {
    path[index] = locator;
    final IObjectLocator parent = locator.getParentLocator();
    if (parent != null)
      fillPath(parent, path, index - 1);
  }

  private int getAncestorCount(IObjectLocator locator) {
    final IObjectLocator parent = locator.getParentLocator();
    if (parent == null)
      return 0;
    else
      return 1 + getAncestorCount(parent);
  }

  public Object getObject() {
    return object;
  }

  public int getColumnNumber() {
    return 0;
  }

  public int getLineNumber() {
    return 0;
  }

  public int getOffset() {
    return 0;
  }

  public URL getURL() {
    return null;
  }

  public Node getNode() {
    return null;
  }

  //  /**
  //   * Returns expression step (for EL and JXPath expressions).
  //   * @return Expression step.
  //   */
  //  public abstract String getStep();

  public String toString() {
    return getMessage();
  }

  /**
   * Returns message code.
   *
   * @return Message code.
   */
  public String getMessageCode() {
    return getClass().getName();
  }

  public Object[] getMessageParameters() {
    return new Object[]{ getObject() };
  }

  public String getMessage(ResourceBundle bundle) {
    try {
      final String messageTemplate = bundle.getString(getMessageCode());
      return MessageFormat.format(messageTemplate, getMessageParameters());
    }
    catch (MissingResourceException mrex) {
      return MessageFormat.format("Object: {0}.", getMessageParameters());
    }
  }

  /**
   * Returns location message.
   *
   * @return Location message.
   */
  public String getMessage() {
    return getMessage(ResourceBundle.getBundle(getClass().getPackage().getName() + ".messages"));
  }

  public int hashCode() {
    int hashCode = getObject().hashCode();
    return hashCode;
  }
}
