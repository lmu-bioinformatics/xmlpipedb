package org.jvnet.jaxbcommons.tests;

import javax.xml.bind.JAXBContext;

public abstract class AbstractPackagedSamplesTest extends AbstractSamplesTest {

  private String packageNames;

  protected AbstractPackagedSamplesTest(String packageNames) {
    super();
    this.packageNames = packageNames;
  }

  protected AbstractPackagedSamplesTest(String testName, String packageNames) {
    super(testName);
    this.packageNames = packageNames;
  }

  protected String getPackageNames() {
    return packageNames;
  }

  protected JAXBContext createContext() throws Exception {
    return JAXBContext.newInstance(getPackageNames());
  }
}