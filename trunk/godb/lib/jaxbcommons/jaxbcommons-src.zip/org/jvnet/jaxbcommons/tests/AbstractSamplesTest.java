package org.jvnet.jaxbcommons.tests;

import java.io.File;
import java.util.Collection;

import javax.xml.bind.JAXBContext;

import junit.framework.TestCase;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class AbstractSamplesTest extends TestCase {

  protected Log logger = LogFactory.getLog(getClass());
  public static final String DEFAULT_SAMPLES_DIRECTORY_NAME = "samples";
  //  public static final FileFilter DEFAULT_SAMPLES_FILE_FILTER = new SuffixFileFilter(".xml");

  private final File samplesDirectory;

  protected String getSamplesDirectoryName() {
    return DEFAULT_SAMPLES_DIRECTORY_NAME;
  }

  private final String testName;
  private final File baseDir;

  protected AbstractSamplesTest() {
    testName = null;
    baseDir = new File(".");
    samplesDirectory = new File(getBaseDir(), getSamplesDirectoryName());
  }

  protected AbstractSamplesTest(String testName) {
    this.testName = testName;
    baseDir = new File("tests", testName);
    samplesDirectory = new File(getBaseDir(), getSamplesDirectoryName());
  }

  public File getSamplesDirectory() {
    return samplesDirectory;
  }

  public File[] getSampleFiles() {
    final Collection files = FileUtils
        .listFiles(getSamplesDirectory(), new String[]{ "xml" }, true);
    return (File[]) files.toArray(new File[files.size()]);

  }

  protected abstract JAXBContext createContext() throws Exception;

  protected void checkSample(File sample) throws Exception {
    final JAXBContext context = createContext();
    checkSample(context, sample);
  }

  protected abstract void checkSample(JAXBContext context, File sample) throws Exception;

  public void testSamples() throws Exception {
    final File[] sampleFiles = getSampleFiles();

    for (int index = 0; index < sampleFiles.length; index++) {
      final File sampleFile = sampleFiles[index];
      checkSample(sampleFile);
    }
  }

  public File getBaseDir() {
    return baseDir;
  }
}