package org.jvnet.jaxbcommons.tests.one;

import org.jvnet.jaxbcommons.addon.tests.AddOnsTest;

public class AddOnTest extends AddOnsTest {

  public AddOnTest() {
    super("one");
  }
}
