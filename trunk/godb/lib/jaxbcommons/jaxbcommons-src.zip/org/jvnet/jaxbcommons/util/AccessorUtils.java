package org.jvnet.jaxbcommons.util;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JMethod;
import com.sun.codemodel.JType;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

/**
 * Accessor utilities.
 * 
 * @author valikov
 */
public class AccessorUtils {
  
  /**
   * Hidden constructor.
   */
  private AccessorUtils()
  {
  }
  
  public static JMethod get(final ClassContext classContext, final FieldItem fieldItem)
  {
    final JCodeModel codeModel = classContext.ref.owner();
    final JType type = fieldItem.getType(codeModel);
    final String getterName = (codeModel.BOOLEAN.equals(type) ? "is" : "get") + fieldItem.name;
    return CodeModelUtils.getMethod(classContext, getterName);
  }

  public static JMethod set(final ClassContext classContext, final FieldItem fieldItem)
  {
    final String setterName = "set" + fieldItem.name;
    return CodeModelUtils.getMethod(classContext, setterName);
  }
  
  public static JMethod unset(final ClassContext classContext, final FieldItem fieldItem)
  {
    final String unsetterName = "unset" + fieldItem.name;
    return CodeModelUtils.getMethod(classContext, unsetterName);
  }
  

  public static JMethod isSet(final ClassContext classContext, final FieldItem fieldItem)
  {
    final String isSetterName = "isSet" + fieldItem.name;
    return CodeModelUtils.getMethod(classContext, isSetterName);
  }
}