package org.jvnet.jaxbcommons.util;

import com.sun.tools.xjc.grammar.ClassItem;

public class ClassUtils {

  public static String getClassName(final ClassItem classItem) {
    return CodeModelUtils.getClassName(classItem.getTypeAsDefined());
  }
}
