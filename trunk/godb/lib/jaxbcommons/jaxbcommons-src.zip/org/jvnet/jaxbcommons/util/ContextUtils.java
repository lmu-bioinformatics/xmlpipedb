package org.jvnet.jaxbcommons.util;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class ContextUtils {

  private ContextUtils() {
  }

  public static String format(JAXBContext context, Object object) throws JAXBException {
    final Marshaller marshaller = context.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
    final StringWriter sw = new StringWriter();
    marshaller.marshal(object, sw);
    return sw.toString();
  }

}
