package org.jvnet.jaxbcommons.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sun.tools.xjc.grammar.JavaItem;
import com.sun.tools.xjc.reader.xmlschema.bindinfo.BIDeclaration;
import com.sun.tools.xjc.reader.xmlschema.bindinfo.BIXPluginCustomization;

public class CustomizationUtils {

  private static final DocumentBuilder DOCUMENT_BUILDER;
  static {
    final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    try {
      DOCUMENT_BUILDER = documentBuilderFactory.newDocumentBuilder();
    }
    catch (ParserConfigurationException pce) {
      throw new ExceptionInInitializerError(pce);
    }
  }

  public static Collection getCustomizations(JavaItem item) {
    final Collection customizations = new ArrayList();
    for (Iterator iterator = item.declarations.iterator(); iterator.hasNext();) {
      final BIDeclaration declaration = (BIDeclaration) iterator.next();
      if (declaration instanceof BIXPluginCustomization) {
        customizations.add(declaration);
      }
    }
    return customizations;
  }

  public static BIXPluginCustomization createCustomization(QName name) {
    final Document document = DOCUMENT_BUILDER.newDocument();
    final Element element = document.createElementNS(name.getNamespaceURI(), name.getLocalPart());
    final BIXPluginCustomization customization = new BIXPluginCustomization(element, null);
    return customization;
  }

  public static BIXPluginCustomization getOrCreateCustomization(JavaItem item, QName name) {
    if (containsCustomization(item, name)) {
      return getCustomization(item, name);
    }
    else {
      final BIXPluginCustomization customization = createCustomization(name);
      item.declarations.add(customization);
      return customization;
    }
  }

  public static Collection getCustomizations(JavaItem item, QName name) {
    final Collection customizationsDraft = getCustomizations(item);
    final Collection customizations = new ArrayList();

    for (Iterator iterator = customizationsDraft.iterator(); iterator.hasNext();) {
      final BIXPluginCustomization customization = (BIXPluginCustomization) iterator.next();

      final Element element = customization.element;
      if (null != element) {
        final QName elementName = new QName(element.getNamespaceURI(), element.getLocalName());
        if (elementName.equals(name))
          customizations.add(customization);
      }
    }
    return customizations;
  }

  public static boolean containsCustomization(JavaItem item, QName name) {
    for (Iterator iterator = item.declarations.iterator(); iterator.hasNext();) {
      final BIDeclaration declaration = (BIDeclaration) iterator.next();
      if (declaration instanceof BIXPluginCustomization) {
        final BIXPluginCustomization customization = (BIXPluginCustomization) declaration;
        if (name.equals(customization.getName())) {
          return true;
        }
      }
    }
    return false;
  }

  public static BIXPluginCustomization getCustomization(JavaItem item, QName name) {
    final Collection customizations = getCustomizations(item, name);
    if (customizations.isEmpty()) {
      return null;
    }
    else {
      return (BIXPluginCustomization) customizations.iterator().next();
    }
  }

}
