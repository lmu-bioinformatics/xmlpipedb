package org.jvnet.jaxbcommons.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.jvnet.jaxbcommons.visitor.enums.EnumValuesVisitor;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class EnumUtils {

  private EnumUtils() {
  }

  public static Collection getValues(final ClassContext classContext, final FieldItem fieldItem) {
    final Collection enumValues = (Collection) fieldItem.visit(new EnumValuesVisitor(
        classContext));
    return enumValues;
  }

  public static String[] createCodes(final Map enumCodeMap, final Object[] ens) {
    final String[] codes = new String[ens.length];
    for (int index = 0; index < codes.length; index++) {
      final Object value = ens[index];
      final String code = (String) enumCodeMap.get(value);
      codes[index] = code;
    }
    return codes;
  }

  public static Map createEnumCodeMap(final Map codeEnumMap) {
    final Map enumCodeMap = new HashMap(codeEnumMap);
    for (Iterator iterator = codeEnumMap.entrySet().iterator(); iterator.hasNext();) {
      final Map.Entry entry = (Map.Entry) iterator.next();
      final Object code = entry.getKey();
      final Object value = entry.getValue();
      enumCodeMap.put(value, code);
    }
    return enumCodeMap;
  }
  

}
