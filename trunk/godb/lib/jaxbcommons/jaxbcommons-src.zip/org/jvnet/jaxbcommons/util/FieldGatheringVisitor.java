/*
 * Created on 28.09.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.jvnet.jaxbcommons.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.jvnet.jaxbcommons.visitor.ClassifyingVisitor;

import com.sun.msv.grammar.BinaryExp;
import com.sun.msv.grammar.ChoiceExp;
import com.sun.msv.grammar.SequenceExp;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;


public class FieldGatheringVisitor extends ClassifyingVisitor {

  public FieldGatheringVisitor(ClassContext classContext) {
    super(classContext);
  }

  public Object onClassInternal(ClassItem classItem) {
    return classItem.exp.visit(this);
  }

  public Object onSequence(SequenceExp exp) {
    return onBinary(exp);
  }

  public Object onChoice(ChoiceExp exp) {
    return onBinary(exp);
  }

  public Object onBinary(BinaryExp exp) {
    final List list = new ArrayList();
    final List left = (List) exp.exp1.visit(this);
    final List right = (List) exp.exp2.visit(this);

    if (left != null) {
      list.addAll(left);
    }

    if (right != null) {
      list.addAll(right);
    }
    return list;
  }

  public Object onField(FieldItem fieldItem) {
    return Collections.singletonList(fieldItem);
  }
}