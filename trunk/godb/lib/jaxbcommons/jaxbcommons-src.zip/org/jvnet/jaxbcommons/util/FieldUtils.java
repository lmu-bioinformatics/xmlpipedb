package org.jvnet.jaxbcommons.util;

import java.util.Iterator;
import java.util.List;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JFieldVar;
import com.sun.codemodel.JType;
import com.sun.codemodel.JVar;
import com.sun.msv.datatype.xsd.XSDatatype;
import com.sun.msv.grammar.Expression;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.generator.field.DefaultFieldRendererFactory;
import com.sun.tools.xjc.generator.field.FieldRenderer;
import com.sun.tools.xjc.grammar.AnnotatedGrammar;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;
import com.sun.tools.xjc.grammar.PrimitiveItem;
import com.sun.tools.xjc.grammar.FieldItem.BadTypeException;
import com.sun.tools.xjc.grammar.util.Multiplicity;

/**
 * Field utilities.
 * 
 * @author valikov
 */
public class FieldUtils {

  /** Hidden constructor. */
  private FieldUtils() {
  }

  public static FieldItem[] getFieldItems(ClassContext classContext) {
    final List fieldItems = (List) classContext.target
        .visit(new FieldGatheringVisitor(classContext));
    return (FieldItem[]) fieldItems.toArray(new FieldItem[fieldItems.size()]);
  }
  
  public static String getFieldName(ClassContext classContext, FieldItem fieldItem) {
    return ClassUtils.getClassName(classContext.target) + "." + fieldItem.name;
  }

  public static String getFieldPropertyName(FieldItem fieldItem) {
    return fieldItem.name;
  }

  public static FieldItem getFieldItem(FieldUse fieldUse) {
    if (fieldUse.items.isEmpty()) {
      return null;
    }
    else {
      return (FieldItem) fieldUse.items.iterator().next();
    }
  }

  /**
   * Returns a new unique name of the field in the given class, based on the given prefix. If required, the prefix will
   * be appended with an integer to make it unique
   *
   * @param theClass class to create field in.
   * @param prefix   field name prefix.
   * @return Unique name of the new field.
   */
  public static String generateUniqueFieldName(final JDefinedClass theClass, final String prefix) {
    final String name;
    if (null == getField(theClass, prefix)) {
      name = prefix;
    }
    else {
      int index = 0;
      while (null != getField(theClass, prefix + index)) {
        index++;
      }
      name = prefix + index;
    }
    return name;
  }

  /**
   * Retrievs a named field of the given class.
   *
   * @param theClass class to search a field in.
   * @param name     name of the field.
   * @return Requested field of the given class.
   */
  public static JVar getField(final JDefinedClass theClass, final String name) {
    JFieldVar result = null;
    for (Iterator iterator = theClass.fields(); iterator.hasNext();) {
      final JFieldVar var = (JFieldVar) iterator.next();
      if (name.equals(var.name())) {
        result = var;
      }
    }
    // todo : if not found???
    return result;
  }

  public static FieldItem createPrimitiveFieldItem(
      ClassContext classContext,
      final String name,
      final XSDatatype datatype,
      final JType type) {
    final FieldItem fieldItem;
    final GeneratorContext generatorContext = classContext.parent;
    final AnnotatedGrammar grammar = generatorContext.getGrammar();
    final JCodeModel codeModel = grammar.codeModel;
    final ClassItem classItem = classContext.target;

    final Expression dataExp = grammar.getPool().createData(datatype);

    final PrimitiveItem typeItem = grammar.createPrimitiveItem(codeModel, datatype, dataExp, null);

    fieldItem = new FieldItem(name, typeItem, null);
    try {
      fieldItem.addType(typeItem);
    }
    catch (BadTypeException btex) {
      // todo
    }
    final FieldUse fieldUse;
    fieldUse = classItem.getOrCreateFieldUse(name);
    fieldUse.items.add(fieldItem);
    fieldUse.multiplicity = Multiplicity.one;
    fieldUse.type = type;

    final FieldRenderer fieldRenderer = new DefaultFieldRendererFactory(codeModel).create(
        generatorContext.getClassContext(classItem),
        fieldUse);
    fieldRenderer.generate();
    return fieldItem;
  }
  
  public static boolean isConstantField(ClassContext classContext, FieldItem fieldItem)
  {
	return AccessorUtils.get(classContext, fieldItem) == null;
  }

}
