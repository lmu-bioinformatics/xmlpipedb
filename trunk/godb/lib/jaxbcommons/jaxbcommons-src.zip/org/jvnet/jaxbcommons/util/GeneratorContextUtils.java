package org.jvnet.jaxbcommons.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.generator.PackageContext;

public class GeneratorContextUtils {

  private GeneratorContextUtils() {
  }

  public static Collection getPackageNames(GeneratorContext context) {
    final PackageContext[] packageContexts = context.getAllPackageContexts();
    final Collection packageNames = new ArrayList(packageContexts.length);

    for (int index = 0; index < packageContexts.length; index++) {
      final PackageContext packageContext = packageContexts[index];
      packageNames.add(packageContext._package.name());
    }
    return packageNames;
  }

  public static String getPackageNamesString(Collection packageNames) {
    final StringBuffer sb = new StringBuffer();
    for (Iterator iterator = packageNames.iterator(); iterator.hasNext();) {
      final String packageName = (String) iterator.next();
      sb.append(packageName);
      if (iterator.hasNext())
        sb.append(':');
    }
    return sb.toString();
  }

  public static String getPackageNamesString(GeneratorContext context) {
    return getPackageNamesString(getPackageNames(context));
  }
}
