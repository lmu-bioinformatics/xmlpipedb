package org.jvnet.jaxbcommons.util;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JType;
import com.sun.msv.datatype.xsd.IDREFType;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;
import com.sun.tools.xjc.grammar.PrimitiveItem;
import com.sun.tools.xjc.grammar.TypeItem;

/**
 * Type utilities.
 * 
 * @author valikov
 */
public class TypeUtils {

  private static final Comparator TYPE_ITEM_COMPARATOR = new Comparator() {
    public int compare(Object o1, Object o2) {
      final TypeItem t1 = (TypeItem) o1;
      final TypeItem t2 = (TypeItem) o2;
      return t1.getType().fullName().compareTo(t2.getType().fullName());
    }
  };

  public static Set getAssignableTypeItems(final TypeItem t) {
    final Set s = new TreeSet(TYPE_ITEM_COMPARATOR);
    addAssignableTypeItems(t, s);
    return s;
  }

  private static void addAssignableTypeItems(TypeItem t, Set s) {
    if (!s.add(t))
      return;

    if (t instanceof ClassItem) {
      final ClassItem c = (ClassItem) t;
      final ClassItem sc = c.getSuperClass();
      if (sc != null)
        addAssignableTypeItems(sc, s);
    }
  }

  public static TypeItem getCommonBaseTypeItem(
      final ClassContext classContext,
      final FieldItem fieldItem) {
    final TypeItem[] t = fieldItem.listTypes();
    // first, eliminate duplicates.
    final Set uniqueTypes = new TreeSet(TYPE_ITEM_COMPARATOR);
    for (int i = 0; i < t.length; i++) {
      if (t[i] instanceof PrimitiveItem
          && ((PrimitiveItem) t[i]).guard == IDREFType.theInstance
          && t[i].getType() instanceof JDefinedClass) {
        final ClassItem classItem = classContext.parent.getGrammar().getClassItem(
            (JDefinedClass) t[i].getType());
        if (classItem != null) {
          uniqueTypes.add(classItem);
        }
        else {
          uniqueTypes.add(t[i]);
        }
      }
      else {
        uniqueTypes.add(t[i]);
      }
    }

    if (uniqueTypes.isEmpty()) {
      return null;
    }

    final TypeItem firstType = (TypeItem) uniqueTypes.iterator().next();

    if (uniqueTypes.size() == 1) {
      return firstType;
    }

    final Set s = getAssignableTypeItems(firstType);
    for (Iterator itr = uniqueTypes.iterator(); itr.hasNext();) {
      final TypeItem type = (TypeItem) itr.next();
      if (type.getType() != type.getType().owner().NULL) {
        s.retainAll(getAssignableTypeItems(type));
      }
    }

    if (s.isEmpty()) {
      return null;
    }

    // refine 's' by removing "lower" types.
    // for example, if we have both java.lang.Object and
    // java.io.InputStream, then we don't want to use java.lang.Object.

    final TypeItem[] raw = (TypeItem[]) s.toArray(new TypeItem[s.size()]);

    s.clear();

    for (int i = 0; i < raw.length; i++) { // for each raw[i]
      int j;
      for (j = 0; j < raw.length; j++) { // see if raw[j] "includes" raw[i]
        if (i == j)
          continue;

        if (CodeModelUtils.box(raw[i].getType()).isAssignableFrom(
            CodeModelUtils.box(raw[j].getType())))
          break; // raw[j] is derived from raw[i], hence j includes i.
      }

      if (j == raw.length)
        // no other type inclueds raw[i]. remember this value.
        s.add(raw[i]);
    }

    if (s.size() == 1) {
      return (TypeItem) s.iterator().next();
    }

    throw new AssertionError("There can be at most one common base type item.");
  }

  public static TypeItem[] getAllTypeItems(final FieldItem fieldItem) {
    final TypeItem[] fieldItemTypes = fieldItem.listTypes();
    TypeItem.sort(fieldItemTypes);
    return fieldItemTypes;
  }

  /**
   * Returns collection of type items of a certain field. 
   * @param fieldItem field item.
   * @return Collection of type items.
   */
  public static Collection getTypeItems(final FieldItem fieldItem) {
    final Set typeItems = new HashSet(1);
    final TypeItem[] fieldItemTypes = fieldItem.listTypes();
    TypeItem.sort(fieldItemTypes);
    for (int index = fieldItemTypes.length - 1; index >= 0; index--) {
      final TypeItem typeItem = fieldItemTypes[index];

      if (typeItem instanceof ClassItem) {
        final ClassItem classItem = (ClassItem) typeItem;
        typeItems.remove(classItem.getSuperClass());

      }
      typeItems.add(typeItem);
    }
    return typeItems;
  }

  public static Collection getAllTypeItems(final FieldUse fieldUse) {
    final Set typeItems = new HashSet(1);
    for (Iterator iterator = fieldUse.items.iterator(); iterator.hasNext();) {
      final FieldItem fieldItem = (FieldItem) iterator.next();
      final TypeItem[] fieldItemTypes = fieldItem.listTypes();
      for (int index = 0; index < fieldItemTypes.length; index++) {
        final TypeItem typeItem = fieldItemTypes[index];
        typeItems.add(typeItem);
      }
    }
    return typeItems;
  }

  /**
   * Returns a single type item of the field.
   * @param fieldItem field item.
   * @return Type item of the field.
   */
  //  public static TypeItem getTypeItem(final FieldItem fieldItem) {
  //    return (TypeItem) getTypeItems(fieldItem).iterator().next();
  //  }
  public static PrimitiveItem getPrimitiveTypeItem(final FieldItem fieldItem) {
    return (PrimitiveItem) getTypeItems(fieldItem).iterator().next();
  }

  /**
   * Returns class item of the field.
   * @param fieldItem field item.
   * @return Class item of the field.
   */
  public static ClassItem getClassItem(ClassContext classContext, final FieldItem fieldItem) {
    return (ClassItem) getCommonBaseTypeItem(classContext, fieldItem);
  }

  public static JDefinedClass getEnumClass(ClassContext classContext, final FieldItem fieldItem) {
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);
    final PrimitiveItem primitiveTypeItem = (PrimitiveItem) typeItem;
    final JType type = primitiveTypeItem.getType();
    final JDefinedClass theClass = (JDefinedClass) type;
    return theClass;
  }
}
