package org.jvnet.jaxbcommons.visitor;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jvnet.jaxbcommons.util.TypeUtils;
import org.w3c.dom.Element;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JType;
import com.sun.msv.grammar.AttributeExp;
import com.sun.msv.grammar.ChoiceExp;
import com.sun.msv.grammar.ConcurExp;
import com.sun.msv.grammar.DataExp;
import com.sun.msv.grammar.ElementExp;
import com.sun.msv.grammar.InterleaveExp;
import com.sun.msv.grammar.ListExp;
import com.sun.msv.grammar.MixedExp;
import com.sun.msv.grammar.OneOrMoreExp;
import com.sun.msv.grammar.OtherExp;
import com.sun.msv.grammar.ReferenceExp;
import com.sun.msv.grammar.SequenceExp;
import com.sun.msv.grammar.ValueExp;
import com.sun.msv.grammar.xmlschema.OccurrenceExp;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.grammar.AnnotatedGrammar;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.ExternalItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;
import com.sun.tools.xjc.grammar.IgnoreItem;
import com.sun.tools.xjc.grammar.InterfaceItem;
import com.sun.tools.xjc.grammar.PrimitiveItem;
import com.sun.tools.xjc.grammar.SuperClassItem;
import com.sun.tools.xjc.grammar.TypeItem;
import com.sun.tools.xjc.grammar.ext.WildcardItem;

/**
 * Base class for classifying visitors.
 * 
 * @author valikov
 */
public class ClassifyingVisitor extends BGMExpressionVisitor {

  protected final Log logger = LogFactory.getLog(ClassifyingVisitor.class);

  protected final AnnotatedGrammar grammar;

  protected final GeneratorContext generatorContext;

  protected final JCodeModel codeModel;

  protected ClassContext classContext;

  protected FieldUse fieldUse;

  /**
   * Constructs a new visitor in generator context.
   * @param generatorContext generator context.
   */
  public ClassifyingVisitor(GeneratorContext generatorContext) {
    this.grammar = generatorContext.getGrammar();
    this.generatorContext = generatorContext;
    this.codeModel = grammar.codeModel;
  }

  /**
   * Constructs a new visitor in class context.
   * @param classContext class context.
   */
  public ClassifyingVisitor(ClassContext classContext) {
    this(classContext.parent);
    this.classContext = classContext;
  }

  public Object onClass(ClassItem classItem) {
    final ClassContext oldClassContext = classContext;
    classContext = generatorContext.getClassContext(classItem);
    logger.trace("Processing class [" + classContext.target.name + "]");
    final Object result = onClassInternal(classItem);
    classContext = oldClassContext;
    return result;
  }

  public Object onClassInternal(ClassItem classItem) {
    return classItem.exp.visit(this);
  }

  public Object onExternal(ExternalItem arg0) {
    return null;
  }

  public Object onField(FieldItem fieldItem) {
    logger.trace("Processing field [" + classContext.target.name + "." + fieldItem.name + "]");
    fieldUse = classContext.target.getField(fieldItem.name);
    if (fieldUse.multiplicity.isAtMostOnce()) {
      return onSingleField(fieldItem);
    }
    else {
      return onCollectionField(fieldItem);
    }
  }

  /**
   * Processes single field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onSingleField(FieldItem fieldItem) {

    //    final Collection typeItems = TypeUtils.getTypeItems(fieldItem);
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);
    if (typeItem != null)
      return onHomoSingleField(fieldItem);
    else
      return onHeteroSingleField(fieldItem);

  }

  /**
   * Processes homogeneous single field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onHomoSingleField(FieldItem fieldItem) {
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);
    if (typeItem instanceof ClassItem)
      return onComplexSingleField(fieldItem);
    else
      return onSimpleHomoSingleField(fieldItem);
  }

  /**
   * Processes heterogeneous single field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onHeteroSingleField(FieldItem fieldItem) {
    return null;
  }

  /**
   * Processes simple homogeneous single field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onSimpleHomoSingleField(FieldItem fieldItem) {
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);

    if (typeItem instanceof PrimitiveItem) {
      final PrimitiveItem primitiveTypeItem = (PrimitiveItem) typeItem;
      final JType type = primitiveTypeItem.getType();
      if (type instanceof JDefinedClass) {
        final JDefinedClass theClass = (JDefinedClass) type;
        return onEnumSingleField(fieldItem);
      }
      else if (type == codeModel.ref(Object.class)) {
        return onWildcardSingleField(fieldItem);
      }
      else {
        return onPrimitiveSingleField(fieldItem);
      }
    }
    else if (typeItem.getType() == codeModel.ref(Element.class)) {
      return onDomSingleField(fieldItem);
    }
    else if (typeItem instanceof WildcardItem) {
      return onWildcardSingleField(fieldItem);
    }
    else {
      return null;
    }
  }

  public Object onPrimitiveSingleField(FieldItem fieldItem) {
    return null;
  }

  public Object onWildcardSingleField(FieldItem fieldItem) {
    return null;
  }

  public Object onDomSingleField(FieldItem fieldItem) {
    return null;
  }

  public Object onEnumSingleField(FieldItem fieldItem) {
    return null;
  }

  public Object onComplexSingleField(FieldItem fieldItem) {
    return null;
  }

  /**
   * Processes collection field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onCollectionField(FieldItem fieldItem) {

    //    final Collection typeItems = TypeUtils.getTypeItems(fieldItem);
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);

    if (typeItem != null)
      return onHomoCollectionField(fieldItem);
    else
      return onHeteroCollectionField(fieldItem);
  }

  /**
   * Processes simple homogeneous collection field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onSimpleHomoCollectionField(FieldItem fieldItem) {
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);

    if (typeItem instanceof PrimitiveItem) {
      final PrimitiveItem primitiveTypeItem = (PrimitiveItem) typeItem;
      final JType type = primitiveTypeItem.getType();
      if (type instanceof JDefinedClass) {
        final JDefinedClass theClass = (JDefinedClass) type;
        return onEnumCollectionField(fieldItem);
      }
      else if (type == codeModel.ref(Object.class)) {
        return onWildcardCollectionField(fieldItem);
      }
      else {
        return onPrimitiveCollectionField(fieldItem);
      }
    }
    else if (typeItem.getType() == codeModel.ref(Element.class)) {
      return onDomCollectionField(fieldItem);
    }
    else if (typeItem instanceof WildcardItem) {
      return onWildcardCollectionField(fieldItem);
    }
    else {
      return null;
    }
  }

  /**
   * Processes homogeneous collection field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onHomoCollectionField(FieldItem fieldItem) {
    final TypeItem typeItem = TypeUtils.getCommonBaseTypeItem(classContext, fieldItem);
    if (typeItem instanceof ClassItem) {
      return onComplexCollectionField(fieldItem);
    }
    else {
      return onSimpleHomoCollectionField(fieldItem);
    }
  }

  public Object onPrimitiveCollectionField(FieldItem fieldItem) {
    return null;
  }

  public Object onWildcardCollectionField(FieldItem fieldItem) {
    return null;
  }

  public Object onDomCollectionField(FieldItem fieldItem) {
    return null;
  }

  public Object onEnumCollectionField(FieldItem fieldItem) {
    return null;
  }

  public Object onComplexCollectionField(FieldItem fieldItem) {
    return null;
  }

  /**
   * Processes heterogeneous collection field.
   * @param fieldItem field item.
   * @return Processing result. 
   */
  public Object onHeteroCollectionField(FieldItem fieldItem) {
    return null;
  }

  public Object onIgnore(IgnoreItem arg0) {
    return null;
  }

  public Object onInterface(InterfaceItem arg0) {
    return null;
  }

  public Object onPrimitive(PrimitiveItem arg0) {
    return null;
  }

  public Object onSuper(SuperClassItem superClassItem) {
    return superClassItem.exp.visit(this);
  }

  public Object onAnyString() {
    return null;
  }

  public Object onAttribute(AttributeExp arg0) {
    return null;
  }

  public Object onChoice(ChoiceExp exp) {

    final Object left = exp.exp1.visit(this);
    final Object right = exp.exp2.visit(this);
    return null;
  }

  public Object onConcur(ConcurExp arg0) {
    return null;
  }

  public Object onData(DataExp arg0) {
    return null;
  }

  public Object onElement(ElementExp exp) {
    return exp.contentModel.visit(this);
  }

  public Object onEpsilon() {
    return null;
  }

  public Object onInterleave(InterleaveExp arg0) {
    return null;
  }

  public Object onList(ListExp arg0) {
    return null;
  }

  public Object onMixed(MixedExp arg0) {
    return null;
  }

  public Object onNullSet() {
    return null;
  }

  public Object onOneOrMore(OneOrMoreExp exp) {
    return exp.exp.visit(this);
  }

  public Object onRef(ReferenceExp exp) {
    return exp.exp.visit(this);
  }

  public Object onSequence(SequenceExp exp) {
    final Object left = exp.exp1.visit(this);
    final Object right = exp.exp2.visit(this);
    return null;
  }

  public Object onValue(ValueExp arg0) {
    return null;
  }

  public Object onOther(final OtherExp exp) {
    if (exp instanceof OccurrenceExp) {
      return onOccurrenceExp((OccurrenceExp) exp);
    }
    else {
      return super.onOther(exp);
    }
  }

  /**
   * Processes occurence expression
   * @param exp occurence expression.
   * @return Processing result. 
   */
  public Object onOccurrenceExp(final OccurrenceExp exp) {
    return null;
  }
}
