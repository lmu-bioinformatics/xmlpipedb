package org.jvnet.jaxbcommons.visitor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;

public class OnceClassifyingVisitor extends ClassifyingVisitor {

  private Map processedClassResults = new HashMap();
  private Map processedFieldResults = new HashMap();
  private Set processedClasses = new HashSet();
  private Set processedFields = new HashSet();

  public OnceClassifyingVisitor(ClassContext classContext) {
    super(classContext);
  }

  public OnceClassifyingVisitor(GeneratorContext generatorContext) {
    super(generatorContext);
  }

  public Object onClassInternal(ClassItem classItem) {
    if (processedClasses.contains(classItem))
      return processedClassResults.get(classItem);
    else {
      processedClasses.add(classItem);
      final Object result = onClassOnce(classItem);
      processedClassResults.put(classItem, result);
      return result;
    }
  }

  public Object onClassOnce(ClassItem classItem) {
    return classItem.exp.visit(this);
  }

  public Object onField(FieldItem fieldItem) {
    if (processedFields.contains(fieldItem))
      return processedFieldResults.get(fieldItem);
    else {
      processedFields.add(fieldItem);
      final Object result = onFieldOnce(fieldItem);
      processedFieldResults.put(fieldItem, result);
      return result;
    }
  }

  public Object onFieldOnce(FieldItem fieldItem) {
    return super.onField(fieldItem);
  }
}
