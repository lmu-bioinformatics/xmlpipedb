package org.jvnet.jaxbcommons.visitor.enums;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jvnet.jaxbcommons.visitor.ClassifyingVisitor;


import com.sun.msv.grammar.BinaryExp;
import com.sun.msv.grammar.ChoiceExp;
import com.sun.msv.grammar.SequenceExp;
import com.sun.msv.grammar.ValueExp;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.PrimitiveItem;

public class EnumValuesVisitor extends ClassifyingVisitor {

  public EnumValuesVisitor(ClassContext classContext) {
    super(classContext);
  }

  public Object onSequence(SequenceExp exp) {
    return onBinaryExp(exp);
  }

  public Object onChoice(ChoiceExp exp) {
    return onBinaryExp(exp);
  }
  
  public Object onBinaryExp(BinaryExp exp)
  {
    final Collection left = (Collection) exp.exp1.visit(this);
    final Collection right = (Collection) exp.exp2.visit(this);
    if (left == null) {
      return right;
    }
    else if (right == null) {
      return left;
    }
    else {
      final List enums = new ArrayList(left.size() + right.size());
      enums.addAll(left);
      enums.addAll(right);
      return enums;
    }
  }

  public Object onPrimitive(PrimitiveItem item) {
    return item.exp.visit(this);
  }

  public Object onValue(ValueExp exp) {
    final List enums = new ArrayList(1);
    enums.add(exp);
    return enums;
  }

  public Object onField(FieldItem fieldItem) {
    return fieldItem.exp.visit(this);
  }
}
