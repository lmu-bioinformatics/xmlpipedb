package org.jvnet.hyperjaxb2.addon;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.ClassUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jvnet.hyperjaxb2.customizations.Constants;
import org.jvnet.hyperjaxb2.hibernate.mapping.HibernateMapping;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.PrincipalStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.utils.HibernateMappingUtils;
import org.jvnet.hyperjaxb2.hibernate.visitor.HibernateMappingGeneratingVisitor;
import org.jvnet.hyperjaxb2.runtime.tests.RoundtripTest;
import org.jvnet.jaxbcommons.addon.AbstractParameterizableCodeAugmenter;
import org.jvnet.jaxbcommons.util.CodeModelUtils;
import org.jvnet.jaxbcommons.util.GeneratorContextUtils;
import org.xml.sax.ErrorHandler;

import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JExpr;
import com.sun.codemodel.JMethod;
import com.sun.codemodel.JMod;
import com.sun.codemodel.fmt.JTextFile;
import com.sun.msv.grammar.ExpressionVisitor;
import com.sun.tools.xjc.CodeAugmenterEx;
import com.sun.tools.xjc.Options;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.generator.GeneratorContext;
import com.sun.tools.xjc.grammar.AnnotatedGrammar;
import com.sun.tools.xjc.grammar.ClassItem;

public class AddOn extends AbstractParameterizableCodeAugmenter implements CodeAugmenterEx {

  private String testName = null;
  private String roundtripTestClassName = null;
  private String config = null;

  public String getConfig() {
    return config;
  }

  public void setConfig(String config) {
    this.config = config;
  }

  public String getRoundtripTestClassName() {
    return roundtripTestClassName;
  }

  public void setRoundtripTestClassName(String roundtripTestClassName) {
    this.roundtripTestClassName = roundtripTestClassName;
  }

  public String getTestName() {
    return testName;
  }

  public void setTestName(String testName) {
    this.testName = testName;
  }

  /**
   * Logger.
   */
  protected Log logger = LogFactory.getLog(getClass());

  protected IPrincipalStrategy principalStrategy = new PrincipalStrategy();

  public String getOptionName() {
    return "Xhyperjaxb2";
  }

  public String getUsage() {
    return "  -Xhyperjaxb2                 :  generates Hibernate XDoclets";
  }

  public List getCustomizationURIs() {
    return Collections.singletonList(Constants.NAMESPACE_URI);
  }

  public boolean run(
      AnnotatedGrammar grammar,
      GeneratorContext generatorContext,
      Options options,
      ErrorHandler errorHandler) {

    final ClassItem[] classItems = grammar.getClasses();
    final Map classMappingsMap = new HashMap(classItems.length);
    for (int index = 0; index < classItems.length; index++) {
      final ClassItem classItem = classItems[index];
      final ClassContext classContext = generatorContext.getClassContext(classItem);
      logger.debug("Processing class item [" + classItem.name + "].");

      final ExpressionVisitor visitor = new HibernateMappingGeneratingVisitor(
          getPrincipalStrategy(),
          classContext);
      final HibernateMapping hibernateMapping = (HibernateMapping) classItem.visit(visitor);
      if (hibernateMapping != null) {
        classMappingsMap.put(classContext, hibernateMapping);
      }
    }

    for (final Iterator iterator = classMappingsMap.entrySet().iterator(); iterator.hasNext();) {
      final Entry entry = (Entry) iterator.next();
      final ClassContext classContext = (ClassContext) entry.getKey();
      final ClassItem classItem = classContext.target;
      final HibernateMapping hibernateMapping = (HibernateMapping) entry.getValue();

      try {
        final JTextFile mappingFile = new JTextFile(
            CodeModelUtils.getPackagedClassName(classContext.ref) + ".hbm.xml");
        final String contents = HibernateMappingUtils.marshall(hibernateMapping);
        mappingFile.setContents(contents);
        classItem.getTypeAsDefined()._package().addResourceFile(mappingFile);
      }
      catch (Exception ex) {
        throw new RuntimeException(ex);
      }
    }

    if (getRoundtripTestClassName() != null) {

      final String packageNames = GeneratorContextUtils.getPackageNamesString(generatorContext);

      final JDefinedClass testClass = CodeModelUtils.getOrCreateClass(
          grammar.codeModel,
          JMod.PUBLIC,
          getRoundtripTestClassName());
      
      testClass._extends(RoundtripTest.class);

      final JMethod constructor = testClass.constructor(JMod.PUBLIC);

      if (getTestName() != null) {
        constructor.body().invoke("super").arg(JExpr.lit(getTestName())).arg(
            JExpr.lit(packageNames));
      }
      else {
        constructor.body().invoke("super").arg(JExpr.lit(packageNames));
      }
    }
    return true;
  }

  protected IPrincipalStrategy getPrincipalStrategy() {
    return principalStrategy;
  }
}
