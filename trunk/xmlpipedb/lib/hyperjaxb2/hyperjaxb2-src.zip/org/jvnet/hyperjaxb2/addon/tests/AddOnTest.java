package org.jvnet.hyperjaxb2.addon.tests;

import java.util.ArrayList;
import java.util.List;

import org.jvnet.hyperjaxb2.addon.AddOn;

import com.sun.tools.xjc.CodeAugmenter;

public class AddOnTest extends org.jvnet.jaxbcommons.addon.tests.AbstractAddOnTest {

  public AddOnTest() {
    super();
  }

  public AddOnTest(String testName) {
    super(testName);
  }

  protected CodeAugmenter newAddOn() {
    return new AddOn();
  }

  public List getAddonOptions() {
    final List draftAddonOptions = super.getAddonOptions();
    final List addonOptions = new ArrayList(draftAddonOptions.size());
    addonOptions.addAll(draftAddonOptions);

    if (getTestName() != null) {
      addonOptions.add("-Xhyperjaxb2-testName=" + getTestName());
      addonOptions.add("-Xhyperjaxb2-roundtripTestClassName=org.jvnet.hyperjaxb2.tests."
          + getTestName()
          + ".RoundtripTestCase");
    }
    return addonOptions;
  }
}
