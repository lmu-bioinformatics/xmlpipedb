package org.jvnet.hyperjaxb2.customizations;

import javax.xml.namespace.QName;

public class Constants {

  public static final String NAMESPACE_URI = "http://hyperjaxb2.jvnet.org/customizations";
  public static final String JAXB_PACKAGE_NAMES = "org.jvnet.hyperjaxb2.customizations";

  public static final QName IGNORED = new QName(NAMESPACE_URI, "ignored");
  public static final QName ID = new QName(NAMESPACE_URI, "id");
  public static final QName VERSION = new QName(NAMESPACE_URI, "version");
  public static final QName DISCRIMINATOR = new QName(NAMESPACE_URI, "discriminator");
  public static final QName CLAZZ = new QName(NAMESPACE_URI, "clazz");
  public static final QName COMPONENT = new QName(NAMESPACE_URI, "component");
  public static final QName SIMPLE_SINGLE_PROPERTY = new QName(
      NAMESPACE_URI,
      "simpleSingleProperty");
  public static final QName COMPLEX_SINGLE_PROPERTY = new QName(
      NAMESPACE_URI,
      "complexSingleProperty");
  public static final QName WILDCARD_SINGLE_PROPERTY = new QName(
      NAMESPACE_URI,
      "wildcardSingleProperty");
  public static final QName SIMPLE_COLLECTION_PROPERTY = new QName(
      NAMESPACE_URI,
      "simpleCollectionProperty");
  public static final QName COMPLEX_COLLECTION_PROPERTY = new QName(
      NAMESPACE_URI,
      "complexCollectionProperty");
  public static final QName WILDCARD_COLLECTION_PROPERTY = new QName(
      NAMESPACE_URI,
      "wildcardCollectionProperty");
}
