package org.jvnet.hyperjaxb2.customizations;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;

import org.jvnet.hyperjaxb2.customizations.impl.ClazzImpl;
import org.jvnet.hyperjaxb2.customizations.impl.ComplexCollectionPropertyTypeImpl;
import org.jvnet.hyperjaxb2.customizations.impl.ComplexSinglePropertyTypeImpl;
import org.jvnet.hyperjaxb2.customizations.impl.SimpleCollectionPropertyTypeImpl;
import org.jvnet.hyperjaxb2.customizations.impl.SimpleSinglePropertyTypeImpl;
import org.jvnet.hyperjaxb2.customizations.impl.WildcardCollectionPropertyTypeImpl;
import org.jvnet.hyperjaxb2.customizations.impl.WildcardSinglePropertyTypeImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.Any;
import org.jvnet.hyperjaxb2.hibernate.mapping.Cache;
import org.jvnet.hyperjaxb2.hibernate.mapping.Clazz;
import org.jvnet.hyperjaxb2.hibernate.mapping.Column;
import org.jvnet.hyperjaxb2.hibernate.mapping.Comment;
import org.jvnet.hyperjaxb2.hibernate.mapping.Component;
import org.jvnet.hyperjaxb2.hibernate.mapping.Discriminator;
import org.jvnet.hyperjaxb2.hibernate.mapping.DynamicComponent;
import org.jvnet.hyperjaxb2.hibernate.mapping.Element;
import org.jvnet.hyperjaxb2.hibernate.mapping.Generator;
import org.jvnet.hyperjaxb2.hibernate.mapping.Id;
import org.jvnet.hyperjaxb2.hibernate.mapping.Join;
import org.jvnet.hyperjaxb2.hibernate.mapping.Key;
import org.jvnet.hyperjaxb2.hibernate.mapping.ListIndex;
import org.jvnet.hyperjaxb2.hibernate.mapping.ManyToAny;
import org.jvnet.hyperjaxb2.hibernate.mapping.ManyToMany;
import org.jvnet.hyperjaxb2.hibernate.mapping.ManyToOne;
import org.jvnet.hyperjaxb2.hibernate.mapping.OneToMany;
import org.jvnet.hyperjaxb2.hibernate.mapping.OneToOne;
import org.jvnet.hyperjaxb2.hibernate.mapping.Param;
import org.jvnet.hyperjaxb2.hibernate.mapping.Property;
import org.jvnet.hyperjaxb2.hibernate.mapping.Subclass;
import org.jvnet.hyperjaxb2.hibernate.mapping.Type;
import org.jvnet.hyperjaxb2.hibernate.mapping.Version;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.AnyImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.CacheImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ColumnImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.CommentImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ComponentImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.DiscriminatorImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ElementImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.GeneratorImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.IdImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.JoinImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.KeyImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ListImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ListIndexImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ManyToAnyImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ManyToManyImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ManyToOneImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.OneToManyImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.OneToOneImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.ParamImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.PropertyImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.SubclassImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.TypeImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.VersionImpl;
import org.jvnet.hyperjaxb2.runtime.hibernate.accessor.ListAccessor;
import org.jvnet.jaxbcommons.util.CustomizationUtils;

import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.JavaItem;
import com.sun.tools.xjc.reader.xmlschema.bindinfo.BIXPluginCustomization;

public class Utils {

  private static final JAXBContext CONTEXT;
  static {
    try {
      CONTEXT = JAXBContext.newInstance(Constants.JAXB_PACKAGE_NAMES, Id.class.getClassLoader());
    }
    catch (JAXBException jaxbex) {
      throw new ExceptionInInitializerError(jaxbex);
    }
  }

  private static Object getCustomization(JavaItem item, QName name) {
    final BIXPluginCustomization customization = CustomizationUtils.getCustomization(item, name);
    return unmarshallCustomization(customization);
  }

  private static Object getOrCreateCustomization(JavaItem item, QName name) {
    final BIXPluginCustomization customization = CustomizationUtils.getOrCreateCustomization(
        item,
        name);
    return unmarshallCustomization(customization);
  }

  /**
   * @param customization
   * @return
   */
  private static Object unmarshallCustomization(final BIXPluginCustomization customization) {
    if (customization == null) {
      return null;
    }
    else {
      try {
        final Unmarshaller unmarshaller = CONTEXT.createUnmarshaller();
        final Object object = unmarshaller.unmarshal(customization.element);
        return object;
      }
      catch (JAXBException jaxbex) {
        // todo
        return null;
      }
    }
  }

  public static ClassType getClazz(JavaItem item) {
    final ClassType cclass = (ClassType) getCustomization(item, Constants.CLAZZ);
    if (cclass != null) {
      return cclass;
    }
    else {
      return new ClazzImpl();
    }
  }

  public static ComponentType getComponent(JavaItem item) {
    final ComponentType ccomponent = (ComponentType) getCustomization(item, Constants.COMPONENT);
    return ccomponent;
  }

  public static SimpleSinglePropertyType getSimpleSingleProperty(JavaItem item) {
    final SimpleSinglePropertyType cproperty = (SimpleSinglePropertyType) getCustomization(
        item,
        Constants.SIMPLE_SINGLE_PROPERTY);
    if (cproperty != null) {
      return cproperty;
    }
    else {
      return new SimpleSinglePropertyTypeImpl();
    }
  }

  public static ComplexSinglePropertyType getComplexSingleProperty(JavaItem item) {
    final ComplexSinglePropertyType cproperty = (ComplexSinglePropertyType) getCustomization(
        item,
        Constants.COMPLEX_SINGLE_PROPERTY);
    if (cproperty != null) {
      return cproperty;
    }
    else {
      return new ComplexSinglePropertyTypeImpl();
    }
  }

  public static WildcardSinglePropertyType getWildcardSingleProperty(JavaItem item) {
    final WildcardSinglePropertyType cproperty = (WildcardSinglePropertyType) getCustomization(
        item,
        Constants.WILDCARD_SINGLE_PROPERTY);
    if (cproperty != null) {
      return cproperty;
    }
    else {
      return new WildcardSinglePropertyTypeImpl();
    }
  }

  public static SimpleCollectionPropertyType getSimpleCollectionProperty(JavaItem item) {
    final SimpleCollectionPropertyType cproperty = (SimpleCollectionPropertyType) getCustomization(
        item,
        Constants.SIMPLE_COLLECTION_PROPERTY);
    if (cproperty != null) {
      return cproperty;
    }
    else {
      return new SimpleCollectionPropertyTypeImpl();
    }
  }

  public static IdType getOrCreateId(JavaItem item) {
    return (IdType) getOrCreateCustomization(item, Constants.ID);
  }

  public static VersionType getOrCreateVersion(JavaItem item) {
    return (VersionType) getOrCreateCustomization(item, Constants.VERSION);
  }

  // public static DiscriminatorType getDiscriminator(JavaItem item) {
  // return (DiscType) getCustomization(item, Constants.VERSION);
  // }

  public static ComplexCollectionPropertyType getComplexCollectionProperty(JavaItem item) {
    final ComplexCollectionPropertyType cproperty = (ComplexCollectionPropertyType) getCustomization(
        item,
        Constants.COMPLEX_COLLECTION_PROPERTY);
    if (cproperty != null) {
      return cproperty;
    }
    else {
      return new ComplexCollectionPropertyTypeImpl();
    }
  }

  public static WildcardCollectionPropertyType getWildcardCollectionProperty(JavaItem item) {
    final WildcardCollectionPropertyType cproperty = (WildcardCollectionPropertyType) getCustomization(
        item,
        Constants.WILDCARD_COLLECTION_PROPERTY);
    if (cproperty != null) {
      return cproperty;
    }
    else {
      return new WildcardCollectionPropertyTypeImpl();
    }
  }

  public static Column createColumn(final ColumnType ccolumn, final String defaultColumnName) {
    final Column column = new ColumnImpl();

    if (!(ccolumn == null || ccolumn.getComment() == null)) {
      final Comment comment = new CommentImpl();
      column.setComment(comment);
      comment.setContent(ccolumn.getComment());
    }

    if (!(ccolumn == null || ccolumn.getName() == null)) {
      column.setName(ccolumn.getName());
    }
    else {
      column.setName(defaultColumnName);
    }

    if (ccolumn != null) {
      column.setLength(ccolumn.getLength());
      column.setPrecision(ccolumn.getPrecision());
      column.setScale(ccolumn.getScale());
      column.setNotNull(ccolumn.getNotNull());
      column.setUnique(ccolumn.getUnique());
      column.setUniqueKey(ccolumn.getUniqueKey());
      column.setSqlType(ccolumn.getSqlType());
      column.setCheck(ccolumn.getCheck());
    }
    return column;
  }

  public static Type createType(final TypeType ctype, final TypeType defaultType) {
    final Type type = new TypeImpl();

    if (!(ctype == null || ctype.getName() == null)) {
      type.setName(ctype.getName());
    }
    else {
      type.setName(defaultType.getName());
    }

    return type;
  }

  public static org.jvnet.hyperjaxb2.hibernate.mapping.List createList(
      final AbstractCollectionPropertyType cproperty,
      final String name,
      final String defaultTableName,
      final String defaultKeyColumnName,
      final String defaultListIndexColumnName,
      final Collection content) {
    final org.jvnet.hyperjaxb2.hibernate.mapping.List list = new ListImpl();

    // @name
    list.setName(name);

    // @access
    if (!(cproperty == null || cproperty.getAccess() == null)) {
      list.setAccess(cproperty.getAccess());
    }
    else {
      list.setAccess(ListAccessor.class.getName());
    }

    if (!(cproperty == null || cproperty.getTable() == null)) {
      // @table
      list.setTable(cproperty.getTable().getName());
      // @schema
      list.setSchema(cproperty.getTable().getSchema());
      // @catalog
      list.setCatalog(cproperty.getTable().getCatalog());
    }
    else {
      // @table
      list.setTable(defaultTableName);
    }

    if (cproperty != null) {

      // @lazy
      list.setLazy(cproperty.getLazy());
      // @inverse
      list.setInverse(cproperty.getInverse());
      // @cascade
      list.setCascade(cproperty.getCascade());
      // @where
      list.setWhere(cproperty.getWhere());
      // @batch-size
      list.setBatchSize(cproperty.getBatchSize());
      // @outer-join
      list.setOuterJoin(cproperty.getOuterJoin());
      // @fetch
      list.setFetch(cproperty.getFetch());
      // @persister
      list.setPersister(cproperty.getPersister());
      // @check
      list.setCheck(cproperty.getCheck());
      // @optimistic-lock
      list.setOptimisticLock(cproperty.getOptimisticLock());
    }

    if (!(cproperty == null || cproperty.getCache() == null)) {
      list.getContent().add(createCache(cproperty.getCache(), "read-only"));
    }

    final KeyType ckey = (cproperty == null) ? null : cproperty.getKey();
    list.getContent().add(createKey(ckey, defaultKeyColumnName));
    final ListIndexType clistIndex = (cproperty == null) ? null : cproperty.getListIndex();
    list.getContent().add(createListIndex(clistIndex, defaultListIndexColumnName));
    list.getContent().addAll(content);
    return list;

  }

  public static Cache createCache(final CacheType ccache, String defaultUsage) {
    final Cache cache = new CacheImpl();
    // cache/@usage
    if (!(ccache == null || ccache.getUsage() == null)) {
      cache.setUsage(ccache.getUsage());
    }
    else {
      cache.setUsage(defaultUsage);
    }
    // cache/@region
    if (ccache != null) {
      cache.setRegion(ccache.getRegion());
    }
    return cache;
  }

  public static Key createKey(final KeyType ckey, String defaultKeyColumnName) {
    final Key key = new KeyImpl();

    if (!(ckey == null || ckey.getColumn() == null || ckey.getColumn().isEmpty())) {
      for (final Iterator iterator = ckey.getColumn().iterator(); iterator.hasNext();) {
        final ColumnType ccolumn = (ColumnType) iterator.next();
        key.getColumn().add(createColumn(ccolumn, defaultKeyColumnName));
      }
    }
    else {
      key.getColumn().add(createColumn(null, defaultKeyColumnName));
    }

    if (ckey != null) {
      key.setPropertyRef(ckey.getPropertyRef());
      key.setForeignKey(ckey.getForeignKey());
      key.setOnDelete(ckey.getOnDelete());
      key.setNotNull(ckey.getNotNull());
      key.setUpdate(ckey.getUpdate());
      key.setUnique(ckey.getUnique());
    }

    return key;
  }

  public static ListIndex createListIndex(
      ListIndexType clistIndex,
      String defaultListIndexColumnName) {
    final ListIndex listIndex = new ListIndexImpl();

    final ColumnType ccolumn;
    if (!(clistIndex == null || clistIndex.getColumn() == null)) {
      ccolumn = clistIndex.getColumn();
    }
    else {
      ccolumn = null;
    }

    listIndex.setColumn(createColumn(ccolumn, defaultListIndexColumnName));

    if (clistIndex != null) {
      listIndex.setBase(clistIndex.getBase());
    }
    return listIndex;
  }

  public static Element createElement(
      ElementType celement,
      TypeType defaultType,
      String defaultElementColumnName) {
    final Element element = new ElementImpl();

    // @type
    if (celement != null && celement.getType() != null) {
      element.setType(celement.getType().getName());
    }
    else {
      element.setType(defaultType.getName());
    }
    // column
    final ColumnType ccolumn;
    if (celement != null && celement.getColumn() != null) {
      ccolumn = celement.getColumn();
    }
    else {
      ccolumn = null;
    }
    element.getContent().add(createColumn(ccolumn, defaultElementColumnName));

    return element;
  }

  public static OneToMany createOneToMany(OneToManyType coneToMany, String clazz) {
    final OneToMany oneToMany = new OneToManyImpl();
    // @class
    oneToMany.setClazz(clazz);
    // @not-found
    if (coneToMany != null) {
      oneToMany.setNotFound(coneToMany.getNotFound());
    }
    return oneToMany;
  }

  public static ManyToMany createManyToMany(
      ManyToManyType cmanyToMany,
      String clazz,
      String defaultManyToManyColumnName) {
    final ManyToMany manyToMany = new ManyToManyImpl();

    // @class
    manyToMany.setClazz(clazz);

    if (cmanyToMany != null) {
      // @not-found
      manyToMany.setNotFound(cmanyToMany.getNotFound());
      // @outer-join
      manyToMany.setOuterJoin(cmanyToMany.getOuterJoin());
      // @fetch
      manyToMany.setFetch(cmanyToMany.getFetch());
      // @lazy
      manyToMany.setLazy(cmanyToMany.getLazy());
      // @foreign-key
      manyToMany.setForeignKey(cmanyToMany.getForeignKey());
      // @unique
      manyToMany.setUnique(cmanyToMany.getUnique());
      // @where
      manyToMany.setWhere(cmanyToMany.getWhere());
    }

    final ColumnType ccolumn;
    if (!(cmanyToMany == null || cmanyToMany.getColumn() == null)) {
      ccolumn = cmanyToMany.getColumn();
    }
    else {
      ccolumn = null;
    }
    manyToMany.getContent().add(createColumn(ccolumn, defaultManyToManyColumnName));

    return manyToMany;
  }

  public static Any createAny(
      final WildcardSinglePropertyType cproperty,
      final String name,
      final String idType,
      final String defaultMetaType,
      final String defaultAnyClassColumnName,
      final String defaultAnyIdColumnName) {
    final Any any = new AnyImpl();
    // @id-type
    any.setIdType(idType);
    // @name
    any.setName(name);
    // @meta-type
    if (!(cproperty == null || cproperty.getMetaType() == null)) {
      any.setMetaType(cproperty.getMetaType());
    }
    else {
      any.setMetaType(defaultMetaType);
    }
    if (cproperty != null) {
      // @access
      any.setAccess(cproperty.getAccess());
      // @update
      any.setUpdate(cproperty.getUpdate());
      // @insert
      any.setInsert(cproperty.getInsert());
      // @optimistic-lock
      any.setOptimisticLock(cproperty.getOptimisticLock());
      // @cascade
      any.setCascade(cproperty.getCascade());
      // @lazy
      any.setLazy(cproperty.getLazy());
    }
    {
      final ColumnType ccolumn;
      if (cproperty != null && cproperty.getClassColumn() != null) {
        ccolumn = cproperty.getClassColumn();
      }
      else {
        ccolumn = null;
      }
      any.setFirstColumn(Utils.createColumn(ccolumn, defaultAnyClassColumnName));

    }
    {
      final ColumnType ccolumn;
      if (cproperty != null && cproperty.getIdColumn() != null) {
        ccolumn = cproperty.getIdColumn();
      }
      else {
        ccolumn = null;
      }
      any.getColumns().add(Utils.createColumn(ccolumn, defaultAnyIdColumnName));

    }
    return any;
  }

  public static ManyToAny createManyToAny(
      ManyToAnyType cproperty,
      String idType,
      String defaultMetaType,
      String defaultManyToAnyClassColumnName,
      String defaultManyToAnyIdColumnName) {
    final ManyToAny manyToAny = new ManyToAnyImpl();

    manyToAny.setIdType(idType);

    if (cproperty != null) {
      if (cproperty.getMetaType() != null) {
        manyToAny.setMetaType(cproperty.getMetaType());
      }
      else {
        manyToAny.setMetaType(defaultMetaType);
      }
    }

    {
      final ColumnType ccolumn;
      if (cproperty != null && cproperty.getClassColumn() != null) {
        ccolumn = cproperty.getClassColumn();
      }
      else {
        ccolumn = null;
      }
      manyToAny.setFirstColumn(Utils.createColumn(ccolumn, defaultManyToAnyClassColumnName));

    }
    {
      final ColumnType ccolumn;
      if (cproperty != null && cproperty.getIdColumn() != null) {
        ccolumn = cproperty.getIdColumn();
      }
      else {
        ccolumn = null;
      }
      manyToAny.getColumns().add(Utils.createColumn(ccolumn, defaultManyToAnyIdColumnName));
    }

    return manyToAny;
  }

  public static Property createProperty(
      final SimpleSinglePropertyType cproperty,
      final String propertyName,
      final String defaultColumnName,
      final TypeType defaultType) {
    final Property property = new PropertyImpl();
    if (cproperty != null && cproperty.getColumn() != null) {
      property.getContent().add(Utils.createColumn(cproperty.getColumn(), defaultColumnName));
    }
    else
    {
      property.getContent().add(Utils.createColumn(null, defaultColumnName));
    }
      
    final TypeType ctype;
    if (cproperty != null && cproperty.getType() != null) {
      ctype = cproperty.getType();
    }
    else {
      ctype = null;
    }
    property.getContent().add(createType(ctype, defaultType));
    property.setName(propertyName);
    if (cproperty != null) {
      property.setAccess(cproperty.getAccess());
      property.setUpdate(cproperty.getUpdate());
      property.setInsert(cproperty.getInsert());
      property.setOptimisticLock(cproperty.getOptimisticLock());
      property.setLazy(cproperty.getLazy());
    }
    return property;
  }

  public static OneToOne createOneToOne(
      final OneToOneType coneToOne,
      final String propertyName,
      final String clazz) {
    final OneToOne oneToOne = new OneToOneImpl();
    // @name
    oneToOne.setName(propertyName);
    // @class
    oneToOne.setClazz(clazz);
    if (coneToOne != null) {
      // @access
      oneToOne.setAccess(coneToOne.getAccess());
      // @cascade
      oneToOne.setCascade(coneToOne.getCascade());
      // @outer-join
      oneToOne.setOuterJoin(coneToOne.getOuterJoin());
      // @fetch
      oneToOne.setFetch(coneToOne.getFetch());
      // @constrained
      oneToOne.setConstrained(coneToOne.getConstrained());
      // @foreign-key
      oneToOne.setForeignKey(coneToOne.getForeignKey());
      // @property-ref
      oneToOne.setPropertyRef(coneToOne.getPropertyRef());
      // @lazy
      oneToOne.setLazy(coneToOne.getLazy());
    }

    return oneToOne;
  }

  public static ManyToOne createManyToOne(
      final ManyToOneType cmanyToOne,
      final String propertyName,
      final String defaultColumnName,
      final String clazz) {
    final ManyToOne manyToOne = new ManyToOneImpl();
    if (cmanyToOne != null && cmanyToOne.getColumn() != null) {
      manyToOne.getContent().add(Utils.createColumn(cmanyToOne.getColumn(), defaultColumnName));
    }
    else
    {
      manyToOne.getContent().add(Utils.createColumn(null, defaultColumnName));
    }
    // @name
    manyToOne.setName(propertyName);
    // @class
    manyToOne.setClazz(clazz);

    if (cmanyToOne != null) {
      // @access
      manyToOne.setAccess(cmanyToOne.getAccess());
      // @update
      manyToOne.setUpdate(cmanyToOne.getUpdate());
      // @insert
      manyToOne.setInsert(cmanyToOne.getInsert());
      // @optimistic-lock
      manyToOne.setOptimisticLock(cmanyToOne.getOptimisticLock());
      // @cascade
      manyToOne.setCascade(cmanyToOne.getCascade());
      // @outer-join
      manyToOne.setOuterJoin(cmanyToOne.getOuterJoin());
      // @fetch
      manyToOne.setFetch(cmanyToOne.getFetch());
      // @foreign-key
      manyToOne.setForeignKey(cmanyToOne.getForeignKey());
      // @property-ref
      manyToOne.setPropertyRef(cmanyToOne.getPropertyRef());
      // @not-found
      manyToOne.setNotFound(cmanyToOne.getNotFound());
      // @lazy
      manyToOne.setLazy(cmanyToOne.getLazy());
    }
    return manyToOne;
  }

  public static Subclass createImplSubclass(
      final ClassType cclass,
      final String subclassName,
      final String defaultDiscriminatorValue) {
    final Subclass subclass = new SubclassImpl();
    // @name
    subclass.setName(subclassName);
    // @proxy
    subclass.setProxy(cclass.getProxy());
    // @discriminator-value
    if (cclass.getDiscriminatorValue() != null) {
      subclass.setDiscriminatorValue(cclass.getDiscriminatorValue());
    }
    else {
      subclass.setDiscriminatorValue(defaultDiscriminatorValue);
    }
    // @dynamic-update
    subclass.setDynamicUpdate(cclass.getDynamicUpdate());
    // @dynamic-insert
    subclass.setDynamicInsert(cclass.getDynamicInsert());
    // @select-before-update
    subclass.setSelectBeforeUpdate(cclass.getSelectBeforeUpdate());
    // @lazy
    subclass.setLazy(cclass.getLazy());
    // @persister
    subclass.setPersister(cclass.getPersister());
    // @batch-size
    subclass.setBatchSize(cclass.getBatchSize());
    return subclass;
  }

  public static Clazz createClass(
      final ClassType cclass,
      final String className,
      final String implClassName,
      final String defaultTableName,
      final String defaultDiscriminatorValue,
      final String defaultCacheUsage,
      final Object id,
      final Object discriminator,
      final Object version,
      final List fieldMappings) {
    final Clazz clazz = new org.jvnet.hyperjaxb2.hibernate.mapping.impl.ClazzImpl();

    if (!(cclass == null || cclass.getTable() == null)) {
      // @table
      clazz.setTable(cclass.getTable().getName());
      // @schema
      clazz.setSchema(cclass.getTable().getSchema());
      // @catalog
      clazz.setCatalog(cclass.getTable().getCatalog());
    }
    else {
      // @table
      clazz.setTable(defaultTableName);
    }

    // @name
    clazz.setName(className);

    // @proxy
    clazz.setProxy(cclass.getProxy());

    // @lazy
    clazz.setLazy(cclass.getLazy());

    // @polymorphism
    clazz.setPolymorphism(cclass.getPolymorphism());

    // @where
    clazz.setWhere(cclass.getWhere());

    // @persister
    clazz.setPersister(cclass.getPersister());

    // @dynamic-update
    clazz.setDynamicUpdate(cclass.getDynamicUpdate());

    // @dynamic-insert
    clazz.setDynamicInsert(cclass.getDynamicInsert());

    // @batch-size
    clazz.setBatchSize(cclass.getBatchSize());

    // @select-before-update
    clazz.setSelectBeforeUpdate(cclass.getSelectBeforeUpdate());

    // @optimistic-lock
    clazz.setOptimisticLock(cclass.getOptimisticLock());

    // @check
    clazz.setCheck(cclass.getCheck());

    // cache
    if (cclass.getCache() != null) {
      final CacheType ccache = cclass.getCache();
      final Cache cache = Utils.createCache(ccache, defaultCacheUsage);
      clazz.getContent().add(cache);
    }

    clazz.getContent().add(id);
    clazz.getContent().add(discriminator);
    clazz.getContent().add(version);
    clazz.getContent().addAll(fieldMappings);

    clazz.getContent().add(
        Utils.createImplSubclass(cclass, implClassName, defaultDiscriminatorValue));

    return clazz;
  }

  public static Subclass createSubclass(
      final ClassType cclass,
      String className,
      String implClassName,
      String superClassName,
      String defaultDiscriminatorValue,
      List fieldMappings,
      String defaultTableName,
      String defaultIdentifierColumnName) {
    final Subclass clazz = new SubclassImpl();

    // @name
    clazz.setName(className);

    // @extends
    clazz.setExtends(superClassName);

    // @proxy
    clazz.setProxy(cclass.getProxy());

    // @lazy
    clazz.setLazy(cclass.getLazy());

    // @persister
    clazz.setPersister(cclass.getPersister());

    // @dynamic-update
    clazz.setDynamicUpdate(cclass.getDynamicUpdate());

    // @dynamic-insert
    clazz.setDynamicInsert(cclass.getDynamicInsert());

    // @batch-size
    clazz.setBatchSize(cclass.getBatchSize());

    // @select-before-update
    clazz.setSelectBeforeUpdate(cclass.getSelectBeforeUpdate());

    // if (cclass.getTable() == null) {
    // cclass.setTable(new TableTypeImpl());
    // cclass.getTable().setName(
    // principalStrategy.getTableStrategy().getTableName(
    // classContext));
    // }

    // clazz.set

    final List classContnt = new ArrayList();

    final List joinContent = new ArrayList();

    for (final Iterator iterator = fieldMappings.iterator(); iterator.hasNext();) {
      final Object mapping = iterator.next();
      if (mapping instanceof Property
          || mapping instanceof ManyToOne
          || mapping instanceof Component
          || mapping instanceof DynamicComponent
          || mapping instanceof Any) {
        joinContent.add(mapping);
      }
      else {
        classContnt.add(mapping);
      }

    }
    clazz.getContent().addAll(classContnt);
    if (!joinContent.isEmpty()) {
      final Join join = Utils.createJoin(
          cclass,
          joinContent,
          defaultTableName,
          defaultIdentifierColumnName);
      clazz.getContent().add(join);
    }

    clazz.getContent().add(
        Utils.createImplSubclass(cclass, implClassName, defaultDiscriminatorValue));

    return clazz;
  }

  public static Join createJoin(
      final ClassType cclass,
      final List content,
      final String defaultTableName,
      final String defaultKeyColumnName) {
    final Join join = new JoinImpl();

    if (!(cclass == null || cclass.getTable() == null)) {
      // @table
      join.setTable(cclass.getTable().getName());
      // @schema
      join.setSchema(cclass.getTable().getSchema());
      // @catalog
      join.setCatalog(cclass.getTable().getCatalog());
    }
    else {
      // @table
      join.setTable(defaultTableName);
    }

    final Key key = createKey(cclass.getKey(), defaultKeyColumnName);
    join.getContent().add(key);
    join.getContent().addAll(content);
    return join;
  }

  public static Generator createGenerator(
      final GeneratorType cgenerator,
      final String defaultGeneratorClass) {
    final Generator generator = new GeneratorImpl();
    if (cgenerator != null) {
      if (cgenerator.getGeneratorClass() != null) {
        generator.setClazz(cgenerator.getGeneratorClass());
      }
      else {
        generator.setClazz(defaultGeneratorClass);
      }

      if (cgenerator.getParam() != null) {
        for (Iterator iterator = cgenerator.getParam().iterator(); iterator.hasNext();) {
          final ParamType cparam = (ParamType) iterator.next();
          final Param param = new ParamImpl();
          param.setName(cparam.getName());
          param.setContent(cparam.getValue());
          generator.getParam().add(param);
        }
      }
    }
    else {
      generator.setClazz(defaultGeneratorClass);
    }
    return generator;
  }

  public static Id createId(
      final IdType cid,
      final String fieldPropertyName,
      final String idType,
      final String defaultGeneratorClass) {
    final Id id = new IdImpl();

    if (cid != null && cid.getColumn() != null && !cid.getColumn().isEmpty()) {
      for (final Iterator iterator = cid.getColumn().iterator(); iterator.hasNext();) {
        final ColumnType ccolumn = (ColumnType) iterator.next();
        final Column column = createColumn(ccolumn, fieldPropertyName);
        id.getColumn().add(column);
      }
    }

    final GeneratorType cgenerator;
    if (cid != null) {
      cgenerator = cid.getGenerator();
    }
    else {
      cgenerator = null;
    }

    id.setGenerator(createGenerator(cgenerator, defaultGeneratorClass));

    // @name
    id.setName(fieldPropertyName);
    // @type
    if (cid != null && cid.getType() != null) {
      id.setType(cid.getType().getName());
    }
    else {
      id.setType(idType);
    }

    if (cid != null) {
      id.setAccess(cid.getAccess());
      id.setUnsavedValue(cid.getUnsavedValue());
    }

    return id;
  }

  public static Version createVersion(
      final VersionType cversion,
      final String fieldPropertyName,
      final String fieldType) {
    final Version version = new VersionImpl();
    version.setName(fieldPropertyName);

    if (cversion != null && cversion.getColumn() != null) {
      final Column column = createColumn(cversion.getColumn(), fieldPropertyName);
      version.setColumn(column.getName());
    }

    if (cversion != null && cversion.getType() != null) {
      version.setType(cversion.getType().getName());
    }
    else {
      version.setType(fieldType);
    }

    if (cversion != null) {
      version.setAccess(cversion.getAccess());
      version.setUnsavedValue(cversion.getUnsavedValue());
    }
    return version;
  }

  public static Discriminator createDiscriminator(
      final DiscriminatorType cdiscriminator,
      final String defaultName,
      final String defaultType) {

    final Discriminator discriminator = new DiscriminatorImpl();

    if (cdiscriminator != null) {
      discriminator.setForce(cdiscriminator.getForce());
      discriminator.setInsert(cdiscriminator.getInsert());
    }

    if (cdiscriminator != null && cdiscriminator.getColumn() != null) {
      final Column column = createColumn(cdiscriminator.getColumn(), defaultName);
      discriminator.setContent(column);
    }
    else {
      final Column column = createColumn(null, defaultName);
      discriminator.setContent(column);
    }

    if (cdiscriminator != null && cdiscriminator.getType() != null) {
      discriminator.setType(cdiscriminator.getType());
    }
    else {
      discriminator.setType(defaultType);
    }
    return discriminator;
  }

  public static boolean isIgnored(FieldItem item) {
    return CustomizationUtils.containsCustomization(item, Constants.IGNORED);
  }

  public static boolean isIgnored(ClassItem item) {

    return CustomizationUtils.containsCustomization(item, Constants.IGNORED)
        || (item.getSuperClass() != null && isIgnored(item.getSuperClass()));
  }

  public static Component createComponent(
      ComponentType ccomponent,
      String name,
      String clazz,
      List fieldMappings) {

    final Component component = new ComponentImpl();

    component.setName(name);
    component.setClazz(clazz);

    if (ccomponent != null) {
      component.setAccess(ccomponent.getAccess());
      component.setUnique(ccomponent.getUnique());
      component.setUpdate(ccomponent.getUpdate());
      component.setInsert(ccomponent.getInsert());
      component.setLazy(ccomponent.getLazy());
      component.setOptimisticLock(ccomponent.getOptimisticLock());
    }

    component.getContent().addAll(fieldMappings);

    return component;
  }
}