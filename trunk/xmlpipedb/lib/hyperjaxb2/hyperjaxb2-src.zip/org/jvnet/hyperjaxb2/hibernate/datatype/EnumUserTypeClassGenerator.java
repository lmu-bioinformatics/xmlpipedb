/*
 * Created on 29.06.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.jvnet.hyperjaxb2.hibernate.datatype;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;
import org.jvnet.jaxbcommons.addon.generator.ClassGenerator;

import com.sun.codemodel.JClassAlreadyExistsException;
import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JConditional;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JExpr;
import com.sun.codemodel.JFieldVar;
import com.sun.codemodel.JMethod;
import com.sun.codemodel.JMod;
import com.sun.codemodel.JOp;
import com.sun.codemodel.JVar;

/**
 * 
 * @author valikov
 */
public class EnumUserTypeClassGenerator extends ClassGenerator {

  private final JDefinedClass enumClass;

  public EnumUserTypeClassGenerator(JDefinedClass enumClass) {
    this.enumClass = enumClass;
  }

  protected JDefinedClass generateClass() throws JClassAlreadyExistsException {
    final JDefinedClass theClass = enumClass._class(JMod.PUBLIC | JMod.STATIC, "Type");
    theClass._implements(UserType.class);
    theClass._implements(Serializable.class);
    return theClass;
  }

  protected void generateFields() {
    // todo use serializable extension
    final JFieldVar serialVersionUID = theClass.field(
        JMod.PRIVATE | JMod.STATIC | JMod.FINAL,
        theClass.owner().LONG,
        "serialVersionUID",
        JExpr.lit(1L));
  }

  protected void generateMethods() {
    final JCodeModel codeModel = theClass.owner();
    {
      theClass.method(JMod.PUBLIC, theClass.owner().INT.array(), "sqlTypes").body()._return(
          JExpr.newArray(theClass.owner().INT).add(
              theClass.owner().ref(Types.class).staticRef("VARCHAR")));
    }

    {
      theClass.method(JMod.PUBLIC, Class.class, "returnedClass").body()._return(
          enumClass.staticRef("class"));
    }

    {
      final JMethod equals = theClass.method(JMod.PUBLIC, boolean.class, "equals");
      final JVar x = equals.param(Object.class, "x");
      final JVar y = equals.param(Object.class, "y");
      equals.body()._return(JOp.eq(x, y));
    }

    {
      final JMethod deepCopy = theClass.method(JMod.PUBLIC, Object.class, "deepCopy");
      final JVar param = deepCopy.param(Object.class, "value");
      deepCopy.body()._return(param);
    }

    {
      theClass.method(JMod.PUBLIC, boolean.class, "isMutable").body()._return(JExpr.FALSE);
    }

    {
      final JMethod nullSafeGet = theClass.method(JMod.PUBLIC, Object.class, "nullSafeGet");

      final JVar resultSet = nullSafeGet.param(ResultSet.class, "resultSet");
      final JVar names = nullSafeGet.param(theClass.owner().ref(String.class).array(), "names");
      nullSafeGet.param(Object.class, "owner");

      nullSafeGet._throws(HibernateException.class);
      nullSafeGet._throws(SQLException.class);

      final JVar name = nullSafeGet.body().decl(
          theClass.owner().ref(String.class),
          "name",
          resultSet.invoke("getString").arg(names.component(JExpr.lit(0))));

      nullSafeGet.body()._return(
          JOp.cond(resultSet.invoke("wasNull"), JExpr._null(), enumClass
              .staticInvoke("fromString")
              .arg(name)));
    }

    {

      final JMethod nullSafeSet = theClass.method(JMod.PUBLIC, Void.TYPE, "nullSafeSet");

      final JVar statement = nullSafeSet.param(PreparedStatement.class, "statement");
      final JVar value = nullSafeSet.param(Object.class, "value");
      final JVar index = nullSafeSet.param(int.class, "index");

      nullSafeSet._throws(HibernateException.class);
      nullSafeSet._throws(SQLException.class);

      final JConditional _if = nullSafeSet.body()._if(JOp.eq(value, JExpr._null()));

      _if._then().invoke(statement, "setNull").arg(index).arg(
          theClass.owner().ref(Types.class).staticRef("VARCHAR"));

      _if._else().invoke(statement, "setString").arg(index).arg(value.invoke("toString"));
    }
    
    {
      final JMethod disassemble = theClass.method(JMod.PUBLIC, Serializable.class, "disassemble");
      disassemble._throws(HibernateException.class);
      final JVar value = disassemble.param(Object.class, "value");
      disassemble.body()._return(JExpr.cast(codeModel.ref(Serializable.class), value));
    }
    
    {
      final JMethod assemble = theClass.method(JMod.PUBLIC, Object.class, "assemble");
      assemble._throws(HibernateException.class);
      final JVar cached = assemble.param(Serializable.class, "cached");
      final JVar owner = assemble.param(Object.class, "owner");
      assemble.body()._return(cached);
      
    }
    
    {
      final JMethod replace = theClass.method(JMod.PUBLIC, Object.class, "replace");
      replace._throws(HibernateException.class);
      final JVar original = replace.param(Object.class, "original");
      final JVar target = replace.param(Object.class, "target");
      final JVar owner = replace.param(Object.class, "owner");
      replace.body()._return(original);
      
    }
    {
      final JMethod hashCode = theClass.method(JMod.PUBLIC, codeModel.INT, "hashCode");
      final JVar object = hashCode.param(Object.class, "object");
      hashCode.body()._return(object.invoke("hashCode"));
    }
  }
}
