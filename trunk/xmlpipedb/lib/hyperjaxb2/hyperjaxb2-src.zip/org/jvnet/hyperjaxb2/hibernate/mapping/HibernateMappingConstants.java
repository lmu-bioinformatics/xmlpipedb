package org.jvnet.hyperjaxb2.hibernate.mapping;

public class HibernateMappingConstants {
  
  public static final String JAXB_PACKAGE_NAMES = HibernateMapping.class.getPackage().getName();
  public static final String DOCTYPE_PUBLIC = "-//Hibernate/Hibernate Mapping DTD 3.0//EN";
  public static final String DOCTYPE_SYSTEM = "http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd";
}
