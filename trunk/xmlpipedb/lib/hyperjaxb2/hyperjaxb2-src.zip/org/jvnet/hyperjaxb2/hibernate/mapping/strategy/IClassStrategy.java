package org.jvnet.hyperjaxb2.hibernate.mapping.strategy;


import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;

import com.sun.tools.xjc.generator.ClassContext;

public interface IClassStrategy {
  
  public Object generateMapping(IPrincipalStrategy principalStrategy, ClassContext classContext);

}
