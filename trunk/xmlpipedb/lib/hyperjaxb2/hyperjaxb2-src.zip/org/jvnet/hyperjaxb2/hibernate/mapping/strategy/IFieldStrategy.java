package org.jvnet.hyperjaxb2.hibernate.mapping.strategy;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public interface IFieldStrategy {

  public Object generateMapping(IPrincipalStrategy principalStrategy, ClassContext classContext, FieldItem fieldItem);
}
