package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.clazz;

import java.util.List;

import org.jvnet.hyperjaxb2.customizations.CacheType;
import org.jvnet.hyperjaxb2.customizations.ClassType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.customizations.impl.TableTypeImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.Cache;
import org.jvnet.hyperjaxb2.hibernate.mapping.Clazz;
import org.jvnet.hyperjaxb2.hibernate.mapping.HibernateMapping;
import org.jvnet.hyperjaxb2.hibernate.mapping.Subclass;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.HibernateMappingImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.ClassUtils;
import org.jvnet.jaxbcommons.util.CodeModelUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;

public class ClassStrategy implements IClassStrategy {

  public Object generateMapping(IPrincipalStrategy principalStrategy, ClassContext classContext) {

    final HibernateMapping hibernateMapping = new HibernateMappingImpl();
    hibernateMapping.setAutoImport("false");
    hibernateMapping.setDefaultLazy("false");
    hibernateMapping.setDefaultCascade("all-delete-orphan");

    final ClassItem classItem = classContext.target;

    final ClassType cclass = Utils.getClazz(classItem);

    final String defaultTableName = principalStrategy.getNamingStrategy().getTableName(classContext);
    final String implClassName = CodeModelUtils.getClassName(classContext.implClass);
    final String className = ClassUtils.getClassName(classItem);
    final String defaultCacheUsage = "read-write";
    final String defaultDiscriminatorValue = classContext.ref.fullName();

    final List fieldMappings = (List) principalStrategy.getFieldsStrategy().generateMapping(
        principalStrategy,
        classContext);

    final Object id = principalStrategy.getIdentifierStrategy().generateMapping(
        principalStrategy,
        classContext);

    final Object discriminator = principalStrategy.getDiscriminatorStrategy().generateMapping(
        principalStrategy,
        classContext);

    final Object version = principalStrategy.getVersionStrategy().generateMapping(
        principalStrategy,
        classContext);

    final Clazz clazz = Utils.createClass(
        cclass,
        className,
        implClassName,
        defaultTableName,
        defaultDiscriminatorValue,
        defaultCacheUsage,
        id,
        discriminator,
        version,
        fieldMappings);

    hibernateMapping.getContent().add(clazz);
    return hibernateMapping;
  }
}
