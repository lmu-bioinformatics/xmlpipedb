package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.clazz;

import java.util.List;

import org.jvnet.hyperjaxb2.customizations.ClassType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.HibernateMapping;
import org.jvnet.hyperjaxb2.hibernate.mapping.Subclass;
import org.jvnet.hyperjaxb2.hibernate.mapping.impl.HibernateMappingImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.ClassUtils;
import org.jvnet.jaxbcommons.util.CodeModelUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;

public class SubclassStrategy implements IClassStrategy {

    public Object generateMapping(IPrincipalStrategy principalStrategy,
            ClassContext classContext) {

        final HibernateMapping hibernateMapping = new HibernateMappingImpl();
        hibernateMapping.setAutoImport("false");
        hibernateMapping.setDefaultLazy("false");
        hibernateMapping.setDefaultCascade("all-delete-orphan");

        final ClassItem classItem = classContext.target;
        final ClassItem superClassItem = classItem.getSuperClass();

        final ClassType cclass = Utils.getClazz(classItem);

        final String className = ClassUtils.getClassName(classItem);
        final String implClassName = CodeModelUtils
                .getClassName(classContext.implClass);
        final String superClassName = ClassUtils.getClassName(superClassItem);
        final String defaultDiscriminatorValue = classContext.ref.fullName();
        final String defaultTableName = principalStrategy.getNamingStrategy()
                .getTableName(classContext);

        final String defaultIdentifierColumnName = "Hjid";
        final List fieldMappings = (List) principalStrategy.getFieldsStrategy()
                .generateMapping(principalStrategy, classContext);

        final Subclass clazz = Utils.createSubclass(cclass, className,
                implClassName, superClassName, defaultDiscriminatorValue,

                fieldMappings, defaultTableName, defaultIdentifierColumnName);

        hibernateMapping.getContent().add(clazz);

        return hibernateMapping;
    }
}
