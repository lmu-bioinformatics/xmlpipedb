package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IFieldStrategy;


public abstract class AbstractFieldStrategy implements IFieldStrategy {
}
