package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection;

import java.util.Collection;

import org.jvnet.hyperjaxb2.customizations.AbstractCollectionPropertyType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.List;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.AbstractFieldStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.FieldUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public abstract class AbstractCollectionFieldStrategy extends AbstractFieldStrategy {

  public Object generateMapping(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {

    final AbstractCollectionPropertyType cproperty = getCollectionProperty(fieldItem);

    final List list = Utils.createList(
        cproperty,
        FieldUtils.getFieldPropertyName(fieldItem),
        principalStrategy.getNamingStrategy().getCollectionTableName(classContext, fieldItem),
        principalStrategy.getNamingStrategy().getCollectionTableSubColumnName(
            classContext,
            fieldItem,
            "Hjid"),
        principalStrategy.getNamingStrategy().getCollectionTableSubColumnName(
            classContext,
            fieldItem,
            "Hjindex"),
        getContent(principalStrategy, classContext, fieldItem));

    return list;
  }

  public abstract AbstractCollectionPropertyType getCollectionProperty(FieldItem fieldItem);

  public abstract Collection getContent(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem);

}
