package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection;

import java.util.Collection;
import java.util.Collections;

import org.jvnet.hyperjaxb2.customizations.AbstractCollectionPropertyType;
import org.jvnet.hyperjaxb2.customizations.SimpleCollectionPropertyType;
import org.jvnet.hyperjaxb2.customizations.TypeType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.Element;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public abstract class AbstractSimpleCollectionFieldStrategy extends AbstractCollectionFieldStrategy {

  public Collection getContent(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {

    final SimpleCollectionPropertyType cproperty = Utils.getSimpleCollectionProperty(fieldItem);

    final Element element = Utils.createElement(cproperty.getElement(), getDefaultType(
        principalStrategy,
        classContext,
        fieldItem), "Hjvalue");

    return Collections.singletonList(element);
  }
  
  public AbstractCollectionPropertyType getCollectionProperty(FieldItem fieldItem) {
    return Utils.getSimpleCollectionProperty(fieldItem);
  }

  protected abstract TypeType getDefaultType(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem);
}
