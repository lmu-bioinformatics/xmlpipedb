package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection;

import java.util.Collection;
import java.util.Collections;

import org.jvnet.hyperjaxb2.customizations.AbstractCollectionPropertyType;
import org.jvnet.hyperjaxb2.customizations.ComplexCollectionPropertyType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.ManyToMany;
import org.jvnet.hyperjaxb2.hibernate.mapping.OneToMany;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.CodeModelUtils;
import org.jvnet.jaxbcommons.util.TypeUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;

public class ComplexCollectionStrategy extends AbstractCollectionFieldStrategy {

  public Collection getContent(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {

    final ClassItem fieldClassItem = TypeUtils.getClassItem(classContext, fieldItem);
    final ClassContext fieldClassContext = classContext.parent.getClassContext(fieldClassItem);

    final ComplexCollectionPropertyType cproperty = Utils.getComplexCollectionProperty(fieldItem);

    if (cproperty == null || cproperty.getManyToMany() == null) {
      // one-to-many
      final OneToMany oneToMany = Utils.createOneToMany(cproperty.getOneToMany(), CodeModelUtils
          .getClassName(fieldClassContext.ref));

      return Collections.singletonList(oneToMany);
    }
    else {
      // many-to-many

      final ManyToMany manyToMany = Utils.createManyToMany(
          cproperty.getManyToMany(),
          CodeModelUtils.getClassName(fieldClassContext.ref),

          principalStrategy.getNamingStrategy().getCollectionTableSubColumnName(
              fieldClassContext,
              fieldItem,
              "Hjchildid"));

      return Collections.singletonList(manyToMany);
    }
  }

  public AbstractCollectionPropertyType getCollectionProperty(FieldItem fieldItem) {
    return Utils.getComplexCollectionProperty(fieldItem);
  }
}
