package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection;

import org.jvnet.hyperjaxb2.customizations.TypeType;
import org.jvnet.hyperjaxb2.customizations.impl.TypeTypeImpl;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.TypeUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.PrimitiveItem;

public class PrimitiveCollectionStrategy extends AbstractSimpleCollectionFieldStrategy {

  protected TypeType getDefaultType(IPrincipalStrategy principalStrategy, ClassContext classContext, FieldItem fieldItem) {
    final PrimitiveItem primitiveItem = TypeUtils.getPrimitiveTypeItem(fieldItem);
    final TypeType type = new TypeTypeImpl();
    type.setName(principalStrategy.getTypeStrategy().getType(primitiveItem.guard));
    return type;
  }
}
