package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single;

import org.jvnet.hyperjaxb2.customizations.SimpleSinglePropertyType;
import org.jvnet.hyperjaxb2.customizations.TypeType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.FieldUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public abstract class AbstractSimpleSingleFieldStrategy extends AbstractSingleFieldStrategy {

  public Object generateMapping(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {
    final SimpleSinglePropertyType cproperty = Utils.getSimpleSingleProperty(fieldItem);
    final String propertyName = FieldUtils.getFieldPropertyName(fieldItem);
    final String defaultColumnName = principalStrategy.getNamingStrategy().getColumnName(classContext, fieldItem);
    final TypeType defaultType = getDefaultType(principalStrategy, classContext, fieldItem);
    return Utils.createProperty(cproperty, propertyName, defaultColumnName, defaultType);
  }

  protected abstract TypeType getDefaultType(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem);
}
