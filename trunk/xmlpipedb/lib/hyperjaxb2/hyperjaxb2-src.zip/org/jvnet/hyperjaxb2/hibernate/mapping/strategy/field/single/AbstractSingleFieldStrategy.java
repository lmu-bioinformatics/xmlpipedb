package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.AbstractFieldStrategy;

public abstract class AbstractSingleFieldStrategy extends AbstractFieldStrategy {

}
