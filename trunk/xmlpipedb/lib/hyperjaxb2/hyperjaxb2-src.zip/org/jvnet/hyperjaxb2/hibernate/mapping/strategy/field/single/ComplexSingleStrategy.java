package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single;

import java.util.List;

import org.jvnet.hyperjaxb2.customizations.ComplexSinglePropertyType;
import org.jvnet.hyperjaxb2.customizations.ComponentType;
import org.jvnet.hyperjaxb2.customizations.Constants;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.CodeModelUtils;
import org.jvnet.jaxbcommons.util.CustomizationUtils;
import org.jvnet.jaxbcommons.util.FieldUtils;
import org.jvnet.jaxbcommons.util.TypeUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;

public class ComplexSingleStrategy extends AbstractSingleFieldStrategy {

  public Object generateMapping(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {

    final ComplexSinglePropertyType cproperty = Utils.getComplexSingleProperty(fieldItem);

    final String propertyName = FieldUtils.getFieldPropertyName(fieldItem);
    final String defaultColumnName = principalStrategy.getNamingStrategy().getColumnName(classContext, fieldItem);
    final ClassItem fieldClassItem = TypeUtils.getClassItem(classContext, fieldItem);
    final ClassContext fieldClassContext = classContext.parent.getClassContext(fieldClassItem);
    final String refClass = CodeModelUtils.getClassName(fieldClassContext.ref);
    final String implClass = CodeModelUtils.getClassName(fieldClassContext.implClass);

    if (CustomizationUtils.containsCustomization(fieldClassItem, Constants.COMPONENT)) {
      final ComponentType ccomponent = Utils.getComponent(fieldClassItem);
      final List fieldMappings = (List) principalStrategy.getComponentFieldsStrategy().generateMapping(
          principalStrategy,
          classContext,
          fieldItem);
      return Utils.createComponent(ccomponent, propertyName, implClass, fieldMappings);
    }
    else if (cproperty != null) {
      if (cproperty.isSetComponent()) {
        final List fieldMappings = (List) principalStrategy.getComponentFieldsStrategy().generateMapping(
            principalStrategy,
            classContext,
            fieldItem);
        return Utils.createComponent(cproperty.getComponent(), propertyName, implClass, fieldMappings);
      }
      if (cproperty.isSetOneToOne()) {
        return Utils.createOneToOne(cproperty.getOneToOne(), propertyName, refClass);
      }
      else if (cproperty.isSetManyToOne()) {
        return Utils.createManyToOne(cproperty.getManyToOne(), propertyName, defaultColumnName, refClass);
      }
      else {
        return Utils.createManyToOne(null, propertyName, defaultColumnName, refClass);
      }
    }
    else {
      return Utils.createManyToOne(null, propertyName, defaultColumnName, refClass);
    }
  }

}
