package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single;

import org.jvnet.hyperjaxb2.customizations.TypeType;
import org.jvnet.hyperjaxb2.customizations.impl.TypeTypeImpl;
import org.jvnet.hyperjaxb2.hibernate.datatype.EnumUserTypeClassGenerator;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.CodeModelUtils;

import com.sun.codemodel.JDefinedClass;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;

public class EnumSingleStrategy extends AbstractSimpleSingleFieldStrategy {

  protected TypeType getDefaultType(IPrincipalStrategy principalStrategy, ClassContext classContext, FieldItem fieldItem) {
    
    final FieldUse fieldUse = classContext.target.getField(fieldItem.name);
    final JDefinedClass enumClass = (JDefinedClass) fieldUse.type;

    final JDefinedClass enumUserTypeClass = new EnumUserTypeClassGenerator(enumClass)
        .getGeneratedClass();
    
    final TypeType type = new TypeTypeImpl();
    type.setName(CodeModelUtils.getClassName(enumUserTypeClass));
    return type;
  }
}
