package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single;

import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.customizations.WildcardSinglePropertyType;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.FieldUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class WildcardSingleStrategy extends AbstractSingleFieldStrategy {

  public Object generateMapping(
      IPrincipalStrategy principalStrategy,
      ClassContext classContext,
      FieldItem fieldItem) {
    final WildcardSinglePropertyType cproperty = Utils.getWildcardSingleProperty(fieldItem);
    final String name = FieldUtils.getFieldPropertyName(fieldItem);
    final String idType = principalStrategy.getIdentifierStrategy().getPropertyType();
    final String defaultMetaType = principalStrategy.getIdentifierStrategy().getMetaType();

    final String defaultAnyClassColumnName = principalStrategy.getNamingStrategy().getSubColumnName(
        classContext,
        fieldItem,
        "Hjclass");
    final String defaultAnyIdColumnName =

    principalStrategy.getNamingStrategy().getSubColumnName(
        classContext,
        fieldItem,
        "Hjid");
    return Utils.createAny(
        cproperty,
        name,
        idType,
        defaultMetaType,
        defaultAnyClassColumnName,
        defaultAnyIdColumnName);
  }
}
