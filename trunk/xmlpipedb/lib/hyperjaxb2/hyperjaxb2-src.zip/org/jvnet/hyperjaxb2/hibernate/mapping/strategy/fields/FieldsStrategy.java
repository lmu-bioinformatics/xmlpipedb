package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.fields;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jvnet.hyperjaxb2.customizations.Constants;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.hyperjaxb2.hibernate.visitor.HibernateMappingGeneratingVisitor;
import org.jvnet.jaxbcommons.util.CustomizationUtils;
import org.jvnet.jaxbcommons.util.FieldUtils;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;

public class FieldsStrategy implements IClassStrategy {

    public Object generateMapping(IPrincipalStrategy principalStrategy,
            ClassContext classContext) {
        final ClassItem classItem = classContext.target;
        final FieldUse[] fieldUses = classItem.getDeclaredFieldUses();

        final List fieldMappings = new ArrayList();

        final List fieldItems = new ArrayList(fieldUses.length);

        for (int index = 0; index < fieldUses.length; index++) {
            final FieldUse fieldUse = fieldUses[index];
            final FieldItem fieldItem = FieldUtils.getFieldItem(fieldUse);

            if (!CustomizationUtils.containsCustomization(fieldItem,
                    Constants.ID)
                    && !CustomizationUtils.containsCustomization(fieldItem,
                            Constants.VERSION)                  ) {
                fieldItems.add(fieldItem);
            }
        }

        for (Iterator iterator = fieldItems.iterator(); iterator.hasNext();) {
            final FieldItem fieldItem = (FieldItem) iterator.next();

            final Object fieldMapping = fieldItem
                    .visit(new HibernateMappingGeneratingVisitor(
                            principalStrategy, classContext));
            if (fieldMapping != null) {
                fieldMappings.add(fieldMapping);
            }
        }

        return fieldMappings;
    }
}
