package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming;

public class ComponentNamingStrategy {

}
