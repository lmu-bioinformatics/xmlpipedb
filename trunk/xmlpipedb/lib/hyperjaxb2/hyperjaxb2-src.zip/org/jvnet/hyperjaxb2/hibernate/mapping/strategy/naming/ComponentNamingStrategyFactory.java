package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public class ComponentNamingStrategyFactory implements INamingStrategyFactory {
  public INamingStrategy createNamingStrategy(
      final IPrincipalStrategy principalStrategy,
      final ClassContext classContext,
      final FieldItem fieldItem) {

    final INamingStrategy namingStrategy = principalStrategy.getNamingStrategy();
    return new NamingStrategy() {

      private final String columnName = namingStrategy.getColumnName(classContext, fieldItem);

      public String getTableName(ClassContext classContext) {
        return columnName + "_" + super.getTableName(classContext);
      }
      
      public String getCollectionTableName(ClassContext classContext,FieldItem fieldItem)
      {
        return columnName + "_" + super.getColumnName(classContext, fieldItem);
      }
      
      public String getColumnName(ClassContext classContext, FieldItem fieldItem) {
        return columnName + "_" + super.getColumnName(classContext, fieldItem);
      }
    };
  }
}
