package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming;

import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;

public interface INamingStrategy {

  public String getTableName(ClassContext classContext);

  public String getCollectionTableName(ClassContext classContext, FieldItem fieldItem);

  public String getCollectionTableSubColumnName(ClassContext classContext, FieldItem fieldItem, String name);
  
  public String getColumnName(ClassContext classContext, FieldItem fieldItem);

  public String getSubColumnName(ClassContext classContext, FieldItem fieldItem, String name);

}
