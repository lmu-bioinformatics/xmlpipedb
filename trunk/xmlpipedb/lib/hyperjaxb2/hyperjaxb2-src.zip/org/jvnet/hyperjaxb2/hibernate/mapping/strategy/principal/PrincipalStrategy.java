package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IFieldStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.clazz.ClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.clazz.SubclassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection.ComplexCollectionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection.DomCollectionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection.EnumCollectionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection.PrimitiveCollectionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.collection.WildcardCollectionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single.ComplexSingleStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single.DomSingleStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single.EnumSingleStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single.PrimitiveSingleStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.field.single.WildcardSingleStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.fields.ComponentFieldsStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.fields.FieldsStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.ComponentNamingStrategyFactory;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.INamingStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.INamingStrategyFactory;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.NamingStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.DiscriminatorStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IDiscriminatorStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IIdentifierStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IVersionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IdentifierStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.VersionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.type.ITypeStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.type.TypeStrategy;

public class PrincipalStrategy implements IPrincipalStrategy {

  private ITypeStrategy typeStrategy = new TypeStrategy();
  private INamingStrategy namingStrategy = new NamingStrategy();
  private INamingStrategyFactory componentNamingStrategyFactory = new ComponentNamingStrategyFactory();
  private IClassStrategy classStrategy = new ClassStrategy();
  private IClassStrategy subclassStrategy = new SubclassStrategy();
  private IIdentifierStrategy identifierStrategy = new IdentifierStrategy();
  private IDiscriminatorStrategy discriminatorStrategy = new DiscriminatorStrategy();
  private IVersionStrategy versionStrategy = new VersionStrategy();
  private IClassStrategy fieldsStrategy = new FieldsStrategy();
  private IFieldStrategy componentFieldsStrategy = new ComponentFieldsStrategy();

  private IFieldStrategy primitiveSingleStrategy = new PrimitiveSingleStrategy();
  private IFieldStrategy domSingleStrategy = new DomSingleStrategy();
  private IFieldStrategy enumSingleStrategy = new EnumSingleStrategy();
  private IFieldStrategy wildcardSingleStrategy = new WildcardSingleStrategy();
  private IFieldStrategy complexSingleStrategy = new ComplexSingleStrategy();

  private IFieldStrategy primitiveCollectionStrategy = new PrimitiveCollectionStrategy();
  private IFieldStrategy domCollectionStrategy = new DomCollectionStrategy();
  private IFieldStrategy enumCollectionStrategy = new EnumCollectionStrategy();
  private IFieldStrategy wildcardCollectionStrategy = new WildcardCollectionStrategy();
  private IFieldStrategy complexCollectionStrategy = new ComplexCollectionStrategy();

  public IClassStrategy getClassStrategy() {
    return classStrategy;
  }

  public void setClassStrategy(IClassStrategy classStrategy) {
    this.classStrategy = classStrategy;
  }

  public IClassStrategy getSubclassStrategy() {
    return subclassStrategy;
  }

  public void setSubclassStrategy(IClassStrategy subclassStrategy) {
    this.subclassStrategy = subclassStrategy;
  }

  public IIdentifierStrategy getIdentifierStrategy() {
    return identifierStrategy;
  }

  public void setIdentifierStrategy(IIdentifierStrategy identifierStrategy) {
    this.identifierStrategy = identifierStrategy;
  }

  public IDiscriminatorStrategy getDiscriminatorStrategy() {
    return discriminatorStrategy;
  }

  public void setDiscriminatorStrategy(IDiscriminatorStrategy discriminatorStrategy) {
    this.discriminatorStrategy = discriminatorStrategy;
  }

  public IVersionStrategy getVersionStrategy() {
    return versionStrategy;
  }

  public void setVersionStrategy(IVersionStrategy versionStrategy) {
    this.versionStrategy = versionStrategy;
  }

  public IClassStrategy getFieldsStrategy() {
    return fieldsStrategy;
  }

  public void setFieldsStrategy(IClassStrategy fieldsStrategy) {
    this.fieldsStrategy = fieldsStrategy;
  }

  public IFieldStrategy getComponentFieldsStrategy() {
    return componentFieldsStrategy;
  }

  public void setComponentFieldsStrategy(IFieldStrategy componentFieldsStrategy) {
    this.componentFieldsStrategy = componentFieldsStrategy;
  }

  public IFieldStrategy getComplexCollectionStrategy() {
    return complexCollectionStrategy;
  }

  public void setComplexCollectionStrategy(IFieldStrategy complexCollectionStrategy) {
    this.complexCollectionStrategy = complexCollectionStrategy;
  }

  public IFieldStrategy getComplexSingleStrategy() {
    return complexSingleStrategy;
  }

  public void setComplexSingleStrategy(IFieldStrategy complexSingleStrategy) {
    this.complexSingleStrategy = complexSingleStrategy;
  }

  public IFieldStrategy getDomCollectionStrategy() {
    return domCollectionStrategy;
  }

  public void setDomCollectionStrategy(IFieldStrategy domCollectionStrategy) {
    this.domCollectionStrategy = domCollectionStrategy;
  }

  public IFieldStrategy getDomSingleStrategy() {
    return domSingleStrategy;
  }

  public void setDomSingleStrategy(IFieldStrategy domSingleStrategy) {
    this.domSingleStrategy = domSingleStrategy;
  }

  public IFieldStrategy getEnumCollectionStrategy() {
    return enumCollectionStrategy;
  }

  public void setEnumCollectionStrategy(IFieldStrategy enumCollectionStrategy) {
    this.enumCollectionStrategy = enumCollectionStrategy;
  }

  public IFieldStrategy getEnumSingleStrategy() {
    return enumSingleStrategy;
  }

  public void setEnumSingleStrategy(IFieldStrategy enumSingleStrategy) {
    this.enumSingleStrategy = enumSingleStrategy;
  }

  public IFieldStrategy getPrimitiveCollectionStrategy() {
    return primitiveCollectionStrategy;
  }

  public void setPrimitiveCollectionStrategy(IFieldStrategy primitiveCollectionStrategy) {
    this.primitiveCollectionStrategy = primitiveCollectionStrategy;
  }

  public IFieldStrategy getPrimitiveSingleStrategy() {
    return primitiveSingleStrategy;
  }

  public void setPrimitiveSingleStrategy(IFieldStrategy primitiveSingleStrategy) {
    this.primitiveSingleStrategy = primitiveSingleStrategy;
  }

  public INamingStrategy getNamingStrategy() {
    return namingStrategy;
  }

  public void setNamingStrategy(INamingStrategy tableStrategy) {
    this.namingStrategy = tableStrategy;
  }

  public ITypeStrategy getTypeStrategy() {
    return typeStrategy;
  }

  public void setTypeStrategy(ITypeStrategy typeStrategy) {
    this.typeStrategy = typeStrategy;
  }

  public IFieldStrategy getWildcardCollectionStrategy() {
    return wildcardCollectionStrategy;
  }

  public void setWildcardCollectionStrategy(IFieldStrategy wildcardCollectionStrategy) {
    this.wildcardCollectionStrategy = wildcardCollectionStrategy;
  }

  public IFieldStrategy getWildcardSingleStrategy() {
    return wildcardSingleStrategy;
  }

  public void setWildcardSingleStrategy(IFieldStrategy wildcardSingleStrategy) {
    this.wildcardSingleStrategy = wildcardSingleStrategy;
  }

  public INamingStrategyFactory getComponentNamingStrategyFactory() {
    return componentNamingStrategyFactory;
  }

  public void setComponentNamingStrategyFactory(
      INamingStrategyFactory componentNamingStrategyFactory) {
    this.componentNamingStrategyFactory = componentNamingStrategyFactory;
  }
}
