package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IFieldStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.INamingStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.naming.INamingStrategyFactory;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IDiscriminatorStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IIdentifierStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property.IVersionStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.type.ITypeStrategy;

public class PrincipalStrategyWrapper implements IPrincipalStrategy {

  private final IPrincipalStrategy principalStrategy;

  public PrincipalStrategyWrapper(final IPrincipalStrategy principalStrategy) {
    this.principalStrategy = principalStrategy;
  }

  public IClassStrategy getClassStrategy() {
    return getPrincipalStrategy().getClassStrategy();
  }

  public IFieldStrategy getComplexCollectionStrategy() {
    return getPrincipalStrategy().getComplexCollectionStrategy();
  }

  public IFieldStrategy getComplexSingleStrategy() {
    return getPrincipalStrategy().getComplexSingleStrategy();
  }

  public IFieldStrategy getComponentFieldsStrategy() {
    return getPrincipalStrategy().getComponentFieldsStrategy();
  }

  public INamingStrategyFactory getComponentNamingStrategyFactory() {
    return getPrincipalStrategy().getComponentNamingStrategyFactory();
  }

  public IDiscriminatorStrategy getDiscriminatorStrategy() {
    return getPrincipalStrategy().getDiscriminatorStrategy();
  }

  public IFieldStrategy getDomCollectionStrategy() {
    return getPrincipalStrategy().getDomCollectionStrategy();
  }

  public IFieldStrategy getDomSingleStrategy() {
    return getPrincipalStrategy().getDomSingleStrategy();
  }

  public IFieldStrategy getEnumCollectionStrategy() {
    return getPrincipalStrategy().getEnumCollectionStrategy();
  }

  public IFieldStrategy getEnumSingleStrategy() {
    return getPrincipalStrategy().getEnumSingleStrategy();
  }

  public IClassStrategy getFieldsStrategy() {
    return getPrincipalStrategy().getFieldsStrategy();
  }

  public IIdentifierStrategy getIdentifierStrategy() {
    return getPrincipalStrategy().getIdentifierStrategy();
  }

  public INamingStrategy getNamingStrategy() {
    return getPrincipalStrategy().getNamingStrategy();
  }

  public IFieldStrategy getPrimitiveCollectionStrategy() {
    return getPrincipalStrategy().getPrimitiveCollectionStrategy();
  }

  public IFieldStrategy getPrimitiveSingleStrategy() {
    return getPrincipalStrategy().getPrimitiveSingleStrategy();
  }

  public IClassStrategy getSubclassStrategy() {
    return getPrincipalStrategy().getSubclassStrategy();
  }

  public ITypeStrategy getTypeStrategy() {
    return getPrincipalStrategy().getTypeStrategy();
  }

  public IVersionStrategy getVersionStrategy() {
    return getPrincipalStrategy().getVersionStrategy();
  }

  public IFieldStrategy getWildcardCollectionStrategy() {
    return getPrincipalStrategy().getWildcardCollectionStrategy();
  }

  public IFieldStrategy getWildcardSingleStrategy() {
    return getPrincipalStrategy().getWildcardSingleStrategy();
  }

  public IPrincipalStrategy getPrincipalStrategy() {
    return principalStrategy;
  }
}
