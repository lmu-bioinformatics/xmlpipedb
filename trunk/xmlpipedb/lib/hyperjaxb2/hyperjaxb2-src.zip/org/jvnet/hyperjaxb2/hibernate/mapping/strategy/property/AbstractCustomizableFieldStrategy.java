package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;

import javax.xml.namespace.QName;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IFieldStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.CustomizationUtils;
import org.jvnet.jaxbcommons.util.FieldUtils;

import com.sun.codemodel.JType;
import com.sun.msv.datatype.xsd.XSDatatype;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;

public abstract class AbstractCustomizableFieldStrategy implements
        IClassStrategy, IFieldStrategy, IPropertyGeneratingStrategy {

    public Object generateMapping(IPrincipalStrategy principalStrategy, ClassContext classContext, FieldItem draftFieldItem) {
        
        final XSDatatype propertyDatatype = getPropertyDatatype();
        final String defaultIdentifierColumnName = getDefaultPropertyName();
        final JType propertyClass = getPropertyClass(classContext.parent.getCodeModel());
    
        final FieldItem fieldItem;
    
        if (draftFieldItem == null) {
            fieldItem = FieldUtils.createPrimitiveFieldItem(classContext,
                    defaultIdentifierColumnName, propertyDatatype, propertyClass);
    
        } else {
            fieldItem = draftFieldItem;
        }
    
        return generateMappingInternal(principalStrategy, classContext, fieldItem);
    }

    protected abstract Object generateMappingInternal(IPrincipalStrategy principalStrategy, ClassContext classContext, final FieldItem idFieldItem);
    
    protected abstract QName getCustomizationName();

    public Object generateMapping(IPrincipalStrategy principalStrategy,
            ClassContext classContext) {

        final FieldItem fieldItem = getFieldItemWithCustomization(classContext,
                getCustomizationName());
        return generateMapping(principalStrategy, classContext, fieldItem);
    }

    private FieldItem getFieldItemWithCustomization(ClassContext classContext,
            final QName name) {
        final FieldUse[] fieldUses = classContext.target.getDeclaredFieldUses();
        for (int index = 0; index < fieldUses.length; index++) {
            final FieldUse fieldUse = fieldUses[index];
            final FieldItem draftFieldItem = FieldUtils.getFieldItem(fieldUse);

            if (CustomizationUtils.containsCustomization(draftFieldItem, name)) {
                return draftFieldItem;
            }
        }
        return null;
    }

}
