package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;

import org.jvnet.hyperjaxb2.customizations.ClassType;
import org.jvnet.hyperjaxb2.customizations.DiscriminatorType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.Discriminator;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JType;
import com.sun.msv.datatype.xsd.StringType;
import com.sun.msv.datatype.xsd.XSDatatype;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.ClassItem;

public class DiscriminatorStrategy implements IDiscriminatorStrategy {

    public Object generateMapping(IPrincipalStrategy principalStrategy,
            ClassContext classContext) {

        final String defaultType = getPropertyType();
        final String defaultName = getDefaultPropertyName();
        final ClassItem classItem = classContext.target;
        final ClassType cclass = Utils.getClazz(classItem);

        final DiscriminatorType cdiscriminator = cclass == null ? null : cclass
                .getDiscriminator();
        
        final Discriminator discriminator = Utils.createDiscriminator(cdiscriminator, defaultName, defaultType);
        return discriminator;
    }

    public String getDefaultPropertyName() {
        return "Hjtype";
    }

    public JType getPropertyClass(JCodeModel codeModel) {
        return codeModel.ref(String.class);
    }

    public XSDatatype getPropertyDatatype() {
        return StringType.theInstance;
    }

    public String getPropertyType() {
        return org.hibernate.type.StringType.class.getName();
    }
}
