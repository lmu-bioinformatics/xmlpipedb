package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;

import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;



public interface IDiscriminatorStrategy extends IClassStrategy, IPropertyGeneratingStrategy{
  
}
