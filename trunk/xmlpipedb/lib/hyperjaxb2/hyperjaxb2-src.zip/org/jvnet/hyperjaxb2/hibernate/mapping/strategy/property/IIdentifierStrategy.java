package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;


import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IFieldStrategy;

import com.sun.msv.datatype.xsd.XSDatatype;

public interface IIdentifierStrategy extends IClassStrategy, IFieldStrategy, IPropertyGeneratingStrategy{
  
  public String getMetaType();
  
  public String getDefaultGeneratorClass();
}
