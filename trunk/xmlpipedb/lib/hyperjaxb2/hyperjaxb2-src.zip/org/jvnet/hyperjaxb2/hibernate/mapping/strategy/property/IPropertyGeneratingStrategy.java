package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JType;
import com.sun.msv.datatype.xsd.XSDatatype;

public interface IPropertyGeneratingStrategy {

    public XSDatatype getPropertyDatatype();

    public JType getPropertyClass(JCodeModel codeModel);
    
    public String getPropertyType();

    public String getDefaultPropertyName();

}
