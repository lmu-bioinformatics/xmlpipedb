package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;


import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.IClassStrategy;

import com.sun.msv.datatype.xsd.XSDatatype;

public interface IVersionStrategy extends IClassStrategy, IPropertyGeneratingStrategy{
  
}
