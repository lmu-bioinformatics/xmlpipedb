package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.property;

import javax.xml.namespace.QName;

import org.jvnet.hyperjaxb2.customizations.Constants;
import org.jvnet.hyperjaxb2.customizations.IdType;
import org.jvnet.hyperjaxb2.customizations.Utils;
import org.jvnet.hyperjaxb2.hibernate.mapping.Id;
import org.jvnet.hyperjaxb2.hibernate.mapping.strategy.principal.IPrincipalStrategy;
import org.jvnet.jaxbcommons.util.FieldUtils;
import org.jvnet.jaxbcommons.util.TypeUtils;

import com.sun.codemodel.JCodeModel;
import com.sun.codemodel.JType;
import com.sun.msv.datatype.xsd.LongType;
import com.sun.msv.datatype.xsd.XSDatatype;
import com.sun.tools.xjc.generator.ClassContext;
import com.sun.tools.xjc.grammar.FieldItem;
import com.sun.tools.xjc.grammar.FieldUse;
import com.sun.tools.xjc.grammar.PrimitiveItem;

public class IdentifierStrategy extends AbstractCustomizableFieldStrategy
        implements IIdentifierStrategy {

    protected Object generateMappingInternal(
            IPrincipalStrategy principalStrategy, ClassContext classContext,
            final FieldItem idFieldItem) {
        final FieldUse idFieldUse = classContext.target
                .getField(idFieldItem.name);
        final IdType cid = Utils.getOrCreateId(idFieldItem);

        final String fieldPropertyName = FieldUtils
                .getFieldPropertyName(idFieldItem);
        final PrimitiveItem fieldTypeItem = TypeUtils
                .getPrimitiveTypeItem(idFieldItem);
        final String fieldType = principalStrategy.getTypeStrategy().getType(
                fieldTypeItem.guard);

        final String defaultGeneratorClass = getDefaultGeneratorClass();

        final Id id = Utils.createId(cid, fieldPropertyName, fieldType,
                defaultGeneratorClass);
        return id;
    }

    public XSDatatype getPropertyDatatype() {
        return LongType.theInstance;
    }

    public JType getPropertyClass(JCodeModel codeModel) {
      return codeModel.LONG.getWrapperClass();
    }

    public String getPropertyType() {
        return org.hibernate.type.LongType.class.getName();
    }

    public String getMetaType() {
        return org.hibernate.type.StringType.class.getName();
    }

    public String getDefaultPropertyName() {
        return "Hjid";
    }

    public String getDefaultGeneratorClass() {
        return "native";
    }

    protected QName getCustomizationName() {
        return Constants.ID;
    }
}
