package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.type;

import org.relaxng.datatype.Datatype;

public interface ITypeStrategy {
  
  public String getType(Datatype datatype);
}
