package org.jvnet.hyperjaxb2.hibernate.mapping.strategy.type;

import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;

import org.hibernate.type.BigDecimalType;
import org.hibernate.type.BigIntegerType;
import org.hibernate.type.BinaryType;
import org.hibernate.type.BooleanType;
import org.hibernate.type.ByteType;
import org.hibernate.type.DoubleType;
import org.hibernate.type.FloatType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.ShortType;
import org.hibernate.type.StringType;
import org.jvnet.hyperjaxb2.runtime.hibernate.type.CalendarType;
import org.jvnet.hyperjaxb2.runtime.hibernate.type.QNameType;
import org.relaxng.datatype.Datatype;

import com.sun.msv.datatype.xsd.XSDatatype;

public class TypeStrategy implements ITypeStrategy {

  private static final String XML_SCHEMA_NAMESPACE_URI = "http://www.w3.org/2001/XMLSchema";

  protected Map datatypeMap = new HashMap();
  {
    datatypeMap.put(xsd("anySimpleType"), StringType.class.getName());
    datatypeMap.put(xsd("base64Binary"), BinaryType.class.getName());
    datatypeMap.put(xsd("hexBinary"), BinaryType.class.getName());
    datatypeMap.put(xsd("dateTime"), CalendarType.class.getName());
    datatypeMap.put(xsd("date"), CalendarType.class.getName());
    datatypeMap.put(xsd("time"), CalendarType.class.getName());
    datatypeMap.put(xsd("duration"), StringType.class.getName());
    datatypeMap.put(xsd("gYearMonth"), StringType.class.getName());
    datatypeMap.put(xsd("gYear"), StringType.class.getName());
    datatypeMap.put(xsd("gMonthDay"), StringType.class.getName());
    datatypeMap.put(xsd("gDay"), StringType.class.getName());
    datatypeMap.put(xsd("gMonth"), StringType.class.getName());
    datatypeMap.put(xsd("float"), FloatType.class.getName());
    datatypeMap.put(xsd("double"), DoubleType.class.getName());
    datatypeMap.put(xsd("decimal"), BigDecimalType.class.getName());
    datatypeMap.put(xsd("integer"), BigIntegerType.class.getName());
    datatypeMap.put(xsd("long"), LongType.class.getName());
    datatypeMap.put(xsd("int"), IntegerType.class.getName());
    datatypeMap.put(xsd("short"), ShortType.class.getName());
    datatypeMap.put(xsd("byte"), ByteType.class.getName());
    datatypeMap.put(xsd("unsignedLong"), BigIntegerType.class.getName());
    datatypeMap.put(xsd("unsignedInt"), LongType.class.getName());
    datatypeMap.put(xsd("unsignedShort"), IntegerType.class.getName());
    datatypeMap.put(xsd("unsignedByte"), ShortType.class.getName());
    datatypeMap.put(xsd("nonNegativeInteger"), BigIntegerType.class.getName());
    datatypeMap.put(xsd("nonPositiveInteger"), BigIntegerType.class.getName());
    datatypeMap.put(xsd("positiveInteger"), BigIntegerType.class.getName());
    datatypeMap.put(xsd("negativeInteger"), BigIntegerType.class.getName());
    datatypeMap.put(xsd("boolean"), BooleanType.class.getName());
    datatypeMap.put(xsd("anyURI"), StringType.class.getName());
    datatypeMap.put(xsd("QName"), QNameType.class.getName());
    datatypeMap.put(xsd("NOTATION"), StringType.class.getName());
    datatypeMap.put(xsd("string"), StringType.class.getName());
    datatypeMap.put(xsd("normalizedString"), StringType.class.getName());
    datatypeMap.put(xsd("token"), StringType.class.getName());
    datatypeMap.put(xsd("language"), StringType.class.getName());
    datatypeMap.put(xsd("Name"), StringType.class.getName());
    datatypeMap.put(xsd("NCName"), StringType.class.getName());
    datatypeMap.put(xsd("ID"), StringType.class.getName());
    datatypeMap.put(xsd("ENTITY"), StringType.class.getName());
    datatypeMap.put(xsd("NMTOKEN"), StringType.class.getName());
  }
  
  public String getType(Datatype datatype) {

    if (datatype instanceof XSDatatype) {
      final XSDatatype xsDatatype = (XSDatatype) datatype;
      final String namespaceUri = xsDatatype.getNamespaceUri();
      final String localPart = xsDatatype.getName();
      final QName qName = localPart == null ? null : new QName(namespaceUri, localPart);

      if (datatypeMap.keySet().contains(qName)) {
        return ((String) datatypeMap.get(qName));
      }
      else {
        return getType(xsDatatype.getBaseType());
      }
    }
    return null;
  }

  public static final QName xsd(String localName) {
    return new QName(XML_SCHEMA_NAMESPACE_URI, localName);
  }
}
