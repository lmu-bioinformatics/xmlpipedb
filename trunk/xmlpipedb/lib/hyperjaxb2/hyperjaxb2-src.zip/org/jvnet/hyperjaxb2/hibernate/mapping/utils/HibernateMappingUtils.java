package org.jvnet.hyperjaxb2.hibernate.mapping.utils;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.jvnet.hyperjaxb2.hibernate.mapping.HibernateMapping;
import org.jvnet.hyperjaxb2.hibernate.mapping.HibernateMappingConstants;

public class HibernateMappingUtils {

  private static final JAXBContext CONTEXT;
  static {
    try {
      CONTEXT = JAXBContext.newInstance(
          HibernateMappingConstants.JAXB_PACKAGE_NAMES,
          HibernateMapping.class.getClassLoader());
//          new ClassLoader() {
//            private ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
//
//            public InputStream getResourceAsStream(String name) {
//              System.out.println(name);
//              return classLoader.getResourceAsStream(name);
//            }
//          });
    }
    catch (JAXBException jaxbex) {
      throw new ExceptionInInitializerError(jaxbex);
    }
  }

  private static final TransformerFactory TRANSFORMER_FACTORY;
  static {
    TRANSFORMER_FACTORY = TransformerFactory.newInstance();
  }

  public static String marshall(Object hibernateMappingObject) throws Exception {

    final Marshaller marshaller = CONTEXT.createMarshaller();
    final DOMResult result = new DOMResult();
    marshaller.marshal(hibernateMappingObject, result);

    final Transformer transformer = TRANSFORMER_FACTORY.newTransformer();

    transformer.setOutputProperty(
        OutputKeys.DOCTYPE_PUBLIC,
        HibernateMappingConstants.DOCTYPE_PUBLIC);
    transformer.setOutputProperty(
        OutputKeys.DOCTYPE_SYSTEM,
        HibernateMappingConstants.DOCTYPE_SYSTEM);
    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    transformer.setOutputProperty(OutputKeys.METHOD, "xml");

    final StringWriter stringWriter = new StringWriter();
    transformer.transform(new DOMSource(result.getNode()), new StreamResult(stringWriter));

    return stringWriter.toString();
  }
}
