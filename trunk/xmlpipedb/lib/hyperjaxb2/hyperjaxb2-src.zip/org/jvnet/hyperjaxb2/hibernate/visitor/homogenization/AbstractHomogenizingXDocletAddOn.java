/*
 * THIS FILE IS PART OF THE HyperJAXB SOURCE CODE.
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE 
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.
 *
 * THE HyperJAXB SOURCE CODE IS (C) COPYRIGHT 2004
 * by Aleksei Valikov, valikov@fzi.de
 */
package org.jvnet.hyperjaxb2.hibernate.visitor.homogenization;



/**
 * Abstract base class for XDoclet-generating add-ons.
 * This class traverses generated class items, detects fields, performs homonization of heterogeneous collections.
 * Subclasses will need to implement <code>onXXX(...)</code> methods to add appropriate XDoclets to
 * method declarations.
 *
 * @author Aleksei Valikov
 */
public abstract class AbstractHomogenizingXDocletAddOn
{
//
//  extends AbstractHyperJAXBAddOn
//  /**
//   * Processes homogeneous collection field. This method generates an internal proxying collection field and calls
//   * super method to process it.
//   *
//   * @param classContext class context.
//   * @param classItem    class item.
//   * @param fieldUse     field use.
//   */
//  public void onHomogeneousCollectionField(final ClassContext classContext, final ClassItem classItem, final FieldUse fieldUse)
//  {
//    log.debug("Processing homogeneous collection field [" + fieldUse.name + "].");
//
//    final FieldUse internalFieldUse = Generator.generateInternalCollectionField(classContext, classItem, fieldUse);
//
//    super.onHomogeneousCollectionField(classContext, classItem, internalFieldUse);
//
//    log.debug("Finished processing homogeneous collection field [" + fieldUse.name + "].");
//  }
//
//  /**
//   * Processes heterogeneous collection field. This method generates an internal homogenizing proxy collection field
//   * and calls super {@link AbstractHyperJAXBAddOn#onHomogeneousCollectionField} to process it.
//   *
//   * @param classContext class context.
//   * @param classItem    class item.
//   * @param fieldUse     field use.
//   */
//  public void onHeterogeneousCollectionField(final ClassContext classContext, final ClassItem classItem, final FieldUse fieldUse)
//  {
//    log.debug("Processing heterogeneous collection field [" + fieldUse.name + "].");
//    try
//    {
//      final FieldUse internalFieldUse = Generator.generateHomogenizingInternalCollectionField(generatorContext, grammar, classContext, classItem, fieldUse);
//      final ClassItem homogenizingClassItem = (ClassItem) Util.getTypeItem(internalFieldUse);
//      final ClassContext homogenizingClassContext = generatorContext.getClassContext(homogenizingClassItem);
//
//      processClass(homogenizingClassContext, homogenizingClassItem);
//
//      super.onHomogeneousCollectionField(classContext, classItem, internalFieldUse);
//    }
//    catch (Exception ex)
//    {
//      log.warn("Error generating homogenizing constructs.", ex);
//    }
//    log.debug("Finished processing heterogeneous collection field [" + fieldUse.name + "].");
//  }
//
}
