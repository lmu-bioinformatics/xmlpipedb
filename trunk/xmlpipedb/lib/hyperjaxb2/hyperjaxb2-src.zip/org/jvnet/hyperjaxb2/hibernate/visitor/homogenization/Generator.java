/*
 * THIS FILE IS PART OF THE HyperJAXB SOURCE CODE.
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS SOURCE IS
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE 
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.
 *
 * THE HyperJAXB SOURCE CODE IS (C) COPYRIGHT 2004
 * by Aleksei Valikov, valikov@fzi.de
 */
package org.jvnet.hyperjaxb2.hibernate.visitor.homogenization;


/**
 * This class implements generation of constructs required by add-ons.
 *
 * @author Aleksei Valikov
 */
public class Generator {
//  /**
//   * Logger.
//   */
//  protected static Log log = LogFactory.getLog(HibernateXDocletAddOn.class);
//
//  /**
//   * generates homogenizing interface.
//   *
//   * @param theInterface interface.
//   * @param fieldUse     field.
//   * @return Generated interface.
//   */
//  public static JDefinedClass generateHomogenizingInterface(final JDefinedClass theInterface, final FieldUse fieldUse) {
//    try {
//      log.debug("Adding homogenizing inner interface [" + fieldUse.name + "].");
//      final JDefinedClass innerInterface = theInterface._interface(fieldUse.name);
//
//      // Get method
//      innerInterface.method(JMod.PUBLIC, Object.class, "get");
//      // Set method
//      innerInterface.method(JMod.PUBLIC, theInterface.owner().VOID, "set").param(Object.class, "obj");
//
//      final Collection types = Util.getTypeItems(fieldUse);
//
//      for (Iterator iterator = types.iterator(); iterator.hasNext();) {
//        final TypeItem typeItem = (TypeItem) iterator.next();
//        final JType type = typeItem.getType();
//        final String name = type.name();
//        // Getter
//        innerInterface.method(JMod.PUBLIC, type, "get" + name);
//        // Setter
//        innerInterface.method(JMod.PUBLIC, theInterface.owner().VOID, "set" + name).param(type, "the" + name);
//      }
//
//      log.debug("Finished adding homogenizing inner interface [" + fieldUse.name + "].");
//      return innerInterface;
//    }
//    catch (JClassAlreadyExistsException jcaeex) {
//      // todo
//      return null;
//    }
//  }
//
//  /**
//   * Generate homogeneous proxy list inner class.
//   *
//   * @param theClass class to add an inner class to.
//   * @param fieldUse property field use.
//   * @param field    field to proxy.
//   * @return Created inner class.
//   */
//  public static JDefinedClass generateHomogeneousProxyListClass(final JDefinedClass theClass, final FieldUse fieldUse, final JVar field) {
//    try {
//      final JDefinedClass proxyListClass = theClass._class(fieldUse.name + "ProxyList")._extends(AbstractList.class);
//      proxyListClass._implements(Serializable.class);
//      
//      {
//        	final JFieldVar serialVersionUID =
//        		proxyListClass.field(JMod.PRIVATE | JMod.STATIC |JMod.FINAL, proxyListClass.owner().LONG, "serialVersionUID",
//        				JExpr.lit(Math.round(Math.random() * Long.MAX_VALUE)));
//      }
//
//      // Get method
//      {
//        final JMethod get = proxyListClass.method(JMod.PUBLIC, Object.class, "get");
//        final JVar index = get.param(theClass.owner().INT, "index");
//        get.body()._return(field.invoke("get").arg(index));
//      }
//
//      // Set method
//      {
//        final JMethod set = proxyListClass.method(JMod.PUBLIC, Object.class, "set");
//        final JVar index = set.param(theClass.owner().INT, "index");
//        final JVar o = set.param(Object.class, "o");
//        set.body()._return(field.invoke("set").arg(index).arg(o));
//      }
//
//      // Add method
//      {
//        final JMethod add = proxyListClass.method(JMod.PUBLIC, theClass.owner().VOID, "add");
//        final JVar index = add.param(theClass.owner().INT, "index");
//        final JVar o = add.param(Object.class, "o");
//        add.body().invoke(field, "add").arg(index).arg(o);
//      }
//
//      // Remove method
//      {
//        final JMethod remove = proxyListClass.method(JMod.PUBLIC, Object.class, "remove");
//        final JVar index = remove.param(theClass.owner().INT, "index");
//        remove.body()._return(field.invoke("remove").arg(index));
//      }
//
//      // Size method
//      {
//        final JMethod size = proxyListClass.method(JMod.PUBLIC, theClass.owner().INT, "size");
//        size.body()._return(field.invoke("size"));
//      }
//
//      return proxyListClass;
//    }
//    catch (JClassAlreadyExistsException jcaeex) {
//      // todo
//      return null;
//    }
//  }
//
//  /**
//   * Generates a heterogeneous proxy list class.
//   *
//   * @param theClass       class to add proxy class to.
//   * @param fieldUse       property field use.
//   * @param field          property field to proxy.
//   * @param innerInterface inner interface.
//   * @param innerClass     inner class.
//   * @return Heterogeneous proxy list class.
//   */
//  public static JDefinedClass generateHeterogeneousProxyListClass(final JDefinedClass theClass, final FieldUse fieldUse, final JVar field, final JDefinedClass innerInterface, final JDefinedClass innerClass) {
//    try {
//      final JDefinedClass proxyListClass = theClass._class(fieldUse.name + "ProxyList")._extends(AbstractList.class);
//      proxyListClass._implements(Serializable.class);
//      
//      {
//    	final JFieldVar serialVersionUID =
//    		proxyListClass.field(JMod.PRIVATE | JMod.STATIC |JMod.FINAL, proxyListClass.owner().LONG, "serialVersionUID",
//    				JExpr.lit(Math.round(Math.random() * Long.MAX_VALUE)));
//      }
//
//      // Get method
//      {
//        final JMethod get = proxyListClass.method(JMod.PUBLIC, Object.class, "get");
//        final JVar index = get.param(theClass.owner().INT, "index");
//        final JVar result = get.body().decl(innerInterface, "result", JExpr.cast(innerInterface, field.invoke("get").arg(index)));
//        get.body()._return(result.invoke("get"));
//      }
//
//      // Set method
//      {
//        final JMethod set = proxyListClass.method(JMod.PUBLIC, Object.class, "set");
//        final JVar index = set.param(theClass.owner().INT, "index");
//        final JVar o = set.param(Object.class, "o");
//        final JVar value = set.body().decl(innerInterface, "value", JExpr._new(innerClass));
//        set.body().invoke(value, "set").arg(o);
//        final JVar oldValue = set.body().decl(innerInterface, "oldValue",
//            JExpr.cast(innerInterface, field.invoke("set").arg(index).arg(value)));
//        set.body()._return(oldValue.invoke("get"));
//      }
//
//      // Add method
//      {
//        final JMethod add = proxyListClass.method(JMod.PUBLIC, theClass.owner().VOID, "add");
//        final JVar index = add.param(theClass.owner().INT, "index");
//        final JVar o = add.param(Object.class, "o");
//        final JVar value = add.body().decl(innerInterface, "value", JExpr._new(innerClass));
//        add.body().invoke(value, "set").arg(o);
//        add.body().invoke(field, "add").arg(index).arg(value);
//      }
//
//      // Remove method
//      {
//        final JMethod remove = proxyListClass.method(JMod.PUBLIC, Object.class, "remove");
//        final JVar index = remove.param(theClass.owner().INT, "index");
//        final JVar oldValue = remove.body().decl(innerInterface, "oldValue",
//            JExpr.cast(innerInterface, field.invoke("remove").arg(index)));
//        remove.body()._return(oldValue);
//      }
//
//      // Size method
//      {
//        final JMethod size = proxyListClass.method(JMod.PUBLIC, theClass.owner().INT, "size");
//        size.body()._return(field.invoke("size"));
//      }
//
//      return proxyListClass;
//    }
//    catch (JClassAlreadyExistsException jcaeex) {
//      // todo
//      return null;
//    }
//  }
//
//  /**
//   * Generates homogenizing class.
//   *
//   * @param generatorContext generator context.
//   * @param innerClass       inner class.
//   * @param fieldUse         field use.
//   * @return Generated class.
//   */
//  public static JDefinedClass generateHomogenizingClass(final GeneratorContext generatorContext, final JDefinedClass innerClass, final FieldUse fieldUse) {
//    JBlock getElse = null;
//    JBlock setElse = null;
//
//    final JMethod get = innerClass.method(JMod.PUBLIC, Object.class, "get");
//    final JMethod set = innerClass.method(JMod.PUBLIC, innerClass.owner().VOID, "set");
//    final JVar obj = set.param(Object.class, "obj");
//
//    final Collection typeItems = Util.getTypeItems(fieldUse);
//
//    for (Iterator iterator = typeItems.iterator(); iterator.hasNext();) {
//      final TypeItem typeItem = (TypeItem) iterator.next();
//      final JType type = typeItem.getType();
//      final String name = type.name();
//
//      // Field
//      final JFieldVar field = innerClass.field(JMod.PRIVATE, type, "_" + name);
//
//      // Getter
//      final JMethod getter = innerClass.method(JMod.PUBLIC, type, "get" + name);
//      getter.body()._return(field);
//
//      // Setter
//      final JMethod setter = innerClass.method(JMod.PUBLIC, innerClass.owner().VOID, "set" + name);
//      final JVar param = setter.param(type, "the" + name);
//      setter.body().assign(field, param);
//
//
//      // Add get condition
//      final JConditional getIf = (null == getElse ? get.body() : getElse)._if(JOp.ne(JExpr._null(), JExpr.invoke(getter)));
//      getIf._then()._return(JExpr.invoke(getter));
//      getElse = getIf._else();
//
//      final String implementingTypeName = typeItem instanceof ClassItem ?
//          Util.getClassName(generatorContext.getClassContext((ClassItem) typeItem).implClass) :
//          type.fullName();
//      // Add set condition
//      final JConditional setIf = (null == setElse ? set.body() : setElse).
//          _if(JExpr.lit(implementingTypeName).invoke("equals").arg(obj.invoke("getClass").invoke("getName")));
//      setIf._then().invoke(setter).arg(JExpr.cast(type, obj));
//      setElse = setIf._else();
//
//      if (!iterator.hasNext()) {
//        // Add return ull statement as fallback get method statement
//        // todo: should we maybe throw an exception?
//        getElse._return(JExpr._null());
//
//        // Add exception throwing as fallback set method statement
//        setElse._throw(JExpr._new(innerClass.owner().ref(IllegalArgumentException.class)).arg(JExpr.lit("Wrong argument class.")));
//      }
//    }
//
//
//    return innerClass;
//  }
//
//  /**
//   * Generates identifier property.
//   *
//   * @param classContext class context.
//   * @param classItem    class item.
//   * @return Generated identifier field.
//   */
//  public static FieldUse generateIdentifierProperty(final ClassContext classContext, final ClassItem classItem) {
//    // Add id field getter
//    log.debug("Adding identifier property interface getter.");
//    classContext.ref.method(JMod.PUBLIC, classContext.ref.owner().ref(String.class), "getIdInternal");
//
//    // Add id field setter method
//    log.debug("Adding identifier property interface setter.");
//    final JMethod interfaceSetter = classContext.ref.method(1, classContext.ref.owner().VOID, "setIdInternal");
//    interfaceSetter.param(classContext.implClass.owner().ref(String.class), "anId");
//    // Add classField field
//    log.debug("Adding identifier property field.");
//    final JVar classField = classContext.implClass.field(JMod.PRIVATE, classContext.implClass.owner().ref(String.class), "idInternal");
//
//    // Add classField field getter
//    log.debug("Adding identifier property getter.");
//    final JMethod classGetter = classContext.implClass.method(JMod.PUBLIC, classContext.implClass.owner().ref(String.class), "getIdInternal");
//    classGetter.body()._return(classField);
//
//    // Add classField field setter method
//    log.debug("Adding identifier property setter.");
//    final JMethod classSetter = classContext.implClass.method(1, classContext.implClass.owner().VOID, "setIdInternal");
//    final JVar classSetterParam = classSetter.param(classContext.implClass.owner().ref(String.class), "anId");
//    classSetter.body().assign(classField, classSetterParam);
//
//    final FieldUse fieldUse = classItem.getOrCreateFieldUse("IdInternal");
//    fieldUse.type = classContext.implClass.owner().ref(String.class);
//    fieldUse.multiplicity = new Multiplicity(0, 1);
//    return fieldUse;
//  }
//
//  /**
//   * Generates homogenizing internal collection field. Note that this method uses reflection to access inner fields of
//   * class context (dirty, but the most elegant solution).
//   *
//   * @param generatorContext generator context.
//   * @param grammar          grammar annotated grammar.
//   * @param classContext     class context.
//   * @param classItem        class item.
//   * @param fieldUse         field use.
//   * @return Generated field.
//   * @throws NoSuchFieldException       In case inner field could not be found.
//   * @throws InstantiationException     In case class context could not be instantiated.
//   * @throws IllegalAccessException     In case field access is denied.
//   * @throws InvocationTargetException  In case one of the reflected invocations failed.
//   * @throws FieldItem.BadTypeException In case type does not suite the type of the field item.
//   */
//  public static FieldUse generateHomogenizingInternalCollectionField(final GeneratorContext generatorContext, final AnnotatedGrammar grammar, final ClassContext classContext, final ClassItem classItem, final FieldUse fieldUse)
//      throws NoSuchFieldException, InstantiationException, IllegalAccessException, InvocationTargetException, FieldItem.BadTypeException {
//    // Add homigenizing inner class and interface
//    final JDefinedClass innerInterface = generateHomogenizingInterface(classContext.ref, fieldUse);
//
//    // final Expression expression = ((FieldItem) ((OneOrMoreExp) classItem.exp).exp).exp;
//
//    final Constructor classContextConstructor = ClassContext.class.getDeclaredConstructors()[0];
//    classContextConstructor.setAccessible(true);
//
//    final Field classContextStrategyField = ClassContext.class.getDeclaredField("strategy");
//    classContextStrategyField.setAccessible(true);
//
//    final ClassItem homogenizingClassItem = grammar.createClassItem(innerInterface, null, null);
//
//    final ClassContext homogenizedClassContext = (ClassContext) classContextConstructor.newInstance(new Object[]{generatorContext, classContextStrategyField.get(classContext), homogenizingClassItem});
//    generateHomogenizingClass(generatorContext, homogenizedClassContext.implClass, fieldUse);
//
//    final Field generatorContextField = generatorContext.getClass().getDeclaredField("classContexts");
//    generatorContextField.setAccessible(true);
//    final Map classContexts = (Map) generatorContextField.get(generatorContext);
//    classContexts.put(homogenizingClassItem, homogenizedClassContext);
//
//    final Collection typeItems = Util.getTypeItems(fieldUse);
//
//    for (final Iterator iterator = typeItems.iterator(); iterator.hasNext();) {
//      final TypeItem typeItem = (TypeItem) iterator.next();
//      final FieldUse homogenizedFieldUse = homogenizingClassItem.getOrCreateFieldUse(typeItem.getType().name());
//      final FieldItem homogenizedFieldItem = new FieldItem(typeItem.getType().name(), null);
//      homogenizedFieldItem.addType(typeItem);
//      homogenizedFieldUse.items.add(homogenizedFieldItem);
//      homogenizedFieldUse.type = typeItem.getType();
//      homogenizedFieldUse.multiplicity = new Multiplicity(0, 1);
//    }
////    processClass(generatorContext, homogenizedClassContext, homogenizingClassItem);
//
//
//    final FieldUse internalFieldUse = classItem.getOrCreateFieldUse(fieldUse.name + "Internal");
//    final FieldItem internalFieldItem = new FieldItem(fieldUse.name + "Internal", null);
//    internalFieldItem.addType(homogenizingClassItem);
//    internalFieldUse.items.add(internalFieldItem);
//    internalFieldUse.type = homogenizedClassContext.ref;
//    internalFieldUse.multiplicity = fieldUse.multiplicity;
//
//    // Declare internal property internalPropertyField
//    final JVar internalPropertyField = classContext.implClass.field(JMod.PRIVATE, List.class, "_" + internalFieldUse.name, JExpr._new(classContext.implClass.owner().ref(ArrayList.class)));
//
//    // Add proxy list class
//    final JDefinedClass proxyListClass = generateHeterogeneousProxyListClass(classContext.implClass, internalFieldUse, internalPropertyField, homogenizedClassContext.ref, homogenizedClassContext.implClass);
//
//    final JVar propertyField = Util.getField(classContext.implClass, "_" + fieldUse.name);
//
//    // Change property initialized.
//    propertyField.init(JExpr._new(classContext.implClass.owner().ref(ListImpl.class)).arg(JExpr._new(proxyListClass)));
//
//    classContext.ref.method(JMod.PUBLIC, List.class, "get" + internalFieldUse.name);
//    final JMethod internalInterfaceSetter = classContext.ref.method(JMod.PUBLIC, classContext.ref.owner().VOID, "set" + internalFieldUse.name);
//    internalInterfaceSetter.param(List.class, "the" + internalFieldUse.name);
//
//    final JMethod internalClassGetter = classContext.implClass.method(JMod.PUBLIC, List.class, "get" + internalFieldUse.name);
//    internalClassGetter.body()._return(internalPropertyField);
//
//    final JMethod internalClassSetter = classContext.implClass.method(JMod.PUBLIC, classContext.implClass.owner().VOID, "set" + internalFieldUse.name);
//
//    final JVar internalClassSetterParam = internalClassSetter.param(List.class, "the" + internalFieldUse.name);
//    final JVar field = Util.getField(classContext.implClass, "_" + internalFieldUse.name);
//    internalClassSetter.body().assign(field, internalClassSetterParam);
//    return internalFieldUse;
//  }
//
//  /**
//   * Generates internal collection field.
//   *
//   * @param classContext class context.
//   * @param classItem    class item.
//   * @param fieldUse     field use.
//   * @return Returns generated field.
//   */
//  public static FieldUse generateInternalCollectionField(final ClassContext classContext, final ClassItem classItem, final FieldUse fieldUse) {
//    final FieldUse internalFieldUse = classItem.getOrCreateFieldUse(fieldUse.name + "Internal");
//
//    internalFieldUse.items.addAll(fieldUse.items);
//    internalFieldUse.type = Util.getTypeItem(fieldUse).getType();
//    internalFieldUse.multiplicity = fieldUse.multiplicity;
//
//    // Declare internal property internalPropertyField
//    final JVar internalPropertyField = classContext.implClass.field(JMod.PRIVATE, List.class, "_" + internalFieldUse.name, JExpr._new(classContext.implClass.owner().ref(ArrayList.class)));
//
//    // Add proxy list class
//    final JDefinedClass proxyListClass = generateHomogeneousProxyListClass(classContext.implClass, internalFieldUse, internalPropertyField);
//
//    final JVar propertyField = Util.getField(classContext.implClass, "_" + fieldUse.name);
//
//    // Change property initialized.
//    propertyField.init(JExpr._new(classContext.implClass.owner().ref(ListImpl.class)).arg(JExpr._new(proxyListClass)));
//
//    final JMethod interfaceSetter = Util.getFieldInterfaceGetter(classContext, fieldUse);
//    final JMethod internalInterfaceGetter = classContext.ref.method(JMod.PUBLIC, List.class, "get" + internalFieldUse.name);
//    internalInterfaceGetter.javadoc().appendComment(interfaceSetter.javadoc().getComment());
//    
//    final JMethod internalInterfaceSetter = classContext.ref.method(JMod.PUBLIC, classContext.ref.owner().VOID, "set" + internalFieldUse.name);
//    internalInterfaceSetter.param(List.class, "the" + internalFieldUse.name);
//
//
//    final JMethod internalClassGetter = classContext.implClass.method(JMod.PUBLIC, List.class, "get" + internalFieldUse.name);
//    internalClassGetter.body()._return(internalPropertyField);
//
//    final JMethod internalClassSetter = classContext.implClass.method(JMod.PUBLIC, classContext.implClass.owner().VOID, "set" + internalFieldUse.name);
//
//    final JVar internalClassSetterParam = internalClassSetter.param(List.class, "the" + internalFieldUse.name);
//    final JVar field = Util.getField(classContext.implClass, "_" + internalFieldUse.name);
//
//    internalClassSetter.body().assign(field, internalClassSetterParam);
//    return internalFieldUse;
//  }
}
