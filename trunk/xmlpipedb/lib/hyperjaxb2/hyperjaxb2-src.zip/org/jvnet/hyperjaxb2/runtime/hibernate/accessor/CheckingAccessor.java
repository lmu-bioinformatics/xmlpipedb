package org.jvnet.hyperjaxb2.runtime.hibernate.accessor;

import java.beans.Introspector;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.hibernate.HibernateException;
import org.hibernate.PropertyNotFoundException;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.property.Getter;
import org.hibernate.property.PropertyAccessor;
import org.hibernate.property.Setter;

public abstract class CheckingAccessor implements PropertyAccessor {

  private final PropertyAccessor corePropertyAccessor;
  
  public CheckingAccessor(PropertyAccessor corePropertyAccessor) {
    this.corePropertyAccessor = corePropertyAccessor;
  }

  public Getter getGetter(Class theClass, String name) throws PropertyNotFoundException {

    final Getter getter = corePropertyAccessor.getGetter(theClass, name);

    final Method isSetter = getIsSetter(theClass, name);

    if (isSetter == null) {
      return getter;
    }
    else {
      return new CheckingGetter(getter, isSetter);
    }
  }

  private Method getIsSetter(Class theClass, String name) {
    final Method[] methods = theClass.getDeclaredMethods();
    for (int i = 0; i < methods.length; i++) {
      // only carry on if the method has no parameters
      if (methods[i].getParameterTypes().length == 0) {
        String methodName = methods[i].getName();

        if (methodName.startsWith("isSet")) {
          String testStdMethod = Introspector.decapitalize(methodName.substring(5));
          String testOldMethod = methodName.substring(5);
          if ((testStdMethod.equals(name) || testOldMethod.equals(name))
              && (methods[i].getReturnType().equals(Boolean.class) || methods[i]
                  .getReturnType()
                  .equals(boolean.class))) {
            return methods[i];
          }
        }
      }
    }
    return null;
  }

  public static class CheckingGetter implements Getter {
    private final Getter getter;
    private final Method isSetter;

    public boolean isSet(Object object) throws HibernateException {
      try {
        return ((Boolean) isSetter.invoke(object, null)).booleanValue();
      }
      catch (IllegalArgumentException e) {
        throw new HibernateException(e);
      }
      catch (IllegalAccessException e) {
        throw new HibernateException(e);
      }
      catch (InvocationTargetException e) {
        throw new HibernateException(e);
      }
    }

    public CheckingGetter(Getter getter, Method isSetter) {
      this.getter = getter;
      this.isSetter = isSetter;
    }

    public Object get(Object object) throws HibernateException {
      if (isSet(object)) {
        return getter.get(object);
      }
      else {
        return null;
      }
    }

    public Object getForInsert(Object object, SessionImplementor session) throws HibernateException {
      return get(object);
    }

    public Method getMethod() {
      return null;
    }

    public String getMethodName() {
      return null;
    }

    public Class getReturnType() {
      return getter.getReturnType();
    }
  }

  public Setter getSetter(Class theClass, String name) throws PropertyNotFoundException {
    final Setter setter = corePropertyAccessor.getSetter(theClass, name);

    final Method unsetter = getUnsetter(theClass, name);

    if (unsetter == null) {
      return setter;
    }
    else {
      return new CheckingSetter(setter, unsetter);
    }
  }

  /**
   * @param theClass
   * @param name
   * @return
   */
  private Method getUnsetter(Class theClass, String name) {
    final Method[] methods = theClass.getDeclaredMethods();
    for (int i = 0; i < methods.length; i++) {
      if (methods[i].getParameterTypes().length == 0) {
        String methodName = methods[i].getName();

        if (methodName.startsWith("unset")) {
          String testStdMethod = Introspector.decapitalize(methodName.substring(5));
          String testOldMethod = methodName.substring(5);
          if ((testStdMethod.equals(name) || testOldMethod.equals(name))
              && (methods[i].getReturnType().equals(Void.class) || methods[i]
                  .getReturnType()
                  .equals(void.class))) {
            return methods[i];
          }
        }
      }
    }
    return null;
  }

  public static class CheckingSetter implements Setter {
    private final Setter setter;
    private final Method unsetter;

    public void unset(Object object) throws HibernateException {
      try {
        unsetter.invoke(object, null);
      }
      catch (IllegalArgumentException e) {
        throw new HibernateException(e);
      }
      catch (IllegalAccessException e) {
        throw new HibernateException(e);
      }
      catch (InvocationTargetException e) {
        throw new HibernateException(e);
      }
    }

    public CheckingSetter(Setter setter, Method unsetter) {
      this.setter = setter;
      this.unsetter = unsetter;
    }

    public void set(Object object, Object value, SessionFactoryImplementor sessionFactory)
        throws HibernateException {

      if (value != null) {
        setter.set(object, value, sessionFactory);
      }
      else {
        unset(object);
      }
    }

    public Method getMethod() {
      return null;
    }

    public String getMethodName() {
      return null;
    }
  }
}
