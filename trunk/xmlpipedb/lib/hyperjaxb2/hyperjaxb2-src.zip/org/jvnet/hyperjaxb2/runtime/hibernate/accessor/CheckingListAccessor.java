package org.jvnet.hyperjaxb2.runtime.hibernate.accessor;

public class CheckingListAccessor extends CheckingAccessor {

  public CheckingListAccessor() {
    super(new ListAccessor());
  }

}
