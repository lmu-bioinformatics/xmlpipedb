package org.jvnet.hyperjaxb2.runtime.hibernate.accessor;

import org.hibernate.property.BasicPropertyAccessor;

public class CheckingPropertyAccessor extends CheckingAccessor{
  
  public CheckingPropertyAccessor() {
    super(new BasicPropertyAccessor());
  }
}
