/*
 * Created on 01.07.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.jvnet.hyperjaxb2.runtime.hibernate.accessor;

import java.lang.reflect.Method;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.PropertyNotFoundException;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.property.BasicPropertyAccessor;
import org.hibernate.property.DirectPropertyAccessor;
import org.hibernate.property.Getter;
import org.hibernate.property.PropertyAccessor;
import org.hibernate.property.Setter;

import com.sun.xml.bind.util.ListImpl;

/**
 * @author valikov
 */
public class ListAccessor implements PropertyAccessor {

  private static final PropertyAccessor DIRECT_PROPERTY_ACCESSOR = new DirectPropertyAccessor();
  private static final PropertyAccessor BASIC_PROPERTY_ACCESSOR = new BasicPropertyAccessor();

  public Getter getGetter(Class theClass, String name) throws PropertyNotFoundException {

    final Getter listGetter = BASIC_PROPERTY_ACCESSOR.getGetter(theClass, name);
    final Getter coreGetter = DIRECT_PROPERTY_ACCESSOR.getGetter(ListImpl.class, "core");
    return new ListGetter(listGetter, coreGetter);
  }

  public Setter getSetter(Class theClass, String name) throws PropertyNotFoundException {
    if (theClass.isInterface()) {
      return new NamedListSetter("_" + name);
    }
    else {
      final Setter setter = DIRECT_PROPERTY_ACCESSOR.getSetter(theClass, "_" + name);
      return new ListSetter(setter);
    }
  }

  private static class ListGetter implements Getter {
    private final Getter listGetter;
    private final Getter propertyGetter;

    public ListGetter(final Getter listGetter, final Getter propertyGetter) {
      this.listGetter = listGetter;
      this.propertyGetter = propertyGetter;
    }

    public Object get(Object object) throws HibernateException {
      final Object list = listGetter.get(object);
      return propertyGetter.get(list);
    }

    public Object getForInsert(Object object, SessionImplementor session) throws HibernateException {
      return get(object);
    }

    public Method getMethod() {
      return null;
    }

    public String getMethodName() {
      return null;
    }

    public Class getReturnType() {
      return List.class;
    }
  }

  private static class ListSetter implements Setter {

    private final Setter setter;

    public ListSetter(final Setter setter) {
      this.setter = setter;
    }

    public void set(Object object, Object value, SessionFactoryImplementor sessionFactory)
        throws HibernateException {
      final ListImpl list = new ListImpl((List) value);
      setter.set(object, list, sessionFactory);
    }

    public Method getMethod() {
      return null;
    }

    public String getMethodName() {
      return null;
    }
  }

  private static class NamedListSetter implements Setter {

    private final String name;

    public NamedListSetter(final String name) {
      this.name = name;
    }

    public void set(Object object, Object value, SessionFactoryImplementor sessionFactory)
        throws HibernateException {

      final Setter setter = DIRECT_PROPERTY_ACCESSOR.getSetter(object.getClass(), name);
      final ListImpl list = new ListImpl((List) value);
      setter.set(object, list, sessionFactory);
    }

    public Method getMethod() {
      return null;
    }

    public String getMethodName() {
      return null;
    }
  }

}
