/*
 * Created on 03.07.2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.jvnet.hyperjaxb2.runtime.hibernate.accessor.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * 
 * @author valikov
 */
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for org.jvnet.hyperjaxb2.runtime.accessor.test");
    //$JUnit-BEGIN$
    suite.addTestSuite(CheckingListAccessorTest.class);
    suite.addTestSuite(CheckingPropertyPropertyAccessorTest.class);
    //$JUnit-END$
    return suite;
  }
}
