package org.jvnet.hyperjaxb2.runtime.hibernate.accessor.tests;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.hibernate.property.Getter;
import org.hibernate.property.Setter;
import org.jvnet.hyperjaxb2.runtime.hibernate.accessor.ListAccessor;

import com.sun.xml.bind.util.ListImpl;

public class CheckingListAccessorTest extends TestCase {

  private Getter getter;
  private Setter setter;

  protected void setUp() throws Exception {
    final ListAccessor listAccessor = new ListAccessor();
    getter = listAccessor.getGetter(Foo.class, "bar");
    setter = listAccessor.getSetter(Foo.class, "bar");
  }

  public void testAccess() {
    final Foo foo = new Foo();

    final List l1 = (List) getter.get(foo);
    Assert.assertNotNull("Non-null list is expected.", l1);
    final List l2 = new ArrayList();
    l2.add("1");
    l2.add("2");
    l2.add("3");
    setter.set(foo, l2, null);
    Assert.assertEquals("Lists must be equal.", foo.getBar(), l2);
    final List l3 = (List) getter.get(foo);
    Assert.assertSame("Lists must be identical.", l2, l3);
    
    setter.set(foo, null, null);
    Assert.assertFalse("Property must be unset.", foo.isSetBar());
  }

  public static class Foo {
    protected ListImpl bar;

    protected ListImpl _getBar() {
      if (bar == null) {
        bar = new ListImpl(new ArrayList());
      }
      return bar;
    }

    public List getBar() {
      return _getBar();
    }

    public boolean isSetBar() {
      return ((bar == null) ? false : bar.isModified());
    }

    public void unsetBar() {
      if (bar != null) {
        bar.clear();
        bar.setModified(false);
      }
    }

  }
}
