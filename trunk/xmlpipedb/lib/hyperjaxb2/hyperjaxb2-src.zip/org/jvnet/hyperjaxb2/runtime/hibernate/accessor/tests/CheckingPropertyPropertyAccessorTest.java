package org.jvnet.hyperjaxb2.runtime.hibernate.accessor.tests;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.hibernate.property.Getter;
import org.hibernate.property.PropertyAccessor;
import org.hibernate.property.Setter;
import org.jvnet.hyperjaxb2.runtime.hibernate.accessor.CheckingPropertyAccessor;

public class CheckingPropertyPropertyAccessorTest extends TestCase {

  private Getter getter;
  private Setter setter;

  protected void setUp() throws Exception {
    final PropertyAccessor accessor = new CheckingPropertyAccessor();
    getter = accessor.getGetter(Foo.class, "bar");
    setter = accessor.getSetter(Foo.class, "bar");
  }

  public void testAccess() {
    final Foo foo = new Foo();

    Assert.assertNull("Value is not yet set - must be null.", getter.get(foo));

    foo.setBar(0);
    Assert.assertEquals("Wrong value.", new Double(0), getter.get(foo));
    foo.setBar(1);
    Assert.assertEquals("Wrong value.", new Double(1), getter.get(foo));
    foo.unsetBar();
    Assert.assertNull("Must be null.", getter.get(foo));

    setter.set(foo, new Double(2), null);
    Assert.assertTrue("Value must be set.", foo.isSetBar());
    Assert.assertEquals("Wrong value.", 2d, foo.getBar(), 0.0001);
    setter.set(foo, null, null);
    Assert.assertFalse("Value must be unset.", foo.isSetBar());
    Assert.assertEquals("Wrong value.", 2d, foo.getBar(), 0.0001);
  }

  public static class Foo {
    protected boolean hasBar;
    protected double bar;

    public double getBar() {
      return bar;
    }

    public void setBar(double value) {
      bar = value;
      hasBar = true;
    }

    public boolean isSetBar() {
      return hasBar;
    }

    public void unsetBar() {
      hasBar = false;
    }
  }
}
