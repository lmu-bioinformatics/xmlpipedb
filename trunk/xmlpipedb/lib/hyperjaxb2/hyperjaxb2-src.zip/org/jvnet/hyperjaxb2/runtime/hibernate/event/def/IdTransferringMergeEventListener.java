package org.jvnet.hyperjaxb2.runtime.hibernate.event.def;

import java.io.Serializable;
import java.util.Map;

import org.hibernate.AssertionFailure;
import org.hibernate.EntityMode;
import org.hibernate.StaleObjectStateException;
import org.hibernate.WrongClassException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.event.MergeEvent;
import org.hibernate.event.def.DefaultMergeEventListener;
import org.hibernate.persister.entity.EntityPersister;

public class IdTransferringMergeEventListener extends DefaultMergeEventListener {

  protected Object entityIsTransient(MergeEvent event, Map copyCache) {
    final Object mergedCopy = super.entityIsTransient(event, copyCache);
    final SessionImplementor session = event.getSession();
    final EntityPersister persister = session.getEntityPersister(event.getEntityName(), event
        .getEntity());
    final Object original = event.getOriginal();
    final EntityMode entityMode = session.getEntityMode();
    // Extract id from merged copy (which is currently registered with Session).
    final Serializable id = persister.getIdentifier(mergedCopy, entityMode);
    // Set id on original object (which remains detached).
    persister.setIdentifier(original, id, entityMode);

    if (persister.isVersioned()) {
      final Object version = persister.getVersion(mergedCopy, entityMode);
      persister.setPropertyValue(original, persister.getVersionProperty(), version, entityMode);
    }
    return mergedCopy;
  }

  protected Object entityIsDetached(MergeEvent event, Map copyCache) {

    //    log.trace("merging detached instance");

    final Object entity = event.getEntity();
    final SessionImplementor source = event.getSession();

    final EntityPersister persister = source.getEntityPersister(event.getEntityName(), entity);
    final String entityName = persister.getEntityName();

    Serializable id = event.getRequestedId();
    if (id == null) {
      id = persister.getIdentifier(entity, source.getEntityMode());
    }
    else {
      //TODO: check that entity id = requestedId
    }

    final Object result = source.get(entityName, id);
    if (result == null) {
      //TODO: we should throw an exception if we really *know* for sure  
      //      that this is a detached instance, rather than just assuming
      //throw new StaleObjectStateException(entityName, id);
      event.setRequestedId(id);

      // we got here because we assumed that an instance
      // with an assigned id was detached, when it was
      // really persistent
      return entityIsTransient(event, copyCache);
    }
    else {
      copyCache.put(entity, result); //before cascade!

      final Object target = source.getPersistenceContext().unproxy(result);
      if (target == entity) {
        throw new AssertionFailure("entity was not detached");
      }
      else if (!source.getEntityName(target).equals(entityName)) {
        throw new WrongClassException(
            "class of the given object did not match class of persistent copy",
            event.getRequestedId(),
            entityName);
      }
      else if (persister.isVersioned()
             && !persister.getVersionType().isSame(
              persister.getVersion(target, source.getEntityMode()),
              persister.getVersion(entity, source.getEntityMode()),
              source.getEntityMode())) {
        throw new StaleObjectStateException(entityName, event.getRequestedId());
      }

      // cascade first, so that all unsaved objects get their 
      // copy created before we actually copy
      cascadeOnMerge(event, persister, entity, copyCache);
      copyValues(persister, entity, target, source, copyCache);

      return result;
    }

  }
}
