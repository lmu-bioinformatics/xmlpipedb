package org.jvnet.hyperjaxb2.runtime.hibernate.type;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.hibernate.HibernateException;
import org.hibernate.type.ImmutableType;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Hibernate's user type for {@link Element}.
 *
 * @author Aleksei Valikov
 */
public class ElementType extends ImmutableType {
  private transient DocumentBuilder documentBuilder;
  private transient Transformer serializer;

  /**
   * Constructs a new element type. Thic constructor initializes parser and serializer.
   */
  public ElementType() {
    final TransformerFactory transformerFactory = TransformerFactory.newInstance();

    try {
      serializer = transformerFactory.newTransformer();
    }
    catch (TransformerConfigurationException tcex) {
      throw new RuntimeException("Unable to instantiate serializing transformer.", tcex);
    }

    final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    documentBuilderFactory.setNamespaceAware(true);

    try {
      documentBuilder = documentBuilderFactory.newDocumentBuilder();
    }
    catch (ParserConfigurationException pcex) {
      throw new RuntimeException("Unable to instantiate parser.", pcex);
    }
  }

  public int sqlType() {
    return Types.VARCHAR;
  }

  public Object deepCopy(final Object o) throws HibernateException {
    Element copy = null;

    if (null != o) {
      final Element element = (Element) o;

      synchronized (documentBuilder) {
        final Document document = documentBuilder.newDocument();
        copy = (Element) document.importNode(element, true);
      }
    }
    return copy;
  }

  public boolean equals(final Object o, final Object o1) throws HibernateException {
    return (o == null && o1 == null) || (null != o && o.equals(o1));
  }

  public Object get(ResultSet rs, String name) throws HibernateException, SQLException {
    final String content = rs.getString(name);
    if (content == null) {
      return null;
    }
    else {
      return parse(content);
    }
  }

  private Object parse(final String content) {
    try {
      synchronized (documentBuilder) {
        final Document document = documentBuilder.parse(new InputSource(new StringReader(content)));
        return document.getDocumentElement();
      }
    }
    catch (IOException ioex) {
      throw new HibernateException("I/O exception parsing content.", ioex);
    }
    catch (SAXException saxex) {
      throw new HibernateException("SAX exception parsing content.", saxex);
    }
  }

  public void set(PreparedStatement st, Object value, int index)
      throws HibernateException,
      SQLException {

    final Element element = (Element) value;
    st.setString(index, serialize(element));
  }

  /**
   * @param element
   * @return
   */
  private String serialize(final Element element) {
    final StringWriter sw = new StringWriter();
    try {
      synchronized (serializer) {
        serializer.transform(new DOMSource(element), new StreamResult(sw));
      }
    }
    catch (TransformerException tex) {
      throw new HibernateException("Error serializing DOM node.", tex);
    }
    return sw.toString();
  }

  public Class getReturnedClass() {
    return Element.class;
  }

  public Object fromStringValue(String xml) throws HibernateException {
    return parse(xml);
  }

  public String toString(Object value) throws HibernateException {
    return serialize((Element) value);
  }

  public String getName() {
    return "dom_element";
  }
}
