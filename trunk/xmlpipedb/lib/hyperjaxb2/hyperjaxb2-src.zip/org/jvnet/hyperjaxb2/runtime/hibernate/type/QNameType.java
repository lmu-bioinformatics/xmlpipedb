package org.jvnet.hyperjaxb2.runtime.hibernate.type;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.xml.namespace.QName;

import org.hibernate.EntityMode;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.type.ImmutableType;
import org.hibernate.type.LiteralType;

public class QNameType extends ImmutableType implements LiteralType {

  public Object get(ResultSet rs, String name) throws HibernateException, SQLException {
    String qName = (String) Hibernate.STRING.nullSafeGet(rs, name);
    return (qName == null) ? null : QName.valueOf(qName);
  }

  public void set(PreparedStatement st, Object value, int index)
      throws HibernateException,
      SQLException {
    Hibernate.STRING.set(st, ((QName) value).toString(), index);
  }

  public int sqlType() {
    return Hibernate.STRING.sqlType();
  }

  public String toString(Object value) throws HibernateException {
    return ((QName) value).toString();
  }

  public int compare(Object x, Object y, EntityMode entityMode) {
    return ((QName) x).toString().compareTo(((QName) y).toString());
  }

  public Object fromStringValue(String xml) throws HibernateException {
    return QName.valueOf(xml);
  }

  public Class getReturnedClass() {
    return QName.class;
  }

  public String getName() {
    return "timezone";
  }

  public String objectToSQLString(Object value) throws Exception {
    return ((LiteralType) Hibernate.STRING).objectToSQLString(((QName) value).toString());
  }
}
