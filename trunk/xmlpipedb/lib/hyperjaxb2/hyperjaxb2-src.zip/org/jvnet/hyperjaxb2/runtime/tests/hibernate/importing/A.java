package org.jvnet.hyperjaxb2.runtime.tests.hibernate.importing;

public class A {
  
  private String id;
  
  private B b;
  
  public B getB() {
    return b;
  }

  public void setB(B b) {
    this.b = b;
  }
  
  private String d;
  
  public String getD() {
    return d;
  }

  public void setD(String d) {
    this.d = d;
  }
  
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
}
