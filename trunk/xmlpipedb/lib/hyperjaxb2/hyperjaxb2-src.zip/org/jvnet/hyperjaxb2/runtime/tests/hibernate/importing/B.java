package org.jvnet.hyperjaxb2.runtime.tests.hibernate.importing;

public class B {
  
  private String id;
  
  private String c;
  
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  public String getC() {
    return c;
  }

  public void setC(String value) {
    this.c = value;
  }
}