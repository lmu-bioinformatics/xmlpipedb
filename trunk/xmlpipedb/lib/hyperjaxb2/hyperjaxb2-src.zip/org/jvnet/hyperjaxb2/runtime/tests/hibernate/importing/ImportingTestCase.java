package org.jvnet.hyperjaxb2.runtime.tests.hibernate.importing;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.jvnet.hyperjaxb2.runtime.hibernate.event.def.IdTransferringMergeEventListener;
import org.jvnet.hyperjaxb2.runtime.tests.hibernate.HibernateTestCase;

public class ImportingTestCase extends HibernateTestCase {

  public ImportingTestCase(String x) {
    super(x);
  }
  
  public void testIt() throws Exception {
    final A a1 = new A();
    final B b1 = new B();
    a1.setId("A");
    a1.setB(b1);
    a1.setD("d1");
    b1.setId("B");
    b1.setC("c1");
    save(a1);
    
    final A a2 = new A();
    final B b2 = new B();
    a2.setId("A");
    a2.setB(b2);
    a2.setD("d2");
    b2.setId("B");
    b2.setC("c2");
    save(a2);
    
    final A a3 = load("A");
    
    assertEquals(a3.getD(), a2.getD());
    assertEquals(a3.getB().getC(), a2.getB().getC());
  }
  
  public void save(A a)
  {
    final Session s = openSession();
    final Transaction t = s.beginTransaction();
    s.merge(a);
    t.commit();
    s.close();
  }
  
  public A load(String id)
  {
    final Session s = openSession();
    final A a = (A) s.get(A.class, id);
    s.close();
    return a;
  }
  
  

  protected String[] getMappings() {
    return new String[] { "A.hbm.xml" };
  }
  
  
  protected void configure(Configuration cfg) {
    cfg.getSessionEventListenerConfig().setMergeEventListener( new IdTransferringMergeEventListener() );      
  }
  
  
}
