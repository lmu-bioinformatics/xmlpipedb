package org.jvnet.hyperjaxb2.tests.po;

public class AddOnTest extends org.jvnet.hyperjaxb2.addon.tests.AddOnTest {

    public AddOnTest() {
        super("po");
    }

}
